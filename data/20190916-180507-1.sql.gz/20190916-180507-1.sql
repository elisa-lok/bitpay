-- -----------------------------
-- Think MySQL Data Transfer 
-- 
-- Host     : 127.0.0.1
-- Port     : 3306
-- Database : pay
-- 
-- Part : #1
-- Date : 2019-09-16 18:05:07
-- -----------------------------

SET FOREIGN_KEY_CHECKS = 0;


-- -----------------------------
-- Table structure for `think_ad_buy`
-- -----------------------------
DROP TABLE IF EXISTS `think_ad_buy`;
CREATE TABLE `think_ad_buy` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `ad_no` varchar(15) NOT NULL COMMENT '广告唯一编号',
  `userid` int(11) NOT NULL COMMENT '发布用户id',
  `location` int(10) NOT NULL COMMENT '地区',
  `currency` int(10) NOT NULL COMMENT '货币',
  `margin` decimal(4,2) NOT NULL DEFAULT '0.00' COMMENT '溢价',
  `min_limit` decimal(12,2) NOT NULL DEFAULT '0.00' COMMENT '限额（最小）',
  `max_limit` decimal(12,2) NOT NULL DEFAULT '0.00' COMMENT '限额（最大）',
  `pay_method` tinyint(4) NOT NULL COMMENT '支付方式',
  `message` varchar(500) NOT NULL COMMENT '留言',
  `due_time` int(10) NOT NULL COMMENT '购买付款期限(分钟)',
  `safe_option` tinyint(1) NOT NULL DEFAULT '0' COMMENT '安全选项,0不开启,1开启',
  `trust_only` tinyint(1) NOT NULL DEFAULT '0' COMMENT '仅限受信任的交易者(0关闭,1开启)',
  `open_time` varchar(100) NOT NULL DEFAULT '1,1,1,1,1,1,1' COMMENT '开启时间(单个1开启,单个0关闭,0-1表示0点到1点开启)',
  `add_time` int(10) NOT NULL COMMENT '添加时间',
  `state` tinyint(1) NOT NULL DEFAULT '0' COMMENT '状态(1进行中,2下架,3已完成)',
  `finished_time` int(10) DEFAULT NULL,
  `type` tinyint(1) NOT NULL DEFAULT '0' COMMENT '默认值，不用赋值',
  `coin` int(10) NOT NULL DEFAULT '0',
  `fee` decimal(5,2) NOT NULL DEFAULT '0.00',
  `amount` int(11) DEFAULT '0' COMMENT '购买数量',
  `price` decimal(10,2) DEFAULT '0.00',
  `pay_method2` tinyint(4) DEFAULT NULL COMMENT '支付宝',
  `pay_method3` tinyint(4) DEFAULT NULL COMMENT '微信',
  `pay_method4` tinyint(4) DEFAULT NULL COMMENT '云闪付',
  PRIMARY KEY (`id`),
  UNIQUE KEY `ad_no` (`ad_no`) USING BTREE,
  KEY `userid` (`userid`) USING BTREE,
  KEY `currency` (`currency`) USING BTREE,
  KEY `trust_only` (`trust_only`) USING BTREE,
  KEY `add_time` (`add_time`) USING BTREE,
  KEY `state` (`state`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `think_ad_buy`
-- -----------------------------
INSERT INTO `think_ad_buy` VALUES ('1', 'cgvtn1567307962', '4', '0', '0', '0.00', '1.00', '7210.00', '0', '', '0', '0', '0', '1,1,1,1,1,1,1', '1567307962', '2', '', '0', '0', '0.00', '1000', '7.21', '2', '2', '0');
INSERT INTO `think_ad_buy` VALUES ('2', 'oekhy1567308500', '4', '0', '0', '0.00', '1.00', '7150.00', '0', '', '0', '0', '0', '1,1,1,1,1,1,1', '1567308500', '2', '', '0', '0', '0.00', '1000', '7.15', '0', '2', '0');
INSERT INTO `think_ad_buy` VALUES ('3', 'nlgqm1567319731', '4', '0', '0', '0.00', '1.00', '714.00', '0', '', '0', '0', '0', '1,1,1,1,1,1,1', '1567319731', '2', '', '0', '0', '0.00', '100', '7.14', '0', '2', '0');
INSERT INTO `think_ad_buy` VALUES ('4', 'ztdpg1567420751', '4', '0', '0', '0.00', '1.00', '7150.00', '2', '', '0', '0', '0', '1,1,1,1,1,1,1', '1567420751', '2', '', '0', '0', '0.00', '1000', '7.15', '2', '0', '0');

-- -----------------------------
-- Table structure for `think_ad_sell`
-- -----------------------------
DROP TABLE IF EXISTS `think_ad_sell`;
CREATE TABLE `think_ad_sell` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `ad_no` varchar(15) NOT NULL COMMENT '广告唯一编号',
  `userid` int(11) NOT NULL COMMENT '发布用户id',
  `location` int(10) NOT NULL COMMENT '地区',
  `currency` int(10) NOT NULL COMMENT '货币',
  `margin` decimal(4,2) NOT NULL DEFAULT '0.00' COMMENT '溢价',
  `min_price` decimal(12,2) DEFAULT '0.00',
  `min_limit` decimal(12,2) NOT NULL DEFAULT '0.00',
  `max_limit` decimal(12,2) NOT NULL DEFAULT '0.00',
  `pay_method` varchar(20) NOT NULL COMMENT '支付方式',
  `message` varchar(500) NOT NULL COMMENT '留言',
  `safe_option` tinyint(1) NOT NULL DEFAULT '0' COMMENT '安全选项,0不开启,1开启',
  `trust_only` tinyint(1) NOT NULL DEFAULT '0' COMMENT '仅限受信任的交易者(0关闭,1开启)',
  `open_time` varchar(100) NOT NULL DEFAULT '1,1,1,1,1,1,1' COMMENT '开启时间(单个1开启,单个0关闭,0-1表示0点到1点开启)',
  `add_time` int(10) NOT NULL COMMENT '添加时间',
  `state` tinyint(1) NOT NULL DEFAULT '1' COMMENT '状态(1进行中,2下架,3完成)',
  `finished_time` int(10) DEFAULT NULL COMMENT '完成时间',
  `type` tinyint(1) NOT NULL DEFAULT '1',
  `coin` int(10) NOT NULL DEFAULT '0',
  `fee` decimal(4,2) DEFAULT '0.00',
  `price` decimal(12,2) DEFAULT '0.00',
  `is_check` tinyint(4) DEFAULT '0' COMMENT '0:待审核，1：通过，2：拒绝',
  `amount` int(11) DEFAULT '0' COMMENT '出售数量',
  `pay_method2` tinyint(4) DEFAULT NULL COMMENT '支付宝',
  `pay_method3` tinyint(4) DEFAULT NULL COMMENT '微信',
  `pay_method4` tinyint(4) DEFAULT NULL COMMENT '云闪付',
  PRIMARY KEY (`id`),
  UNIQUE KEY `ad_no` (`ad_no`) USING BTREE,
  KEY `userid` (`userid`) USING BTREE,
  KEY `currency` (`currency`) USING BTREE,
  KEY `trust_only` (`trust_only`) USING BTREE,
  KEY `add_time` (`add_time`) USING BTREE,
  KEY `state` (`state`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=46 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `think_ad_sell`
-- -----------------------------
INSERT INTO `think_ad_sell` VALUES ('1', 'oivxa1567236364', '2', '0', '0', '0.00', '0.00', '1.00', '7230.00', '1', '', '0', '0', '1,1,1,1,1,1,1', '1567236364', '2', '', '1', '0', '0.00', '7.23', '0', '1000', '1', '0', '0');
INSERT INTO `think_ad_sell` VALUES ('2', 'tqfln1567306574', '4', '0', '0', '0.00', '0.00', '1.00', '713.00', '2', '', '0', '0', '1,1,1,1,1,1,1', '1567306574', '2', '', '1', '0', '0.00', '7.13', '0', '100', '2', '2', '0');
INSERT INTO `think_ad_sell` VALUES ('3', 'dpifx1567309592', '4', '0', '0', '0.00', '0.00', '1.00', '7130.00', '', '', '0', '0', '1,1,1,1,1,1,1', '1567309592', '2', '', '1', '0', '0.00', '7.13', '0', '1000', '2', '2', '0');
INSERT INTO `think_ad_sell` VALUES ('4', 'qewdk1567317148', '4', '0', '0', '0.00', '0.00', '1.00', '2154.00', '', '', '0', '0', '1,1,1,1,1,1,1', '1567317148', '2', '', '1', '0', '0.00', '7.18', '0', '300', '0', '2', '0');
INSERT INTO `think_ad_sell` VALUES ('5', 'avadz1567318905', '4', '0', '0', '0.00', '0.00', '1.00', '718.00', '2', '', '0', '0', '1,1,1,1,1,1,1', '1567318905', '2', '', '1', '0', '0.00', '7.18', '0', '100', '0', '0', '0');
INSERT INTO `think_ad_sell` VALUES ('6', 'tiovh1567319305', '4', '0', '0', '0.00', '0.00', '1.00', '3590.00', '2', '', '0', '0', '1,1,1,1,1,1,1', '1567319305', '2', '', '1', '0', '0.00', '7.18', '0', '500', '2', '0', '0');
INSERT INTO `think_ad_sell` VALUES ('7', 'ttask1567321213', '4', '0', '0', '0.00', '0.00', '1.00', '7180.00', '', '', '0', '0', '1,1,1,1,1,1,1', '1567321213', '2', '', '1', '0', '0.00', '7.18', '0', '1000', '0', '2', '0');
INSERT INTO `think_ad_sell` VALUES ('8', 'opcly1567327913', '4', '0', '0', '0.00', '0.00', '1.00', '7180.00', '', '', '0', '0', '1,1,1,1,1,1,1', '1567327913', '2', '', '1', '0', '0.00', '7.18', '0', '1000', '0', '2', '0');
INSERT INTO `think_ad_sell` VALUES ('9', 'tdcir1567329461', '4', '0', '0', '0.00', '0.00', '1.00', '7190.00', '', '', '0', '0', '1,1,1,1,1,1,1', '1567329461', '2', '', '1', '0', '0.00', '7.19', '0', '1000', '0', '2', '0');
INSERT INTO `think_ad_sell` VALUES ('10', 'ndbfm1567329715', '4', '0', '0', '0.00', '0.00', '1.00', '718.00', '', '', '0', '0', '1,1,1,1,1,1,1', '1567329715', '2', '', '1', '0', '0.00', '7.18', '0', '100', '0', '2', '0');
INSERT INTO `think_ad_sell` VALUES ('11', 'bjfpk1567330096', '4', '0', '0', '0.00', '0.00', '1.00', '7190.00', '', '', '0', '0', '1,1,1,1,1,1,1', '1567330096', '2', '', '1', '0', '0.00', '7.19', '0', '1000', '0', '2', '0');
INSERT INTO `think_ad_sell` VALUES ('12', 'xbbnb1567330211', '4', '0', '0', '0.00', '0.00', '1.00', '7180.00', '', '', '0', '0', '1,1,1,1,1,1,1', '1567330211', '2', '', '1', '0', '0.00', '7.18', '0', '1000', '0', '2', '0');
INSERT INTO `think_ad_sell` VALUES ('13', 'wzxil1567330621', '4', '0', '0', '0.00', '0.00', '1.00', '7180.00', '', '', '0', '0', '1,1,1,1,1,1,1', '1567330621', '2', '', '1', '0', '0.00', '7.18', '0', '1000', '0', '2', '0');
INSERT INTO `think_ad_sell` VALUES ('14', 'nhxaz1567330793', '4', '0', '0', '0.00', '0.00', '1.00', '7180.00', '', '', '0', '0', '1,1,1,1,1,1,1', '1567330793', '2', '', '1', '0', '0.00', '7.18', '0', '1000', '0', '2', '0');
INSERT INTO `think_ad_sell` VALUES ('15', 'ltjar1567331397', '4', '0', '0', '0.00', '0.00', '1.00', '7180.00', '', '', '0', '0', '1,1,1,1,1,1,1', '1567331397', '2', '', '1', '0', '0.00', '7.18', '0', '1000', '0', '2', '0');
INSERT INTO `think_ad_sell` VALUES ('16', 'xlkfr1567331948', '4', '0', '0', '0.00', '0.00', '1.00', '7180.00', '', '', '0', '0', '1,1,1,1,1,1,1', '1567331948', '2', '', '1', '0', '0.00', '7.18', '0', '1000', '0', '2', '0');
INSERT INTO `think_ad_sell` VALUES ('17', 'ftlti1567332350', '4', '0', '0', '0.00', '0.00', '1.00', '7180.00', '', '', '0', '0', '1,1,1,1,1,1,1', '1567332350', '2', '', '1', '0', '0.00', '7.18', '0', '1000', '0', '2', '0');
INSERT INTO `think_ad_sell` VALUES ('18', 'xgbhe1567333453', '4', '0', '0', '0.00', '0.00', '1.00', '7180.00', '', '', '0', '0', '1,1,1,1,1,1,1', '1567333453', '2', '', '1', '0', '0.00', '7.18', '0', '1000', '0', '2', '0');
INSERT INTO `think_ad_sell` VALUES ('19', 'hqhzh1567335089', '4', '0', '0', '0.00', '0.00', '1.00', '10008.48', '', '', '0', '0', '1,1,1,1,1,1,1', '1567335089', '2', '', '1', '0', '0.00', '7.19', '0', '1392', '0', '2', '0');
INSERT INTO `think_ad_sell` VALUES ('20', 'afhkb1567337552', '4', '0', '0', '0.00', '0.00', '1.00', '7180.00', '', '', '0', '0', '1,1,1,1,1,1,1', '1567337552', '2', '', '1', '0', '0.00', '7.18', '0', '1000', '2', '0', '0');
INSERT INTO `think_ad_sell` VALUES ('21', 'dgkam1567337881', '4', '0', '0', '0.00', '0.00', '1.00', '7180.00', '', '', '0', '0', '1,1,1,1,1,1,1', '1567337881', '2', '', '1', '0', '0.00', '7.18', '0', '1000', '2', '0', '0');
INSERT INTO `think_ad_sell` VALUES ('22', 'kqinv1567338103', '4', '0', '0', '0.00', '0.00', '1.00', '7180.00', '', '', '0', '0', '1,1,1,1,1,1,1', '1567338103', '2', '', '1', '0', '0.00', '7.18', '0', '1000', '2', '0', '0');
INSERT INTO `think_ad_sell` VALUES ('23', 'jktvg1567338422', '4', '0', '0', '0.00', '0.00', '1.00', '7180.00', '', '', '0', '0', '1,1,1,1,1,1,1', '1567338422', '2', '', '1', '0', '0.00', '7.18', '0', '1000', '2', '0', '0');
INSERT INTO `think_ad_sell` VALUES ('24', 'uberd1567338802', '4', '0', '0', '0.00', '0.00', '1.00', '7180.00', '', '', '0', '0', '1,1,1,1,1,1,1', '1567338802', '2', '', '1', '0', '0.00', '7.18', '0', '1000', '2', '0', '0');
INSERT INTO `think_ad_sell` VALUES ('25', 'jigrj1567339051', '4', '0', '0', '0.00', '0.00', '1.00', '7180.00', '', '', '0', '0', '1,1,1,1,1,1,1', '1567339051', '2', '', '1', '0', '0.00', '7.18', '0', '1000', '0', '2', '0');
INSERT INTO `think_ad_sell` VALUES ('26', 'omsvk1567339241', '4', '0', '0', '0.00', '0.00', '1.00', '7180.00', '', '', '0', '0', '1,1,1,1,1,1,1', '1567339241', '2', '', '1', '0', '0.00', '7.18', '0', '1000', '2', '0', '0');
INSERT INTO `think_ad_sell` VALUES ('27', 'anczj1567339678', '4', '0', '0', '0.00', '0.00', '1.00', '7180.00', '', '', '0', '0', '1,1,1,1,1,1,1', '1567339678', '2', '', '1', '0', '0.00', '7.18', '0', '1000', '2', '0', '0');
INSERT INTO `think_ad_sell` VALUES ('28', 'qfnmj1567339858', '4', '0', '0', '0.00', '0.00', '1.00', '7190.00', '', '', '0', '0', '1,1,1,1,1,1,1', '1567339858', '2', '', '1', '0', '0.00', '7.19', '0', '1000', '2', '0', '0');
INSERT INTO `think_ad_sell` VALUES ('29', 'oaujt1567340073', '4', '0', '0', '0.00', '0.00', '1.00', '7190.00', '', '', '0', '0', '1,1,1,1,1,1,1', '1567340073', '2', '', '1', '0', '0.00', '7.19', '0', '1000', '2', '0', '0');
INSERT INTO `think_ad_sell` VALUES ('30', 'pvmhp1567340238', '4', '0', '0', '0.00', '0.00', '1.00', '7180.00', '', '', '0', '0', '1,1,1,1,1,1,1', '1567340238', '2', '', '1', '0', '0.00', '7.18', '0', '1000', '2', '0', '0');
INSERT INTO `think_ad_sell` VALUES ('31', 'szbew1567341769', '4', '0', '0', '0.00', '0.00', '1.00', '71800.00', '', '', '0', '0', '1,1,1,1,1,1,1', '1567341769', '2', '', '1', '0', '0.00', '7.18', '0', '10000', '2', '0', '0');
INSERT INTO `think_ad_sell` VALUES ('32', 'eizca1567341993', '4', '0', '0', '0.00', '0.00', '1.00', '7180.00', '', '', '0', '0', '1,1,1,1,1,1,1', '1567341993', '2', '', '1', '0', '0.00', '7.18', '0', '1000', '2', '0', '0');
INSERT INTO `think_ad_sell` VALUES ('33', 'ossoe1567349786', '4', '0', '0', '0.00', '0.00', '1.00', '7180.00', '', '', '0', '0', '1,1,1,1,1,1,1', '1567349786', '2', '', '1', '0', '0.00', '7.18', '0', '1000', '0', '2', '0');
INSERT INTO `think_ad_sell` VALUES ('34', 'tions1567350129', '4', '0', '0', '0.00', '0.00', '1.00', '1438.00', '', '', '0', '0', '1,1,1,1,1,1,1', '1567350129', '2', '', '1', '0', '0.00', '7.19', '0', '200', '0', '2', '0');
INSERT INTO `think_ad_sell` VALUES ('35', 'tuvqg1567419651', '4', '0', '0', '0.00', '0.00', '1.00', '719.00', '2', '', '0', '0', '1,1,1,1,1,1,1', '1567419651', '2', '', '1', '0', '0.00', '7.19', '0', '100', '2', '2', '0');
INSERT INTO `think_ad_sell` VALUES ('36', 'zyvco1567420813', '4', '0', '0', '0.00', '0.00', '1.00', '7190.00', '2', '', '0', '0', '1,1,1,1,1,1,1', '1567420813', '2', '', '1', '0', '0.00', '7.19', '0', '1000', '2', '2', '0');
INSERT INTO `think_ad_sell` VALUES ('37', 'myzna1567420904', '2', '0', '0', '0.00', '0.00', '1.00', '7190.00', '', '', '0', '0', '1,1,1,1,1,1,1', '1567420904', '2', '', '1', '0', '0.00', '7.19', '0', '1000', '0', '1', '0');
INSERT INTO `think_ad_sell` VALUES ('38', 'ppdpc1567421230', '2', '0', '0', '0.00', '0.00', '1.00', '7190.00', '', '', '0', '0', '1,1,1,1,1,1,1', '1567421230', '2', '', '1', '0', '0.00', '7.19', '0', '1000', '0', '1', '0');
INSERT INTO `think_ad_sell` VALUES ('39', 'mhbon1567421389', '2', '0', '0', '0.00', '0.00', '1.00', '7190.00', '', '', '0', '0', '1,1,1,1,1,1,1', '1567421389', '2', '', '1', '0', '0.00', '7.19', '0', '1000', '0', '1', '0');
INSERT INTO `think_ad_sell` VALUES ('40', 'qdofd1567434738', '4', '0', '0', '0.00', '0.00', '1.00', '7180.00', '', '', '0', '0', '1,1,1,1,1,1,1', '1567434738', '2', '', '1', '0', '0.00', '7.18', '0', '1000', '2', '0', '0');
INSERT INTO `think_ad_sell` VALUES ('41', 'xavmy1568354864', '4', '0', '0', '0.00', '0.00', '1.00', '7010.00', '', '', '0', '0', '1,1,1,1,1,1,1', '1568354864', '2', '', '1', '0', '0.00', '7.01', '0', '1000', '2', '0', '0');
INSERT INTO `think_ad_sell` VALUES ('42', 'kxfbr1568355707', '4', '0', '0', '0.00', '0.00', '1.00', '7010.00', '', '', '0', '0', '1,1,1,1,1,1,1', '1568355707', '2', '', '1', '0', '0.00', '7.01', '0', '1000', '2', '2', '0');
INSERT INTO `think_ad_sell` VALUES ('43', 'husse1568355884', '4', '0', '0', '0.00', '0.00', '1.00', '7010.00', '', '', '0', '0', '1,1,1,1,1,1,1', '1568355884', '2', '', '1', '0', '0.00', '7.01', '0', '1000', '2', '0', '0');
INSERT INTO `think_ad_sell` VALUES ('44', 'nzuzu1568356017', '4', '0', '0', '0.00', '0.00', '1.00', '7010.00', '', '', '0', '0', '1,1,1,1,1,1,1', '1568356017', '2', '', '1', '0', '0.00', '7.01', '0', '1000', '0', '2', '0');
INSERT INTO `think_ad_sell` VALUES ('45', 'saioa1568356214', '4', '0', '0', '0.00', '0.00', '1.00', '7010.00', '', '', '0', '0', '1,1,1,1,1,1,1', '1568356214', '2', '', '1', '0', '0.00', '7.01', '0', '1000', '2', '0', '0');

-- -----------------------------
-- Table structure for `think_address`
-- -----------------------------
DROP TABLE IF EXISTS `think_address`;
CREATE TABLE `think_address` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `uid` int(10) DEFAULT NULL COMMENT '用户ID',
  `address` varchar(255) DEFAULT NULL COMMENT '地址',
  `status` tinyint(1) DEFAULT '0' COMMENT '状态:0未分配1已分配',
  `addtime` varchar(60) DEFAULT NULL COMMENT '添加时间',
  `note` varchar(255) DEFAULT NULL COMMENT '备注',
  `type` varchar(10) DEFAULT NULL COMMENT '钱包类型,btc和eth',
  `password` varchar(255) DEFAULT NULL COMMENT 'ETH钱包地址密码',
  `privatekey` varchar(255) DEFAULT NULL COMMENT '私钥',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=31 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `think_address`
-- -----------------------------
INSERT INTO `think_address` VALUES ('1', '4', '0x6d8ffc3c999de02900a7e13a58ee5472b0029a59', '1', '1567311649', '', 'eth', '', 'b27042bfe4a8e617388c0a259f275d0415acd8d0f904f352de1078fc0aec5f1d');
INSERT INTO `think_address` VALUES ('2', '5', '0x0f491c4675a84d7c40e538b1737568ae48d40f21', '1', '1567311651', '', 'eth', '', '17523262c573f3eb2285a9ea302665cd7db72460ff043b670421b214409cb6fa');
INSERT INTO `think_address` VALUES ('3', '6', '0xd8865a9f321e8241629afca7e447d89b1937f11b', '1', '1567311651', '', 'eth', '', '5ecb0dc4657947daf6af0a0d13dd4516ec8d94356fba19f9a0f023d2dbf485a6');
INSERT INTO `think_address` VALUES ('4', '', '0x315d9ad61efb1a438ecfa06247f710fcb980567b', '0', '1567311652', '', 'eth', '', '7b6ff5d9872e2029d7f7766beb89a20c89ff459c40d1dcbab4dde0dfcc627f1e');
INSERT INTO `think_address` VALUES ('5', '', '0xe996036921340f77df97e15f0a4b628e6139362d', '0', '1567311653', '', 'eth', '', 'b7eb779515022b6b7fab4df3cfe4e089976cefc2770280343c86c340b58f5c7f');
INSERT INTO `think_address` VALUES ('6', '', '0x032280dd29514a79fe9144220d1330e414a2f8ab', '0', '1567311654', '', 'eth', '', 'd6b7ac271d9e138940af38f12d5025e539f05f3c01a66050a42acf117b27c4ae');
INSERT INTO `think_address` VALUES ('7', '', '0x989bc6f55132b51e6d751d65fbba79007f37b23a', '0', '1567311654', '', 'eth', '', '5397603926eef49b1e48dfc6884d106322bb8a8dbdc5d168628c5dd4e42c2802');
INSERT INTO `think_address` VALUES ('8', '', '0xe415a6c98b310a86718d276dbfeb6861ce688c7a', '0', '1567311656', '', 'eth', '', '3630a74f66be4703121914c23a769739e359e932a1ad1ada494ff1f2c57c4f52');
INSERT INTO `think_address` VALUES ('9', '', '0xac3ac01d810a3f4349f6c59a8e51be72bc6eb4d4', '0', '1567311656', '', 'eth', '', 'b6b49074e7f2e0120d3ee215289d0065c4ccfb247625d7366d2aede1d1e51f36');
INSERT INTO `think_address` VALUES ('10', '', '0xc2ace25cee8954599b1db87924b130febf8b2392', '0', '1567311657', '', 'eth', '', 'c07f0b1439f5d10a849f310a135a65c60f26770bb5409f1e2149ff8b6a677c82');
INSERT INTO `think_address` VALUES ('11', '', '0xe31e2b2bd7826705e7d419c7f6e54086ed3a4f54', '0', '1567311658', '', 'eth', '', 'fe771d36d309488310a81d6eb851c9a189b8d679459c546db6c00415a185dd0b');
INSERT INTO `think_address` VALUES ('12', '', '0xbe376acb37d1b0371d43545deb9e3f06adfa6ab2', '0', '1567311658', '', 'eth', '', '0ceb381fff4493b033c04e7d612a288270e157c0c75beb0b6f8ad7162c331751');
INSERT INTO `think_address` VALUES ('13', '', '0x1a8c365be3f8e71100e44883dbd09d191160fd39', '0', '1567311659', '', 'eth', '', 'b64b2507518577f040cecdfe681a0694e62c3a4067fa0195d51a4b81a686557f');
INSERT INTO `think_address` VALUES ('14', '', '0xd5e0a9b34c5d9fe93c88af4ee29baf77503517b0', '0', '1567311660', '', 'eth', '', '287f5fba5dd5e62b801522b2ae8b445e62cc689b968974e95c3d3e9b93cf7eb2');
INSERT INTO `think_address` VALUES ('15', '', '0xcfea74ba109b1c303a3c8a8926e6af0b738d0c45', '0', '1567311661', '', 'eth', '', '6c8c99164befcebee0bab72a5b43e7daed177a2bd378690207c20babf65491e1');
INSERT INTO `think_address` VALUES ('16', '', '0x6f641e0e91f963f91cca0f2e7d01e7a5a76f4527', '0', '1567311662', '', 'eth', '', '88446d31e44e2ce2f83fcd6999d4bc7dfdcdd52778c3a49f00fda9eb3d56f2e8');
INSERT INTO `think_address` VALUES ('17', '', '0xd6c57b1795cd16495a81e0ca99c0e8c4523c62a8', '0', '1567311663', '', 'eth', '', '7177f97482d40f267ad9cb67769d305a9c847c672dbd7c54b33e81b0498bee8a');
INSERT INTO `think_address` VALUES ('18', '', '0x764857fa1dc98fad0ab92c4346d1255fc6177941', '0', '1567311664', '', 'eth', '', '9c53dfc5ddb95a1bba0d4998dd0f4e0508eb1943e113faa201e0caeef91c662c');
INSERT INTO `think_address` VALUES ('19', '', '0x40e5e7b94880f2ffaf342308fd450cf2f0fad6d5', '0', '1567311665', '', 'eth', '', '2e8845e75b429dc239db3aa8e8c728b15a785f65cf9610d9267fe97a47830ccc');
INSERT INTO `think_address` VALUES ('20', '', '0xe5e6a492e6aa9b3df728ebc9ad615b500d2423e7', '0', '1567311666', '', 'eth', '', '64256b43a67063a6a99493c7398f69634ef957ef5030cbc586714fe3964811eb');
INSERT INTO `think_address` VALUES ('21', '', '0x24899ed04388bbd57f23a49ec23b1b78c832a058', '0', '1567311667', '', 'eth', '', '3f3c9cd76f21929b681387aa7e161334cc64d529a703c9d4c6091feda8494a8c');
INSERT INTO `think_address` VALUES ('22', '', '0x0935a2f33ec91652af9ed2ca4bc0cef56e2f6382', '0', '1567311667', '', 'eth', '', 'b6704311d55c35efd69e07db4be55b7125b4c475ef3f130963a861a4e0bc5f1b');
INSERT INTO `think_address` VALUES ('23', '', '0x3670045f4eedc70682e748ba694a3bd4be23d13f', '0', '1567311668', '', 'eth', '', 'cd826378b6d6815d8b2a86ef37c458504e44048740d45ad7be1ef8f4b6084a78');
INSERT INTO `think_address` VALUES ('24', '', '0x4cd63e0d7d88d86a163401f5e349433aedba9184', '0', '1567311669', '', 'eth', '', '77a91b7e2a831441798260306600e58d14cf780988c600c6933d8fe14614419a');
INSERT INTO `think_address` VALUES ('25', '', '0xca60eb582a2367927cfaac4dcb79b4198297c017', '0', '1567311670', '', 'eth', '', 'ff04f9c0a4c8282e790d3ccf541af037b72616649d6f2222b6048ab652d01979');
INSERT INTO `think_address` VALUES ('26', '', '0x6fe58072a0d4b786d22377c7baeba783adc8d32e', '0', '1567311671', '', 'eth', '', 'be3d7142df3974daa701d02c5a042485ff20c29c394a4685f15d2719f1d00911');
INSERT INTO `think_address` VALUES ('27', '', '0x5c4ea35230eae94d105c5b597bf7ca1a1c843333', '0', '1567311672', '', 'eth', '', '72ef6f45adef7035d2317c85a61ae2a8686ece24fe9b3d8d6d1562a278571c34');
INSERT INTO `think_address` VALUES ('28', '', '0x860da3b0aa7515ec6b97dfeb9c41d7b585536542', '0', '1567311673', '', 'eth', '', 'ab6fc50779933b6efdccefe793edfc9352a5a9303367baea10b8fa8fc834952e');
INSERT INTO `think_address` VALUES ('29', '', '0x13254b63c0228c81915c1ddc00f180eec920ab03', '0', '1567311674', '', 'eth', '', 'eb8b1619cade79c00b053091bd76a4c1043d6c02a44edcb437f7abb44acca5e8');
INSERT INTO `think_address` VALUES ('30', '', '0xad2f9b333a69a6ce2fbc0c4f6e3d48a9cd093297', '0', '1567311676', '', 'eth', '', '0d0d4a2a0e5fcba36dc6be4c5902b0a2bbdee2d125d66de5a79f4a8caf5b27be');

-- -----------------------------
-- Table structure for `think_admin`
-- -----------------------------
DROP TABLE IF EXISTS `think_admin`;
CREATE TABLE `think_admin` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(20) COLLATE utf8_bin DEFAULT '' COMMENT '用户名',
  `password` varchar(32) COLLATE utf8_bin DEFAULT '' COMMENT '密码',
  `portrait` varchar(100) COLLATE utf8_bin DEFAULT NULL COMMENT '头像',
  `loginnum` int(11) DEFAULT '0' COMMENT '登陆次数',
  `last_login_ip` varchar(255) COLLATE utf8_bin DEFAULT '' COMMENT '最后登录IP',
  `last_login_time` int(11) DEFAULT '0' COMMENT '最后登录时间',
  `real_name` varchar(20) COLLATE utf8_bin DEFAULT '' COMMENT '真实姓名',
  `status` int(1) DEFAULT '0' COMMENT '状态',
  `groupid` int(11) DEFAULT '1' COMMENT '用户角色id',
  `token` varchar(32) COLLATE utf8_bin DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=30 DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

-- -----------------------------
-- Records of `think_admin`
-- -----------------------------
INSERT INTO `think_admin` VALUES ('1', 'admin', 'bcdc0b231056d9acf93c00c58ddab31b', '20161122\\admin.jpg', '504', '183.31.244.210', '1568628021', 'admin', '1', '1', '41a8f96765efb4db193e5932bf353acc');
INSERT INTO `think_admin` VALUES ('29', '1', '31605938c0c04ff6c96fb7d65e9cf3fa', '', '2', '127.0.0.1', '1567234646', '1', '1', '23', '6fd73eb569c520f42b3478fe5cfbc7c0');

-- -----------------------------
-- Table structure for `think_agent_reward`
-- -----------------------------
DROP TABLE IF EXISTS `think_agent_reward`;
CREATE TABLE `think_agent_reward` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `uid` int(11) DEFAULT NULL,
  `duid` int(11) DEFAULT NULL,
  `amount` decimal(20,8) DEFAULT '0.00000000',
  `type` tinyint(4) DEFAULT '0' COMMENT '0:商户提币，1：用户提币，2：用户充值',
  `create_time` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


-- -----------------------------
-- Table structure for `think_article`
-- -----------------------------
DROP TABLE IF EXISTS `think_article`;
CREATE TABLE `think_article` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '文章逻辑ID',
  `title` varchar(128) NOT NULL COMMENT '文章标题',
  `cate_id` int(11) NOT NULL DEFAULT '1' COMMENT '文章类别',
  `photo` varchar(64) DEFAULT '' COMMENT '文章图片',
  `remark` varchar(256) DEFAULT '' COMMENT '文章描述',
  `keyword` varchar(32) DEFAULT '' COMMENT '文章关键字',
  `content` text NOT NULL COMMENT '文章内容',
  `views` int(11) NOT NULL DEFAULT '1' COMMENT '浏览量',
  `status` tinyint(1) DEFAULT NULL,
  `type` int(1) NOT NULL DEFAULT '1' COMMENT '文章类型',
  `is_tui` int(1) DEFAULT '0' COMMENT '是否推荐',
  `from` varchar(16) NOT NULL DEFAULT '' COMMENT '来源',
  `writer` varchar(64) NOT NULL COMMENT '作者',
  `ip` varchar(16) NOT NULL,
  `create_time` int(11) NOT NULL COMMENT '创建时间',
  `update_time` int(11) DEFAULT NULL COMMENT '更新时间',
  PRIMARY KEY (`id`),
  KEY `a_title` (`title`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COMMENT='文章表';

-- -----------------------------
-- Records of `think_article`
-- -----------------------------
INSERT INTO `think_article` VALUES ('1', '测试公告', '23', '', '123', '123', '<p>测试公告</p>', '1', '1', '1', '1', '', '', '', '1566197983', '1566197983');

-- -----------------------------
-- Table structure for `think_article_cate`
-- -----------------------------
DROP TABLE IF EXISTS `think_article_cate`;
CREATE TABLE `think_article_cate` (
  `id` smallint(5) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(32) DEFAULT NULL COMMENT '分类名称',
  `orderby` varchar(10) DEFAULT '100' COMMENT '排序',
  `create_time` int(11) DEFAULT NULL COMMENT '创建时间',
  `update_time` int(11) DEFAULT NULL COMMENT '更新时间',
  `status` tinyint(1) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=25 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `think_article_cate`
-- -----------------------------
INSERT INTO `think_article_cate` VALUES ('24', '使用教程', '2', '1556202561', '1556202561', '1');
INSERT INTO `think_article_cate` VALUES ('23', '最新公告', '1', '1556202546', '1556202546', '0');

-- -----------------------------
-- Table structure for `think_auth_group`
-- -----------------------------
DROP TABLE IF EXISTS `think_auth_group`;
CREATE TABLE `think_auth_group` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `title` char(100) NOT NULL DEFAULT '',
  `status` tinyint(1) NOT NULL DEFAULT '1',
  `rules` text NOT NULL,
  `create_time` int(11) DEFAULT NULL,
  `update_time` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=24 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `think_auth_group`
-- -----------------------------
INSERT INTO `think_auth_group` VALUES ('1', '超级管理员', '1', '', '1446535750', '1446535750');
INSERT INTO `think_auth_group` VALUES ('4', '系统测试员', '1', '1,2,9,10,11,12,3,30,31,32,33,34,4,35,36,37,38,39,61,62,63,92,93,115,5,6,7,8,27,28,29,13,14,22,24,25,40,41,42,43,26,44,45,46,47,48,49,50,51,52,53,54,55,56,57,58,70,71,72,73,74,80,75,76,77,78,79,84,85,88,89,90,107,86,87,101,95,96,97,98,99,100,103,102,94,104,108,105,106,109,110,111,112,113,114', '1446535750', '1566183317');
INSERT INTO `think_auth_group` VALUES ('23', '客服', '1', '84,91,119,120,121,122,123,124', '1567178730', '1567234600');

-- -----------------------------
-- Table structure for `think_auth_group_access`
-- -----------------------------
DROP TABLE IF EXISTS `think_auth_group_access`;
CREATE TABLE `think_auth_group_access` (
  `uid` mediumint(8) unsigned NOT NULL,
  `group_id` mediumint(8) unsigned NOT NULL,
  UNIQUE KEY `uid_group_id` (`uid`,`group_id`),
  KEY `uid` (`uid`),
  KEY `group_id` (`group_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `think_auth_group_access`
-- -----------------------------
INSERT INTO `think_auth_group_access` VALUES ('1', '4');
INSERT INTO `think_auth_group_access` VALUES ('21', '4');
INSERT INTO `think_auth_group_access` VALUES ('22', '4');
INSERT INTO `think_auth_group_access` VALUES ('23', '4');
INSERT INTO `think_auth_group_access` VALUES ('24', '4');
INSERT INTO `think_auth_group_access` VALUES ('25', '4');
INSERT INTO `think_auth_group_access` VALUES ('26', '4');
INSERT INTO `think_auth_group_access` VALUES ('28', '4');
INSERT INTO `think_auth_group_access` VALUES ('29', '23');

-- -----------------------------
-- Table structure for `think_auth_rule`
-- -----------------------------
DROP TABLE IF EXISTS `think_auth_rule`;
CREATE TABLE `think_auth_rule` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` char(80) NOT NULL DEFAULT '',
  `title` char(20) NOT NULL DEFAULT '',
  `type` tinyint(1) NOT NULL DEFAULT '1',
  `status` tinyint(1) NOT NULL DEFAULT '1',
  `css` varchar(20) NOT NULL COMMENT '样式',
  `condition` char(100) NOT NULL DEFAULT '',
  `pid` int(11) NOT NULL DEFAULT '0' COMMENT '父栏目ID',
  `sort` int(11) NOT NULL DEFAULT '0' COMMENT '排序',
  `create_time` int(11) NOT NULL DEFAULT '0' COMMENT '添加时间',
  `update_time` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=127 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `think_auth_rule`
-- -----------------------------
INSERT INTO `think_auth_rule` VALUES ('1', '#', '系统管理', '1', '1', 'fa fa-gear', '', '0', '1', '1446535750', '1477312169');
INSERT INTO `think_auth_rule` VALUES ('2', 'admin/user/index', '用户管理', '1', '1', '', '', '1', '10', '1446535750', '1477312169');
INSERT INTO `think_auth_rule` VALUES ('3', 'admin/role/index', '角色管理', '1', '1', '', '', '1', '20', '1446535750', '1477312169');
INSERT INTO `think_auth_rule` VALUES ('4', 'admin/menu/index', '菜单管理', '1', '1', '', '', '1', '30', '1446535750', '1477312169');
INSERT INTO `think_auth_rule` VALUES ('5', '#', '数据库管理', '1', '1', 'fa fa-database', '', '0', '7', '1446535750', '1477312169');
INSERT INTO `think_auth_rule` VALUES ('6', 'admin/data/index', '数据库备份', '1', '1', '', '', '5', '50', '1446535750', '1477312169');
INSERT INTO `think_auth_rule` VALUES ('7', 'admin/data/optimize', '优化表', '1', '1', '', '', '6', '50', '1477312169', '1477312169');
INSERT INTO `think_auth_rule` VALUES ('8', 'admin/data/repair', '修复表', '1', '1', '', '', '6', '50', '1477312169', '1477312169');
INSERT INTO `think_auth_rule` VALUES ('9', 'admin/user/add', '添加用户', '1', '1', '', '', '2', '50', '1477312169', '1477312169');
INSERT INTO `think_auth_rule` VALUES ('10', 'admin/user/edit', '编辑用户', '1', '1', '', '', '2', '50', '1477312169', '1477312169');
INSERT INTO `think_auth_rule` VALUES ('11', 'admin/user/del', '删除用户', '1', '1', '', '', '2', '50', '1477312169', '1477312169');
INSERT INTO `think_auth_rule` VALUES ('12', 'admin/user/state', '用户状态', '1', '1', '', '', '2', '20', '1477312169', '1477312169');
INSERT INTO `think_auth_rule` VALUES ('13', '#', '日志管理', '1', '1', 'fa fa-tasks', '', '0', '6', '1477312169', '1477312169');
INSERT INTO `think_auth_rule` VALUES ('14', 'admin/log/operate_log', '行为日志', '1', '1', '', '', '13', '50', '1477312169', '1477312169');
INSERT INTO `think_auth_rule` VALUES ('22', 'admin/log/del_log', '删除日志', '1', '1', '', '', '14', '50', '1477312169', '1477316778');
INSERT INTO `think_auth_rule` VALUES ('24', '#', '文章管理', '1', '1', 'fa fa-paste', '', '0', '4', '1477312169', '1477312169');
INSERT INTO `think_auth_rule` VALUES ('25', 'admin/article/index_cate', '文章分类', '1', '1', '', '', '24', '10', '1477312260', '1477312260');
INSERT INTO `think_auth_rule` VALUES ('26', 'admin/article/index', '文章列表', '1', '1', '', '', '24', '20', '1477312333', '1477312333');
INSERT INTO `think_auth_rule` VALUES ('27', 'admin/data/import', '数据库还原', '1', '1', '', '', '5', '50', '1477639870', '1477639870');
INSERT INTO `think_auth_rule` VALUES ('28', 'admin/data/revert', '还原', '1', '1', '', '', '27', '50', '1477639972', '1477639972');
INSERT INTO `think_auth_rule` VALUES ('29', 'admin/data/del', '删除', '1', '1', '', '', '27', '50', '1477640011', '1477640011');
INSERT INTO `think_auth_rule` VALUES ('30', 'admin/role/add', '添加角色', '1', '1', '', '', '3', '50', '1477640011', '1477640011');
INSERT INTO `think_auth_rule` VALUES ('31', 'admin/role/edit', '编辑角色', '1', '1', '', '', '3', '50', '1477640011', '1477640011');
INSERT INTO `think_auth_rule` VALUES ('32', 'admin/role/del', '删除角色', '1', '1', '', '', '3', '50', '1477640011', '1477640011');
INSERT INTO `think_auth_rule` VALUES ('33', 'admin/role/state', '角色状态', '1', '1', '', '', '3', '50', '1477640011', '1477640011');
INSERT INTO `think_auth_rule` VALUES ('34', 'admin/role/giveAccess', '权限分配', '1', '1', '', '', '3', '50', '1477640011', '1477640011');
INSERT INTO `think_auth_rule` VALUES ('35', 'admin/menu/add', '添加菜单', '1', '1', '', '', '4', '50', '1477640011', '147740011');
INSERT INTO `think_auth_rule` VALUES ('36', 'admin/menu/edit', '编辑菜单', '1', '1', '', '', '4', '50', '1477640011', '1477640011');
INSERT INTO `think_auth_rule` VALUES ('37', 'admin/menu/del', '删除菜单', '1', '1', '', '', '4', '50', '1477640011', '1477640011');
INSERT INTO `think_auth_rule` VALUES ('38', 'admin/menu/state', '菜单状态', '1', '1', '', '', '4', '50', '1477640011', '1477640011');
INSERT INTO `think_auth_rule` VALUES ('39', 'admin/menu/ruleOrderBy', '菜单排序', '1', '1', '', '', '4', '50', '1477640011', '1477640011');
INSERT INTO `think_auth_rule` VALUES ('40', 'admin/article/add_cate', '添加分类', '1', '1', '', '', '25', '50', '1477640011', '1477640011');
INSERT INTO `think_auth_rule` VALUES ('41', 'admin/article/edit_cate', '编辑分类', '1', '1', '', '', '25', '50', '1477640011', '1477640011');
INSERT INTO `think_auth_rule` VALUES ('42', 'admin/article/del_cate', '删除分类', '1', '1', '', '', '25', '50', '1477640011', '1477640011');
INSERT INTO `think_auth_rule` VALUES ('43', 'admin/article/cate_state', '分类状态', '1', '1', '', '', '25', '50', '1477640011', '1477640011');
INSERT INTO `think_auth_rule` VALUES ('44', 'admin/article/add_article', '添加文章', '1', '1', '', '', '26', '50', '1477640011', '1477640011');
INSERT INTO `think_auth_rule` VALUES ('45', 'admin/article/edit_article', '编辑文章', '1', '1', '', '', '26', '50', '1477640011', '1477640011');
INSERT INTO `think_auth_rule` VALUES ('46', 'admin/article/del_article', '删除文章', '1', '1', '', '', '26', '50', '1477640011', '1477640011');
INSERT INTO `think_auth_rule` VALUES ('47', 'admin/article/article_state', '文章状态', '1', '1', '', '', '26', '50', '1477640011', '1477640011');
INSERT INTO `think_auth_rule` VALUES ('48', '#', '广告管理', '1', '0', 'fa fa-image', '', '0', '5', '1477640011', '1477640011');
INSERT INTO `think_auth_rule` VALUES ('49', 'admin/banner/index_position', '广告位', '1', '1', '', '', '48', '10', '1477640011', '1477640011');
INSERT INTO `think_auth_rule` VALUES ('50', 'admin/banner/add_position', '添加广告位', '1', '1', '', '', '49', '50', '1477640011', '1477640011');
INSERT INTO `think_auth_rule` VALUES ('51', 'admin/banneredit_position', '编辑广告位', '1', '1', '', '', '49', '50', '1477640011', '1477640011');
INSERT INTO `think_auth_rule` VALUES ('52', 'admin/banner/del_position', '删除广告位', '1', '1', '', '', '49', '50', '1477640011', '1477640011');
INSERT INTO `think_auth_rule` VALUES ('53', 'admin/banner/position_state', '广告位状态', '1', '1', '', '', '49', '50', '1477640011', '1477640011');
INSERT INTO `think_auth_rule` VALUES ('54', 'admin/banner/index', '广告列表', '1', '1', '', '', '48', '20', '1477640011', '1477640011');
INSERT INTO `think_auth_rule` VALUES ('55', 'admin/banner/add', '添加广告', '1', '1', '', '', '54', '50', '1477640011', '1477640011');
INSERT INTO `think_auth_rule` VALUES ('56', 'admin/banner/edit', '编辑广告', '1', '1', '', '', '54', '50', '1477640011', '1477640011');
INSERT INTO `think_auth_rule` VALUES ('57', 'admin/banner/del', '删除广告', '1', '1', '', '', '54', '50', '1477640011', '1477640011');
INSERT INTO `think_auth_rule` VALUES ('58', 'admin/banner/state', '广告状态', '1', '1', '', '', '54', '50', '1477640011', '1477640011');
INSERT INTO `think_auth_rule` VALUES ('61', 'admin/config/index', '配置管理', '1', '1', '', '', '1', '50', '1479908607', '1479908607');
INSERT INTO `think_auth_rule` VALUES ('62', 'admin/config/index', '配置列表', '1', '1', '', '', '61', '50', '1479908607', '1487943813');
INSERT INTO `think_auth_rule` VALUES ('63', 'admin/config/save', '保存配置', '1', '1', '', '', '61', '50', '1479908607', '1487943831');
INSERT INTO `think_auth_rule` VALUES ('70', '#', '会员管理', '1', '0', 'fa fa-users', '', '0', '3', '1484103066', '1484103066');
INSERT INTO `think_auth_rule` VALUES ('72', 'admin/member/add_group', '添加会员组', '1', '1', '', '', '71', '50', '1484103304', '1484103304');
INSERT INTO `think_auth_rule` VALUES ('71', 'admin/member/group', '会员组', '1', '1', '', '', '70', '10', '1484103304', '1484103304');
INSERT INTO `think_auth_rule` VALUES ('73', 'admin/member/edit_group', '编辑会员组', '1', '1', '', '', '71', '50', '1484103304', '1484103304');
INSERT INTO `think_auth_rule` VALUES ('74', 'admin/member/del_group', '删除会员组', '1', '1', '', '', '71', '50', '1484103304', '1484103304');
INSERT INTO `think_auth_rule` VALUES ('75', 'admin/member/index', '会员列表', '1', '1', '', '', '70', '20', '1484103304', '1484103304');
INSERT INTO `think_auth_rule` VALUES ('76', 'admin/member/add_member', '添加会员', '1', '1', '', '', '75', '50', '1484103304', '1484103304');
INSERT INTO `think_auth_rule` VALUES ('77', 'admin/member/edit_member', '编辑会员', '1', '1', '', '', '75', '50', '1484103304', '1484103304');
INSERT INTO `think_auth_rule` VALUES ('78', 'admin/member/del_member', '删除会员', '1', '1', '', '', '75', '50', '1484103304', '1484103304');
INSERT INTO `think_auth_rule` VALUES ('79', 'admin/member/member_status', '会员状态', '1', '1', '', '', '75', '50', '1484103304', '1487937671');
INSERT INTO `think_auth_rule` VALUES ('80', 'admin/member/group_status', '会员组状态', '1', '1', '', '', '71', '50', '1484103304', '1484103304');
INSERT INTO `think_auth_rule` VALUES ('84', '#', '商户管理', '1', '1', 'fa fa-user', '', '0', '2', '1542891863', '1542892118');
INSERT INTO `think_auth_rule` VALUES ('85', 'admin/merchant/tibi', '商户提币列表', '1', '0', '', '', '84', '50', '1542891863', '1542892118');
INSERT INTO `think_auth_rule` VALUES ('86', '#', '问题管理', '1', '1', 'fa fa-comment', '', '0', '5', '1543030476', '1543030476');
INSERT INTO `think_auth_rule` VALUES ('87', 'admin/message/index', '问题列表', '1', '1', '', '', '86', '50', '1543030515', '1543030515');
INSERT INTO `think_auth_rule` VALUES ('88', 'admin/merchant/address', 'USDT地址列表', '1', '1', '', '', '84', '49', '1543063416', '1543063416');
INSERT INTO `think_auth_rule` VALUES ('89', 'admin/merchant/withdrawlist', '用户提币列表', '1', '1', '', '', '84', '50', '1543063942', '1543063942');
INSERT INTO `think_auth_rule` VALUES ('90', 'admin/merchant/rechargelist', '用户充值列表', '1', '0', '', '', '84', '50', '1543066579', '1543066579');
INSERT INTO `think_auth_rule` VALUES ('91', 'admin/merchant/index?reg_type=1', '商户列表', '1', '1', '', '', '84', '48', '1543068278', '1543068278');
INSERT INTO `think_auth_rule` VALUES ('92', 'admin/merchant/usdtlog', 'USDT更新记录', '1', '1', '', '', '1', '51', '1446535750', '1566021721');
INSERT INTO `think_auth_rule` VALUES ('93', 'admin/merchant/btclog', 'BTC更新记录', '1', '1', '', '', '1', '51', '1446535750', '1446535750');
INSERT INTO `think_auth_rule` VALUES ('94', 'admin/merchant/agentreward', '代理奖励', '1', '1', '', '', '102', '49', '1543066579', '1543066579');
INSERT INTO `think_auth_rule` VALUES ('95', 'admin/merchant/adlist', '出售广告列表', '1', '1', '', '', '101', '52', '1446535750', '1446535750');
INSERT INTO `think_auth_rule` VALUES ('96', 'admin/merchant/orderlist', '匹配订单列表', '1', '1', '', '', '101', '53', '1446535750', '1446535750');
INSERT INTO `think_auth_rule` VALUES ('97', 'admin/merchant/traderrecharge', '交易员充币列表', '1', '1', '', '', '101', '51', '1446535750', '1446535750');
INSERT INTO `think_auth_rule` VALUES ('98', 'admin/merchant/buyadlist', '交易员求购广告', '1', '1', '', '', '101', '54', '1446535750', '1446535750');
INSERT INTO `think_auth_rule` VALUES ('99', 'admin/merchant/orderlistbuy', '交易员求购订单', '1', '1', '', '', '101', '54', '1446535750', '1446535750');
INSERT INTO `think_auth_rule` VALUES ('100', 'admin/merchant/traderreward', '交易员奖励', '1', '1', '', '', '101', '49', '1446535750', '1446535750');
INSERT INTO `think_auth_rule` VALUES ('101', '#', '承兑商管理', '1', '1', 'fa fa-user', '', '0', '3', '1446535750', '1446535750');
INSERT INTO `think_auth_rule` VALUES ('102', '#', '代理商管理', '1', '1', 'fa fa-user', '', '0', '4', '1446535750', '1446535750');
INSERT INTO `think_auth_rule` VALUES ('103', 'admin/merchant/index?reg_type=2', '承兑商列表', '1', '1', '', '', '101', '0', '1543066579', '1543066579');
INSERT INTO `think_auth_rule` VALUES ('104', 'admin/merchant/index?reg_type=3', '代理商列表', '1', '1', '', '', '102', '0', '1543066579', '1543066579');
INSERT INTO `think_auth_rule` VALUES ('105', '#', '交易管理', '1', '0', 'fa fa-image', '', '0', '3', '1555559364', '1555561185');
INSERT INTO `think_auth_rule` VALUES ('106', 'admin/merchant/orderlist', '盘口订单', '1', '0', ' Example of exchange', '', '105', '50', '1555559706', '1555559853');
INSERT INTO `think_auth_rule` VALUES ('107', 'admin/merchant/orderlistbuy?reg_type=1', '商户出售订单列表', '1', '1', '', '', '84', '52', '1446535750', '1446535750');
INSERT INTO `think_auth_rule` VALUES ('108', 'admin/merchant/orderlistbuy?reg_type=3', '代理商出售订单列表', '1', '1', '', '', '102', '2', '1446535750', '1446535750');
INSERT INTO `think_auth_rule` VALUES ('109', '#', '统计管理', '1', '1', 'fa fa-cube', '', '0', '7', '1446535750', '1446535750');
INSERT INTO `think_auth_rule` VALUES ('110', 'admin/merchant/statistics', '平台统计', '1', '1', '', '', '109', '0', '1446535750', '1446535750');
INSERT INTO `think_auth_rule` VALUES ('111', 'admin/merchant/merchantstatistics', '商户统计', '1', '1', '', '', '109', '0', '1446535750', '1446535750');
INSERT INTO `think_auth_rule` VALUES ('112', '#', '提币管理', '1', '1', 'fa fa-user', '', '0', '5', '1556181096', '1556181096');
INSERT INTO `think_auth_rule` VALUES ('113', 'admin/merchant/tibi', '管理提币', '1', '1', '', '', '112', '50', '1556181210', '1556181210');
INSERT INTO `think_auth_rule` VALUES ('114', 'admin/merchant/rechargelist', '盘口提币', '1', '1', '', '', '112', '50', '1556181295', '1556181295');
INSERT INTO `think_auth_rule` VALUES ('115', 'admin/merchant/log', '登录日志', '1', '1', '', '', '13', '70', '1556181210', '1556181210');
INSERT INTO `think_auth_rule` VALUES ('116', 'admin/log/financelog', '资金日志', '1', '1', 'fa fa-usd', '', '13', '50', '1566958834', '1566958834');
INSERT INTO `think_auth_rule` VALUES ('118', 'admin/merchant/addresslist', '钱包地址列表', '1', '1', '', '', '1', '50', '1566994828', '1566994828');
INSERT INTO `think_auth_rule` VALUES ('119', 'admin/merchant/merchant_check', '商户注册审核', '1', '1', '', '', '91', '50', '1567009697', '1567009697');
INSERT INTO `think_auth_rule` VALUES ('120', 'admin/merchant/merchant_agent_check', '代理审核', '1', '1', '', '', '91', '50', '1567009697', '1567009697');
INSERT INTO `think_auth_rule` VALUES ('121', 'admin/merchant/merchant_trader_check', '交易员审核', '1', '1', '', '', '91', '50', '1567009697', '1567009697');
INSERT INTO `think_auth_rule` VALUES ('122', 'admin/merchant/merchant_status', '更改会员状态', '1', '1', '', '', '91', '50', '1567009697', '1567009697');
INSERT INTO `think_auth_rule` VALUES ('123', 'admin/merchant/del_merchant', '删除会员', '1', '1', '', '', '91', '50', '1567009697', '1567009697');
INSERT INTO `think_auth_rule` VALUES ('124', 'admin/merchant/edit_merchant', '编辑会员', '1', '1', '', '', '91', '50', '1567009697', '1567009697');
INSERT INTO `think_auth_rule` VALUES ('125', 'admin/merchant/merchant_check', '承兑商注册审核', '1', '1', '', '', '103', '50', '1567009697', '1567009697');
INSERT INTO `think_auth_rule` VALUES ('126', 'admin/merchant/merchant_check', '代理注册审核', '1', '1', '', '', '104', '50', '1567009697', '1567009697');

-- -----------------------------
-- Table structure for `think_banner`
-- -----------------------------
DROP TABLE IF EXISTS `think_banner`;
CREATE TABLE `think_banner` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(64) DEFAULT NULL,
  `ad_position_id` varchar(10) DEFAULT NULL COMMENT '广告位',
  `link_url` varchar(128) DEFAULT NULL,
  `images` varchar(128) DEFAULT NULL,
  `start_date` date DEFAULT NULL COMMENT '开始时间',
  `end_date` date DEFAULT NULL COMMENT '结束时间',
  `status` tinyint(1) DEFAULT NULL COMMENT '状态',
  `closed` tinyint(1) DEFAULT '0',
  `orderby` tinyint(3) DEFAULT '100',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=53 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `think_banner`
-- -----------------------------
INSERT INTO `think_banner` VALUES ('52', '1', '25', '', '20190819/7fde9b834d7f727fd43caf06e6fc5432.png', '2019-08-19', '2019-08-20', '1', '0', '100');

-- -----------------------------
-- Table structure for `think_banner_position`
-- -----------------------------
DROP TABLE IF EXISTS `think_banner_position`;
CREATE TABLE `think_banner_position` (
  `id` smallint(5) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(32) DEFAULT NULL COMMENT '分类名称',
  `orderby` varchar(10) DEFAULT '100' COMMENT '排序',
  `create_time` int(11) DEFAULT NULL COMMENT '创建时间',
  `update_time` int(11) DEFAULT NULL COMMENT '更新时间',
  `status` tinyint(1) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=29 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `think_banner_position`
-- -----------------------------
INSERT INTO `think_banner_position` VALUES ('25', '首页banner', '10', '1502181832', '1502434196', '1');
INSERT INTO `think_banner_position` VALUES ('26', '6168', '11', '1502182772', '1502182772', '1');

-- -----------------------------
-- Table structure for `think_coin_log`
-- -----------------------------
DROP TABLE IF EXISTS `think_coin_log`;
CREATE TABLE `think_coin_log` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `admin_id` int(11) DEFAULT NULL,
  `balance` decimal(20,8) DEFAULT '0.00000000',
  `coin_type` tinyint(4) DEFAULT '0' COMMENT '0:usdt，1:btc',
  `create_time` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


-- -----------------------------
-- Table structure for `think_config`
-- -----------------------------
DROP TABLE IF EXISTS `think_config`;
CREATE TABLE `think_config` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '配置ID',
  `name` varchar(30) NOT NULL DEFAULT '' COMMENT '配置名称',
  `value` text COMMENT '配置值',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_name` (`name`)
) ENGINE=MyISAM AUTO_INCREMENT=65 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `think_config`
-- -----------------------------
INSERT INTO `think_config` VALUES ('1', 'web_site_title', 'FA5050');
INSERT INTO `think_config` VALUES ('2', 'web_site_description', '');
INSERT INTO `think_config` VALUES ('3', 'web_site_keyword', '');
INSERT INTO `think_config` VALUES ('4', 'web_site_icp', '');
INSERT INTO `think_config` VALUES ('5', 'web_site_cnzz', '');
INSERT INTO `think_config` VALUES ('6', 'web_site_copy', 'Copyright  2019  All rights reserved.');
INSERT INTO `think_config` VALUES ('7', 'web_site_close', '1');
INSERT INTO `think_config` VALUES ('8', 'list_rows', '20');
INSERT INTO `think_config` VALUES ('9', 'admin_allow_ip', '');
INSERT INTO `think_config` VALUES ('12', 'alisms_appkey', '');
INSERT INTO `think_config` VALUES ('13', 'alisms_appsecret', '');
INSERT INTO `think_config` VALUES ('14', 'alisms_signname', '');
INSERT INTO `think_config` VALUES ('15', 'logo', '20190901/e51cc260c53245891bfa550d58e78b90.png');
INSERT INTO `think_config` VALUES ('16', 'merchant_tibi_fee', '3');
INSERT INTO `think_config` VALUES ('17', 'user_tibi_fee', '');
INSERT INTO `think_config` VALUES ('18', 'user_recharge_fee', '');
INSERT INTO `think_config` VALUES ('19', 'merchant_tibi_max', '10000');
INSERT INTO `think_config` VALUES ('20', 'merchant_tibi_min', '100');
INSERT INTO `think_config` VALUES ('21', 'usdt_confirms', '6');
INSERT INTO `think_config` VALUES ('22', 'agent_tibi_fee', '0.2');
INSERT INTO `think_config` VALUES ('23', 'agent_withdraw_fee', '0.2');
INSERT INTO `think_config` VALUES ('24', 'agent_recharge_fee', '0.3');
INSERT INTO `think_config` VALUES ('25', 'usdt_price_way', '2');
INSERT INTO `think_config` VALUES ('26', 'usdt_price_min', '6');
INSERT INTO `think_config` VALUES ('27', 'usdt_price_max', '8');
INSERT INTO `think_config` VALUES ('28', 'moble_url', 'http://utf8.sms.webchinese.cn');
INSERT INTO `think_config` VALUES ('29', 'moble_user', 'authcn');
INSERT INTO `think_config` VALUES ('30', 'moble_pwd', 'd41d8cd98f00b204e9801222a');
INSERT INTO `think_config` VALUES ('31', 'send_message_content', '您的广告买家已付款，数量：{usdt}，请及时处理。');
INSERT INTO `think_config` VALUES ('32', 'trader_merchant_fee', '3');
INSERT INTO `think_config` VALUES ('33', 'usdt_price_way_buy', '2');
INSERT INTO `think_config` VALUES ('34', 'usdt_price_min_buy', '6');
INSERT INTO `think_config` VALUES ('35', 'usdt_buy_trader_fee', '0.2');
INSERT INTO `think_config` VALUES ('36', 'usdt_buy_merchant_fee', '0.05');
INSERT INTO `think_config` VALUES ('37', 'usdt_price_max_buy', '8');
INSERT INTO `think_config` VALUES ('38', 'trader_platform_get', '1');
INSERT INTO `think_config` VALUES ('39', 'reg_invite_on', '0');
INSERT INTO `think_config` VALUES ('40', 'usdt_pwd', 'zrCzPx8ozSfWjJqN4iQ81');
INSERT INTO `think_config` VALUES ('41', 'usdt_fee', '0');
INSERT INTO `think_config` VALUES ('43', 'ad_down_remain_amount', '10');
INSERT INTO `think_config` VALUES ('44', 'trader_parent_get', '5');
INSERT INTO `think_config` VALUES ('45', 'trader_merchant_parent_get', '3');
INSERT INTO `think_config` VALUES ('46', 'trader_pp_max_unfinished_order', '100');
INSERT INTO `think_config` VALUES ('47', 'rpc_user', 'usdtuser');
INSERT INTO `think_config` VALUES ('48', 'rpc_pwd', '123123123');
INSERT INTO `think_config` VALUES ('49', 'rpc_url', '127.0.0.1');
INSERT INTO `think_config` VALUES ('50', 'rpc_port', '60001');
INSERT INTO `think_config` VALUES ('51', 'base_address', '3Ee5NW584q1wWKCWaxaJzZHdyqiUL46dmP');
INSERT INTO `think_config` VALUES ('52', 'pk_waiting_finished_num', '20');
INSERT INTO `think_config` VALUES ('53', 'ethip', 'http://127.0.0.1:40010');
INSERT INTO `think_config` VALUES ('54', 'usdtaddr', '0xdac17f958d2ee523a2206206994597c13d831ec7');
INSERT INTO `think_config` VALUES ('55', 'feepass', '');
INSERT INTO `think_config` VALUES ('56', 'feeaddr', '');
INSERT INTO `think_config` VALUES ('57', 'hzaddr', '0x4D0567E832BA305e08489deCfbCd49041A861B4b');
INSERT INTO `think_config` VALUES ('58', 'mincover', '10');
INSERT INTO `think_config` VALUES ('59', 'wallettype', 'erc');
INSERT INTO `think_config` VALUES ('60', 'usdtabi', '[{\"constant\":true,\"inputs\":[],\"name\":\"name\",\"outputs\":[{\"name\":\"\",\"type\":\"string\"}],\"payable\":false,\"stateMutability\":\"view\",\"type\":\"function\"},{\"constant\":false,\"inputs\":[{\"name\":\"_upgradedAddress\",\"type\":\"address\"}],\"name\":\"deprecate\",\"outputs\":[],\"payable\":false,\"stateMutability\":\"nonpayable\",\"type\":\"function\"},{\"constant\":false,\"inputs\":[{\"name\":\"_spender\",\"type\":\"address\"},{\"name\":\"_value\",\"type\":\"uint256\"}],\"name\":\"approve\",\"outputs\":[],\"payable\":false,\"stateMutability\":\"nonpayable\",\"type\":\"function\"},{\"constant\":true,\"inputs\":[],\"name\":\"deprecated\",\"outputs\":[{\"name\":\"\",\"type\":\"bool\"}],\"payable\":false,\"stateMutability\":\"view\",\"type\":\"function\"},{\"constant\":false,\"inputs\":[{\"name\":\"_evilUser\",\"type\":\"address\"}],\"name\":\"addBlackList\",\"outputs\":[],\"payable\":false,\"stateMutability\":\"nonpayable\",\"type\":\"function\"},{\"constant\":true,\"inputs\":[],\"name\":\"totalSupply\",\"outputs\":[{\"name\":\"\",\"type\":\"uint256\"}],\"payable\":false,\"stateMutability\":\"view\",\"type\":\"function\"},{\"constant\":false,\"inputs\":[{\"name\":\"_from\",\"type\":\"address\"},{\"name\":\"_to\",\"type\":\"address\"},{\"name\":\"_value\",\"type\":\"uint256\"}],\"name\":\"transferFrom\",\"outputs\":[],\"payable\":false,\"stateMutability\":\"nonpayable\",\"type\":\"function\"},{\"constant\":true,\"inputs\":[],\"name\":\"upgradedAddress\",\"outputs\":[{\"name\":\"\",\"type\":\"address\"}],\"payable\":false,\"stateMutability\":\"view\",\"type\":\"function\"},{\"constant\":true,\"inputs\":[{\"name\":\"\",\"type\":\"address\"}],\"name\":\"balances\",\"outputs\":[{\"name\":\"\",\"type\":\"uint256\"}],\"payable\":false,\"stateMutability\":\"view\",\"type\":\"function\"},{\"constant\":true,\"inputs\":[],\"name\":\"decimals\",\"outputs\":[{\"name\":\"\",\"type\":\"uint256\"}],\"payable\":false,\"stateMutability\":\"view\",\"type\":\"function\"},{\"constant\":true,\"inputs\":[],\"name\":\"maximumFee\",\"outputs\":[{\"name\":\"\",\"type\":\"uint256\"}],\"payable\":false,\"stateMutability\":\"view\",\"type\":\"function\"},{\"constant\":true,\"inputs\":[],\"name\":\"_totalSupply\",\"outputs\":[{\"name\":\"\",\"type\":\"uint256\"}],\"payable\":false,\"stateMutability\":\"view\",\"type\":\"function\"},{\"constant\":false,\"inputs\":[],\"name\":\"unpause\",\"outputs\":[],\"payable\":false,\"stateMutability\":\"nonpayable\",\"type\":\"function\"},{\"constant\":true,\"inputs\":[{\"name\":\"_maker\",\"type\":\"address\"}],\"name\":\"getBlackListStatus\",\"outputs\":[{\"name\":\"\",\"type\":\"bool\"}],\"payable\":false,\"stateMutability\":\"view\",\"type\":\"function\"},{\"constant\":true,\"inputs\":[{\"name\":\"\",\"type\":\"address\"},{\"name\":\"\",\"type\":\"address\"}],\"name\":\"allowed\",\"outputs\":[{\"name\":\"\",\"type\":\"uint256\"}],\"payable\":false,\"stateMutability\":\"view\",\"type\":\"function\"},{\"constant\":true,\"inputs\":[],\"name\":\"paused\",\"outputs\":[{\"name\":\"\",\"type\":\"bool\"}],\"payable\":false,\"stateMutability\":\"view\",\"type\":\"function\"},{\"constant\":true,\"inputs\":[{\"name\":\"who\",\"type\":\"address\"}],\"name\":\"balanceOf\",\"outputs\":[{\"name\":\"\",\"type\":\"uint256\"}],\"payable\":false,\"stateMutability\":\"view\",\"type\":\"function\"},{\"constant\":false,\"inputs\":[],\"name\":\"pause\",\"outputs\":[],\"payable\":false,\"stateMutability\":\"nonpayable\",\"type\":\"function\"},{\"constant\":true,\"inputs\":[],\"name\":\"getOwner\",\"outputs\":[{\"name\":\"\",\"type\":\"address\"}],\"payable\":false,\"stateMutability\":\"view\",\"type\":\"function\"},{\"constant\":true,\"inputs\":[],\"name\":\"owner\",\"outputs\":[{\"name\":\"\",\"type\":\"address\"}],\"payable\":false,\"stateMutability\":\"view\",\"type\":\"function\"},{\"constant\":true,\"inputs\":[],\"name\":\"symbol\",\"outputs\":[{\"name\":\"\",\"type\":\"string\"}],\"payable\":false,\"stateMutability\":\"view\",\"type\":\"function\"},{\"constant\":false,\"inputs\":[{\"name\":\"_to\",\"type\":\"address\"},{\"name\":\"_value\",\"type\":\"uint256\"}],\"name\":\"transfer\",\"outputs\":[],\"payable\":false,\"stateMutability\":\"nonpayable\",\"type\":\"function\"},{\"constant\":false,\"inputs\":[{\"name\":\"newBasisPoints\",\"type\":\"uint256\"},{\"name\":\"newMaxFee\",\"type\":\"uint256\"}],\"name\":\"setParams\",\"outputs\":[],\"payable\":false,\"stateMutability\":\"nonpayable\",\"type\":\"function\"},{\"constant\":false,\"inputs\":[{\"name\":\"amount\",\"type\":\"uint256\"}],\"name\":\"issue\",\"outputs\":[],\"payable\":false,\"stateMutability\":\"nonpayable\",\"type\":\"function\"},{\"constant\":false,\"inputs\":[{\"name\":\"amount\",\"type\":\"uint256\"}],\"name\":\"redeem\",\"outputs\":[],\"payable\":false,\"stateMutability\":\"nonpayable\",\"type\":\"function\"},{\"constant\":true,\"inputs\":[{\"name\":\"_owner\",\"type\":\"address\"},{\"name\":\"_spender\",\"type\":\"address\"}],\"name\":\"allowance\",\"outputs\":[{\"name\":\"remaining\",\"type\":\"uint256\"}],\"payable\":false,\"stateMutability\":\"view\",\"type\":\"function\"},{\"constant\":true,\"inputs\":[],\"name\":\"basisPointsRate\",\"outputs\":[{\"name\":\"\",\"type\":\"uint256\"}],\"payable\":false,\"stateMutability\":\"view\",\"type\":\"function\"},{\"constant\":true,\"inputs\":[{\"name\":\"\",\"type\":\"address\"}],\"name\":\"isBlackListed\",\"outputs\":[{\"name\":\"\",\"type\":\"bool\"}],\"payable\":false,\"stateMutability\":\"view\",\"type\":\"function\"},{\"constant\":false,\"inputs\":[{\"name\":\"_clearedUser\",\"type\":\"address\"}],\"name\":\"removeBlackList\",\"outputs\":[],\"payable\":false,\"stateMutability\":\"nonpayable\",\"type\":\"function\"},{\"constant\":true,\"inputs\":[],\"name\":\"MAX_UINT\",\"outputs\":[{\"name\":\"\",\"type\":\"uint256\"}],\"payable\":false,\"stateMutability\":\"view\",\"type\":\"function\"},{\"constant\":false,\"inputs\":[{\"name\":\"newOwner\",\"type\":\"address\"}],\"name\":\"transferOwnership\",\"outputs\":[],\"payable\":false,\"stateMutability\":\"nonpayable\",\"type\":\"function\"},{\"constant\":false,\"inputs\":[{\"name\":\"_blackListedUser\",\"type\":\"address\"}],\"name\":\"destroyBlackFunds\",\"outputs\":[],\"payable\":false,\"stateMutability\":\"nonpayable\",\"type\":\"function\"},{\"inputs\":[{\"name\":\"_initialSupply\",\"type\":\"uint256\"},{\"name\":\"_name\",\"type\":\"string\"},{\"name\":\"_symbol\",\"type\":\"string\"},{\"name\":\"_decimals\",\"type\":\"uint256\"}],\"payable\":false,\"stateMutability\":\"nonpayable\",\"type\":\"constructor\"},{\"anonymous\":false,\"inputs\":[{\"indexed\":false,\"name\":\"amount\",\"type\":\"uint256\"}],\"name\":\"Issue\",\"type\":\"event\"},{\"anonymous\":false,\"inputs\":[{\"indexed\":false,\"name\":\"amount\",\"type\":\"uint256\"}],\"name\":\"Redeem\",\"type\":\"event\"},{\"anonymous\":false,\"inputs\":[{\"indexed\":false,\"name\":\"newAddress\",\"type\":\"address\"}],\"name\":\"Deprecate\",\"type\":\"event\"},{\"anonymous\":false,\"inputs\":[{\"indexed\":false,\"name\":\"feeBasisPoints\",\"type\":\"uint256\"},{\"indexed\":false,\"name\":\"maxFee\",\"type\":\"uint256\"}],\"name\":\"Params\",\"type\":\"event\"},{\"anonymous\":false,\"inputs\":[{\"indexed\":false,\"name\":\"_blackListedUser\",\"type\":\"address\"},{\"indexed\":false,\"name\":\"_balance\",\"type\":\"uint256\"}],\"name\":\"DestroyedBlackFunds\",\"type\":\"event\"},{\"anonymous\":false,\"inputs\":[{\"indexed\":false,\"name\":\"_user\",\"type\":\"address\"}],\"name\":\"AddedBlackList\",\"type\":\"event\"},{\"anonymous\":false,\"inputs\":[{\"indexed\":false,\"name\":\"_user\",\"type\":\"address\"}],\"name\":\"RemovedBlackList\",\"type\":\"event\"},{\"anonymous\":false,\"inputs\":[{\"indexed\":true,\"name\":\"owner\",\"type\":\"address\"},{\"indexed\":true,\"name\":\"spender\",\"type\":\"address\"},{\"indexed\":false,\"name\":\"value\",\"type\":\"uint256\"}],\"name\":\"Approval\",\"type\":\"event\"},{\"anonymous\":false,\"inputs\":[{\"indexed\":true,\"name\":\"from\",\"type\":\"address\"},{\"indexed\":true,\"name\":\"to\",\"type\":\"address\"},{\"indexed\":false,\"name\":\"value\",\"type\":\"uint256\"}],\"name\":\"Transfer\",\"type\":\"event\"},{\"anonymous\":false,\"inputs\":[],\"name\":\"Pause\",\"type\":\"event\"},{\"anonymous\":false,\"inputs\":[],\"name\":\"Unpause\",\"type\":\"event\"}]');
INSERT INTO `think_config` VALUES ('61', 'feeaddrprive', '0x05F72bE0CB7Cf86f41a49788C7CCaCC3DC80034C');
INSERT INTO `think_config` VALUES ('63', 'usdt_price_add', '0');
INSERT INTO `think_config` VALUES ('62', 'usdtabi_bak', '[{\"constant\":true,\"inputs\":[],\"name\":\"name\",\"outputs\":[{\"name\":\"\",\"type\":\"string\"}],\"payable\":false,\"stateMutability\":\"view\",\"type\":\"function\"},{\"constant\":false,\"inputs\":[{\"name\":\"_upgradedAddress\",\"type\":\"address\"}],\"name\":\"deprecate\",\"outputs\":[],\"payable\":false,\"stateMutability\":\"nonpayable\",\"type\":\"function\"},{\"constant\":false,\"inputs\":[{\"name\":\"_spender\",\"type\":\"address\"},{\"name\":\"_value\",\"type\":\"uint256\"}],\"name\":\"approve\",\"outputs\":[],\"payable\":false,\"stateMutability\":\"nonpayable\",\"type\":\"function\"},{\"constant\":true,\"inputs\":[],\"name\":\"deprecated\",\"outputs\":[{\"name\":\"\",\"type\":\"bool\"}],\"payable\":false,\"stateMutability\":\"view\",\"type\":\"function\"},{\"constant\":false,\"inputs\":[{\"name\":\"_evilUser\",\"type\":\"address\"}],\"name\":\"addBlackList\",\"outputs\":[],\"payable\":false,\"stateMutability\":\"nonpayable\",\"type\":\"function\"},{\"constant\":true,\"inputs\":[],\"name\":\"totalSupply\",\"outputs\":[{\"name\":\"\",\"type\":\"uint256\"}],\"payable\":false,\"stateMutability\":\"view\",\"type\":\"function\"},{\"constant\":false,\"inputs\":[{\"name\":\"_from\",\"type\":\"address\"},{\"name\":\"_to\",\"type\":\"address\"},{\"name\":\"_value\",\"type\":\"uint256\"}],\"name\":\"transferFrom\",\"outputs\":[],\"payable\":false,\"stateMutability\":\"nonpayable\",\"type\":\"function\"},{\"constant\":true,\"inputs\":[],\"name\":\"upgradedAddress\",\"outputs\":[{\"name\":\"\",\"type\":\"address\"}],\"payable\":false,\"stateMutability\":\"view\",\"type\":\"function\"},{\"constant\":true,\"inputs\":[{\"name\":\"\",\"type\":\"address\"}],\"name\":\"balances\",\"outputs\":[{\"name\":\"\",\"type\":\"uint256\"}],\"payable\":false,\"stateMutability\":\"view\",\"type\":\"function\"},{\"constant\":true,\"inputs\":[],\"name\":\"decimals\",\"outputs\":[{\"name\":\"\",\"type\":\"uint256\"}],\"payable\":false,\"stateMutability\":\"view\",\"type\":\"function\"},{\"constant\":true,\"inputs\":[],\"name\":\"maximumFee\",\"outputs\":[{\"name\":\"\",\"type\":\"uint256\"}],\"payable\":false,\"stateMutability\":\"view\",\"type\":\"function\"},{\"constant\":true,\"inputs\":[],\"name\":\"_totalSupply\",\"outputs\":[{\"name\":\"\",\"type\":\"uint256\"}],\"payable\":false,\"stateMutability\":\"view\",\"type\":\"function\"},{\"constant\":false,\"inputs\":[],\"name\":\"unpause\",\"outputs\":[],\"payable\":false,\"stateMutability\":\"nonpayable\",\"type\":\"function\"},{\"constant\":true,\"inputs\":[{\"name\":\"_maker\",\"type\":\"address\"}],\"name\":\"getBlackListStatus\",\"outputs\":[{\"name\":\"\",\"type\":\"bool\"}],\"payable\":false,\"stateMutability\":\"view\",\"type\":\"function\"},{\"constant\":true,\"inputs\":[{\"name\":\"\",\"type\":\"address\"},{\"name\":\"\",\"type\":\"address\"}],\"name\":\"allowed\",\"outputs\":[{\"name\":\"\",\"type\":\"uint256\"}],\"payable\":false,\"stateMutability\":\"view\",\"type\":\"function\"},{\"constant\":true,\"inputs\":[],\"name\":\"paused\",\"outputs\":[{\"name\":\"\",\"type\":\"bool\"}],\"payable\":false,\"stateMutability\":\"view\",\"type\":\"function\"},{\"constant\":true,\"inputs\":[{\"name\":\"who\",\"type\":\"address\"}],\"name\":\"balanceOf\",\"outputs\":[{\"name\":\"\",\"type\":\"uint256\"}],\"payable\":false,\"stateMutability\":\"view\",\"type\":\"function\"},{\"constant\":false,\"inputs\":[],\"name\":\"pause\",\"outputs\":[],\"payable\":false,\"stateMutability\":\"nonpayable\",\"type\":\"function\"},{\"constant\":true,\"inputs\":[],\"name\":\"getOwner\",\"outputs\":[{\"name\":\"\",\"type\":\"address\"}],\"payable\":false,\"stateMutability\":\"view\",\"type\":\"function\"},{\"constant\":true,\"inputs\":[],\"name\":\"owner\",\"outputs\":[{\"name\":\"\",\"type\":\"address\"}],\"payable\":false,\"stateMutability\":\"view\",\"type\":\"function\"},{\"constant\":true,\"inputs\":[],\"name\":\"symbol\",\"outputs\":[{\"name\":\"\",\"type\":\"string\"}],\"payable\":false,\"stateMutability\":\"view\",\"type\":\"function\"},{\"constant\":false,\"inputs\":[{\"name\":\"_to\",\"type\":\"address\"},{\"name\":\"_value\",\"type\":\"uint256\"}],\"name\":\"transfer\",\"outputs\":[],\"payable\":false,\"stateMutability\":\"nonpayable\",\"type\":\"function\"},{\"constant\":false,\"inputs\":[{\"name\":\"newBasisPoints\",\"type\":\"uint256\"},{\"name\":\"newMaxFee\",\"type\":\"uint256\"}],\"name\":\"setParams\",\"outputs\":[],\"payable\":false,\"stateMutability\":\"nonpayable\",\"type\":\"function\"},{\"constant\":false,\"inputs\":[{\"name\":\"amount\",\"type\":\"uint256\"}],\"name\":\"issue\",\"outputs\":[],\"payable\":false,\"stateMutability\":\"nonpayable\",\"type\":\"function\"},{\"constant\":false,\"inputs\":[{\"name\":\"amount\",\"type\":\"uint256\"}],\"name\":\"redeem\",\"outputs\":[],\"payable\":false,\"stateMutability\":\"nonpayable\",\"type\":\"function\"},{\"constant\":true,\"inputs\":[{\"name\":\"_owner\",\"type\":\"address\"},{\"name\":\"_spender\",\"type\":\"address\"}],\"name\":\"allowance\",\"outputs\":[{\"name\":\"remaining\",\"type\":\"uint256\"}],\"payable\":false,\"stateMutability\":\"view\",\"type\":\"function\"},{\"constant\":true,\"inputs\":[],\"name\":\"basisPointsRate\",\"outputs\":[{\"name\":\"\",\"type\":\"uint256\"}],\"payable\":false,\"stateMutability\":\"view\",\"type\":\"function\"},{\"constant\":true,\"inputs\":[{\"name\":\"\",\"type\":\"address\"}],\"name\":\"isBlackListed\",\"outputs\":[{\"name\":\"\",\"type\":\"bool\"}],\"payable\":false,\"stateMutability\":\"view\",\"type\":\"function\"},{\"constant\":false,\"inputs\":[{\"name\":\"_clearedUser\",\"type\":\"address\"}],\"name\":\"removeBlackList\",\"outputs\":[],\"payable\":false,\"stateMutability\":\"nonpayable\",\"type\":\"function\"},{\"constant\":true,\"inputs\":[],\"name\":\"MAX_UINT\",\"outputs\":[{\"name\":\"\",\"type\":\"uint256\"}],\"payable\":false,\"stateMutability\":\"view\",\"type\":\"function\"},{\"constant\":false,\"inputs\":[{\"name\":\"newOwner\",\"type\":\"address\"}],\"name\":\"transferOwnership\",\"outputs\":[],\"payable\":false,\"stateMutability\":\"nonpayable\",\"type\":\"function\"},{\"constant\":false,\"inputs\":[{\"name\":\"_blackListedUser\",\"type\":\"address\"}],\"name\":\"destroyBlackFunds\",\"outputs\":[],\"payable\":false,\"stateMutability\":\"nonpayable\",\"type\":\"function\"},{\"inputs\":[{\"name\":\"_initialSupply\",\"type\":\"uint256\"},{\"name\":\"_name\",\"type\":\"string\"},{\"name\":\"_symbol\",\"type\":\"string\"},{\"name\":\"_decimals\",\"type\":\"uint256\"}],\"payable\":false,\"stateMutability\":\"nonpayable\",\"type\":\"constructor\"},{\"anonymous\":false,\"inputs\":[{\"indexed\":false,\"name\":\"amount\",\"type\":\"uint256\"}],\"name\":\"Issue\",\"type\":\"event\"},{\"anonymous\":false,\"inputs\":[{\"indexed\":false,\"name\":\"amount\",\"type\":\"uint256\"}],\"name\":\"Redeem\",\"type\":\"event\"},{\"anonymous\":false,\"inputs\":[{\"indexed\":false,\"name\":\"newAddress\",\"type\":\"address\"}],\"name\":\"Deprecate\",\"type\":\"event\"},{\"anonymous\":false,\"inputs\":[{\"indexed\":false,\"name\":\"feeBasisPoints\",\"type\":\"uint256\"},{\"indexed\":false,\"name\":\"maxFee\",\"type\":\"uint256\"}],\"name\":\"Params\",\"type\":\"event\"},{\"anonymous\":false,\"inputs\":[{\"indexed\":false,\"name\":\"_blackListedUser\",\"type\":\"address\"},{\"indexed\":false,\"name\":\"_balance\",\"type\":\"uint256\"}],\"name\":\"DestroyedBlackFunds\",\"type\":\"event\"},{\"anonymous\":false,\"inputs\":[{\"indexed\":false,\"name\":\"_user\",\"type\":\"address\"}],\"name\":\"AddedBlackList\",\"type\":\"event\"},{\"anonymous\":false,\"inputs\":[{\"indexed\":false,\"name\":\"_user\",\"type\":\"address\"}],\"name\":\"RemovedBlackList\",\"type\":\"event\"},{\"anonymous\":false,\"inputs\":[{\"indexed\":true,\"name\":\"owner\",\"type\":\"address\"},{\"indexed\":true,\"name\":\"spender\",\"type\":\"address\"},{\"indexed\":false,\"name\":\"value\",\"type\":\"uint256\"}],\"name\":\"Approval\",\"type\":\"event\"},{\"anonymous\":false,\"inputs\":[{\"indexed\":true,\"name\":\"from\",\"type\":\"address\"},{\"indexed\":true,\"name\":\"to\",\"type\":\"address\"},{\"indexed\":false,\"name\":\"value\",\"type\":\"uint256\"}],\"name\":\"Transfer\",\"type\":\"event\"},{\"anonymous\":false,\"inputs\":[],\"name\":\"Pause\",\"type\":\"event\"},{\"anonymous\":false,\"inputs\":[],\"name\":\"Unpause\",\"type\":\"event\"}]');
INSERT INTO `think_config` VALUES ('64', 'usdt_price_add_buy', '-0.04');

-- -----------------------------
-- Table structure for `think_financelog`
-- -----------------------------
DROP TABLE IF EXISTS `think_financelog`;
CREATE TABLE `think_financelog` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uid` int(11) DEFAULT NULL COMMENT '用户ID',
  `user` varchar(50) DEFAULT NULL COMMENT '用户姓名',
  `note` varchar(300) DEFAULT NULL COMMENT '描述',
  `amount` varchar(200) DEFAULT NULL COMMENT '数量',
  `status` tinyint(1) DEFAULT NULL COMMENT '0增加1减少',
  `add_time` int(11) DEFAULT NULL COMMENT '添加时间',
  `op` varchar(255) DEFAULT NULL COMMENT '操作员',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=157 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `think_financelog`
-- -----------------------------
INSERT INTO `think_financelog` VALUES ('1', '1', '商户', '买入USDT_f1', '95.1136044908', '0', '1567306659', '承兑商二');
INSERT INTO `think_financelog` VALUES ('2', '1', '商户', '卖出USDT_冻结1', '70.6293706293', '1', '1567308652', '商户');
INSERT INTO `think_financelog` VALUES ('3', '4', '承兑商二', '买入USDT_f2', '70.6293706293', '0', '1567308882', '商户');
INSERT INTO `think_financelog` VALUES ('4', '1', '商户', '买入USDT_f1', '127.0014025224', '0', '1567309752', '承兑商二');
INSERT INTO `think_financelog` VALUES ('5', '1', '商户', '买入USDT_f1', '16.3562412384', '0', '1567317061', '承兑商二');
INSERT INTO `think_financelog` VALUES ('6', '1', '商户', '买入USDT_f1', '137.1725105198', '0', '1567317070', '承兑商二');
INSERT INTO `think_financelog` VALUES ('7', '1', '商户', '买入USDT_f1', '10.0336605866', '0', '1567317480', '承兑商二');
INSERT INTO `think_financelog` VALUES ('8', '1', '商户', '买入USDT_f1', '59.5097493004', '0', '1567319041', '承兑商二');
INSERT INTO `think_financelog` VALUES ('9', '1', '商户', '买入USDT_f1', '112.019635343', '0', '1567319141', '承兑商二');
INSERT INTO `think_financelog` VALUES ('10', '1', '商户', '买入USDT_f1', '4.231197775', '0', '1567319245', '承兑商二');
INSERT INTO `think_financelog` VALUES ('11', '1', '商户', '买入USDT_f1', '50.6378830062', '0', '1567319407', '承兑商二');
INSERT INTO `think_financelog` VALUES ('12', '1', '商户', '卖出USDT_冻结1', '14.08963585344', '1', '1567319819', '商户');
INSERT INTO `think_financelog` VALUES ('13', '4', '承兑商二', '买入USDT_f2', '14.1456582624', '0', '1567319996', '商户');
INSERT INTO `think_financelog` VALUES ('14', '1', '商户', '买入USDT_f1', '62.239554314', '0', '1567325251', '承兑商二');
INSERT INTO `think_financelog` VALUES ('15', '4', '承兑商二', '后台修改USDT余额', '18396.69805022', '1', '1567325428', 'admin');
INSERT INTO `think_financelog` VALUES ('16', '1', '商户', '后台修改USDT余额', '207.67230874', '0', '1567327705', 'admin');
INSERT INTO `think_financelog` VALUES ('17', '1', '商户', '买入USDT_f1', '122.8036211707', '0', '1567327999', '承兑商二');
INSERT INTO `think_financelog` VALUES ('18', '1', '商户', '后台修改USDT余额', '122.80362117', '1', '1567328350', 'admin');
INSERT INTO `think_financelog` VALUES ('19', '4', '承兑商二', '后台修改USDT余额', '126.60167131', '0', '1567328420', 'admin');
INSERT INTO `think_financelog` VALUES ('20', '1', '商户', '买入USDT_f1', '70.3325905248', '0', '1567328519', '承兑商二');
INSERT INTO `think_financelog` VALUES ('21', '1', '商户', '后台修改USDT余额', '70.33259052', '1', '1567328663', 'admin');
INSERT INTO `think_financelog` VALUES ('22', '4', '承兑商二', '后台修改USDT余额', '70.4735376', '0', '1567328694', 'admin');
INSERT INTO `think_financelog` VALUES ('23', '1', '商户', '买入USDT_f1', '69.7465181014', '0', '1567328838', '承兑商二');
INSERT INTO `think_financelog` VALUES ('24', '4', '承兑商二', '后台修改USDT余额', '71.16991643', '0', '1567329260', 'admin');
INSERT INTO `think_financelog` VALUES ('25', '1', '商户', '买入USDT_f1', '139.08205841', '0', '1567329534', '承兑商二');
INSERT INTO `think_financelog` VALUES ('26', '4', '承兑商二', '后台修改USDT余额', '139.08205841', '0', '1567329585', 'admin');
INSERT INTO `think_financelog` VALUES ('27', '1', '商户', '后台修改USDT余额', '208.82857651', '1', '1567329606', 'admin');
INSERT INTO `think_financelog` VALUES ('28', '1', '商户', '买入USDT_f1', '13.649025068', '0', '1567329775', '承兑商二');
INSERT INTO `think_financelog` VALUES ('29', '4', '承兑商二', '后台修改USDT余额', '13.9275766', '0', '1567329970', 'admin');
INSERT INTO `think_financelog` VALUES ('30', '1', '商户', '后台修改USDT余额', '13.64902507', '1', '1567329990', 'admin');
INSERT INTO `think_financelog` VALUES ('31', '1', '商户', '买入USDT_f1', '136.3004172418', '0', '1567330139', '承兑商二');
INSERT INTO `think_financelog` VALUES ('32', '4', '承兑商二', '后台修改USDT余额', '139.08205841', '0', '1567330161', 'admin');
INSERT INTO `think_financelog` VALUES ('33', '1', '商户', '后台修改USDT余额', '136.30041724', '1', '1567330182', 'admin');
INSERT INTO `think_financelog` VALUES ('34', '1', '商户', '买入USDT_f1', '980', '0', '1567330252', '承兑商二');
INSERT INTO `think_financelog` VALUES ('35', '4', '承兑商二', '后台修改USDT余额', '1000', '0', '1567330564', 'admin');
INSERT INTO `think_financelog` VALUES ('36', '1', '商户', '后台修改USDT余额', '980', '1', '1567330592', 'admin');
INSERT INTO `think_financelog` VALUES ('37', '1', '商户', '买入USDT_f1', '980', '0', '1567330698', '承兑商二');
INSERT INTO `think_financelog` VALUES ('38', '4', '承兑商二', '后台修改USDT余额', '1000', '0', '1567330756', 'admin');
INSERT INTO `think_financelog` VALUES ('39', '1', '商户', '后台修改USDT余额', '980', '1', '1567330771', 'admin');
INSERT INTO `think_financelog` VALUES ('40', '1', '商户', '买入USDT_f1', '980', '0', '1567331058', '承兑商二');
INSERT INTO `think_financelog` VALUES ('41', '1', '商户', '后台修改USDT余额', '980', '1', '1567331287', 'admin');
INSERT INTO `think_financelog` VALUES ('42', '4', '承兑商二', '后台修改USDT余额', '1000', '0', '1567331371', 'admin');
INSERT INTO `think_financelog` VALUES ('43', '1', '商户', '买入USDT_f1', '996', '0', '1567331523', '承兑商二');
INSERT INTO `think_financelog` VALUES ('44', '1', '商户', '后台修改USDT余额', '996', '1', '1567331827', 'admin');
INSERT INTO `think_financelog` VALUES ('45', '4', '承兑商二', '后台修改USDT余额', '1000', '0', '1567331902', 'admin');
INSERT INTO `think_financelog` VALUES ('46', '1', '商户', '买入USDT_f1', '1000', '0', '1567331993', '承兑商二');
INSERT INTO `think_financelog` VALUES ('47', '4', '承兑商二', '后台修改USDT余额', '1000', '0', '1567332292', 'admin');
INSERT INTO `think_financelog` VALUES ('48', '1', '商户', '后台修改USDT余额', '1000', '1', '1567332333', 'admin');
INSERT INTO `think_financelog` VALUES ('49', '1', '商户', '买入USDT_f1', '996', '0', '1567332402', '承兑商二');
INSERT INTO `think_financelog` VALUES ('50', '3', '代理商', '后台修改USDT余额', '1000', '0', '1567332738', 'admin');
INSERT INTO `think_financelog` VALUES ('51', '4', '承兑商二', '后台修改USDT余额', '1000', '0', '1567333413', 'admin');
INSERT INTO `think_financelog` VALUES ('52', '1', '商户', '买入USDT_f1', '996', '0', '1567333546', '承兑商二');
INSERT INTO `think_financelog` VALUES ('53', '1', '商户', '后台修改USDT余额', '1992', '1', '1567334879', 'admin');
INSERT INTO `think_financelog` VALUES ('54', '1', '商户', '后台修改USDT余额', '392.7', '0', '1567334976', 'admin');
INSERT INTO `think_financelog` VALUES ('55', '4', '承兑商二', '后台修改USDT余额', '1392.7', '0', '1567335002', 'admin');
INSERT INTO `think_financelog` VALUES ('56', '2', '承兑商', '提币_1', '10.00000000', '1', '1567335803', 'admin');
INSERT INTO `think_financelog` VALUES ('57', '4', '承兑商二', '后台修改USDT余额', '392.7', '1', '1567337509', 'admin');
INSERT INTO `think_financelog` VALUES ('58', '1', '商户', '后台修改USDT余额', '392.7', '1', '1567337537', 'admin');
INSERT INTO `think_financelog` VALUES ('59', '1', '商户', '买入USDT_f1', '970', '0', '1567337614', '承兑商二');
INSERT INTO `think_financelog` VALUES ('60', '4', '承兑商二', '交易员利润_f1', '5', '0', '1567337614', '承兑商二');
INSERT INTO `think_financelog` VALUES ('61', '4', '承兑商二', '后台修改USDT余额', '995', '0', '1567337868', 'admin');
INSERT INTO `think_financelog` VALUES ('62', '1', '商户', '买入USDT_f1', '970', '0', '1567337920', '承兑商二');
INSERT INTO `think_financelog` VALUES ('63', '4', '承兑商二', '交易员利润_f1', '2', '0', '1567337920', '承兑商二');
INSERT INTO `think_financelog` VALUES ('64', '4', '承兑商二', '后台修改USDT余额', '998', '0', '1567338033', 'admin');
INSERT INTO `think_financelog` VALUES ('65', '1', '商户', '后台修改USDT余额', '1940', '1', '1567338072', 'admin');
INSERT INTO `think_financelog` VALUES ('66', '1', '商户', '买入USDT_f1', '970', '0', '1567338136', '承兑商二');
INSERT INTO `think_financelog` VALUES ('67', '4', '承兑商二', '交易员利润_f1', '1.5', '0', '1567338136', '承兑商二');
INSERT INTO `think_financelog` VALUES ('68', '1', '商户', '后台修改USDT余额', '970', '1', '1567338242', 'admin');
INSERT INTO `think_financelog` VALUES ('69', '1', '商户', '后台修改USDT余额', '1000', '1', '1567338261', 'admin');
INSERT INTO `think_financelog` VALUES ('70', '4', '承兑商二', '后台修改USDT余额', '998.5', '0', '1567338330', 'admin');
INSERT INTO `think_financelog` VALUES ('71', '1', '商户', '买入USDT_f1', '996.5', '0', '1567338470', '承兑商二');
INSERT INTO `think_financelog` VALUES ('72', '4', '承兑商二', '后台修改USDT余额', '1000', '0', '1567338749', 'admin');
INSERT INTO `think_financelog` VALUES ('73', '1', '商户', '后台修改USDT余额', '996.5', '1', '1567338777', 'admin');
INSERT INTO `think_financelog` VALUES ('74', '1', '商户', '买入USDT_f1', '996.5', '0', '1567338874', '承兑商二');
INSERT INTO `think_financelog` VALUES ('75', '1', '商户', '后台修改USDT余额', '3.5', '0', '1567338990', 'admin');
INSERT INTO `think_financelog` VALUES ('76', '4', '承兑商二', '后台修改USDT余额', '1000', '0', '1567339017', 'admin');
INSERT INTO `think_financelog` VALUES ('77', '1', '商户', '买入USDT_f1', '996.5', '0', '1567339111', '承兑商二');
INSERT INTO `think_financelog` VALUES ('78', '4', '承兑商二', '后台修改USDT余额', '1000', '0', '1567339214', 'admin');
INSERT INTO `think_financelog` VALUES ('79', '1', '商户', '后台修改USDT余额', '1996.5', '1', '1567339302', 'admin');
INSERT INTO `think_financelog` VALUES ('80', '1', '商户', '买入USDT_f1', '965', '0', '1567339326', '承兑商二');
INSERT INTO `think_financelog` VALUES ('81', '4', '承兑商二', '交易员利润_f1', '1.5', '0', '1567339326', '承兑商二');
INSERT INTO `think_financelog` VALUES ('82', '1', '商户', '后台修改USDT余额', '965', '1', '1567339553', 'admin');
INSERT INTO `think_financelog` VALUES ('83', '4', '承兑商二', '后台修改USDT余额', '998.5', '0', '1567339571', 'admin');
INSERT INTO `think_financelog` VALUES ('84', '1', '商户', '买入USDT_f1', '992', '0', '1567339733', '承兑商二');
INSERT INTO `think_financelog` VALUES ('85', '4', '承兑商二', '交易员利润_f1', '1.5', '0', '1567339733', '承兑商二');
INSERT INTO `think_financelog` VALUES ('86', '1', '商户', '后台修改USDT余额', '992', '1', '1567339819', 'admin');
INSERT INTO `think_financelog` VALUES ('87', '4', '承兑商二', '后台修改USDT余额', '998.5', '0', '1567339832', 'admin');
INSERT INTO `think_financelog` VALUES ('88', '1', '商户', '买入USDT_f1', '995', '0', '1567339889', '承兑商二');
INSERT INTO `think_financelog` VALUES ('89', '4', '承兑商二', '交易员利润_f1', '1.5', '0', '1567339889', '承兑商二');
INSERT INTO `think_financelog` VALUES ('90', '4', '承兑商二', '后台修改USDT余额', '998.5', '0', '1567340031', 'admin');
INSERT INTO `think_financelog` VALUES ('91', '1', '商户', '后台修改USDT余额', '995', '1', '1567340049', 'admin');
INSERT INTO `think_financelog` VALUES ('92', '1', '商户', '买入USDT_f1', '996', '0', '1567340109', '承兑商二');
INSERT INTO `think_financelog` VALUES ('93', '4', '承兑商二', '交易员利润_f1', '1.5', '0', '1567340109', '承兑商二');
INSERT INTO `think_financelog` VALUES ('94', '1', '商户', '后台修改USDT余额', '4', '0', '1567340194', 'admin');
INSERT INTO `think_financelog` VALUES ('95', '4', '承兑商二', '后台修改USDT余额', '998.5', '0', '1567340207', 'admin');
INSERT INTO `think_financelog` VALUES ('96', '1', '商户', '买入USDT_f1', '996.5', '0', '1567340273', '承兑商二');
INSERT INTO `think_financelog` VALUES ('97', '4', '承兑商二', '交易员利润_f1', '1.5', '0', '1567340273', '承兑商二');
INSERT INTO `think_financelog` VALUES ('98', '4', '承兑商二', '后台修改USDT余额', '9998.5', '0', '1567341691', 'admin');
INSERT INTO `think_financelog` VALUES ('99', '1', '商户', '后台修改USDT余额', '1996.5', '1', '1567341715', 'admin');
INSERT INTO `think_financelog` VALUES ('100', '1', '商户', '买入USDT_f1', '9965', '0', '1567341820', '承兑商二');
INSERT INTO `think_financelog` VALUES ('101', '4', '承兑商二', '后台修改USDT余额', '1000', '0', '1567341950', 'admin');
INSERT INTO `think_financelog` VALUES ('102', '1', '商户', '后台修改USDT余额', '9965', '1', '1567341970', 'admin');
INSERT INTO `think_financelog` VALUES ('103', '1', '商户', '买入USDT_f1', '996.5', '0', '1567342042', '承兑商二');
INSERT INTO `think_financelog` VALUES ('104', '4', '承兑商二', '交易员利润_f1', '1.5', '0', '1567342042', '承兑商二');
INSERT INTO `think_financelog` VALUES ('105', '4', '承兑商二', '后台修改USDT余额', '998.5', '0', '1567349722', 'admin');
INSERT INTO `think_financelog` VALUES ('106', '1', '商户', '后台修改USDT余额', '996.5', '1', '1567349742', 'admin');
INSERT INTO `think_financelog` VALUES ('107', '1', '商户', '买入USDT_f1', '13.8788300819', '0', '1567349977', '承兑商二');
INSERT INTO `think_financelog` VALUES ('108', '4', '承兑商二', '交易员利润_f1', '0.0208913649', '0', '1567349977', '承兑商二');
INSERT INTO `think_financelog` VALUES ('109', '4', '承兑商二', '后台修改USDT余额', '1013.90668524', '0', '1567350114', 'admin');
INSERT INTO `think_financelog` VALUES ('110', '1', '商户', '买入USDT_f1', '13.8788300819', '0', '1567350197', '承兑商二');
INSERT INTO `think_financelog` VALUES ('111', '4', '承兑商二', '交易员利润_f1', '0.0208913649', '0', '1567350197', '承兑商二');
INSERT INTO `think_financelog` VALUES ('112', '4', '承兑商二', '后台修改USDT余额', '986.09331476', '1', '1567419514', 'admin');
INSERT INTO `think_financelog` VALUES ('113', '4', '承兑商二', '后台修改USDT余额', '1000', '0', '1567419608', 'admin');
INSERT INTO `think_financelog` VALUES ('114', '6', '陈超', '后台修改USDT余额', '1000', '0', '1567420168', 'admin');
INSERT INTO `think_financelog` VALUES ('115', '1', '商户', '买入USDT_f1', '13.85952711956', '0', '1567420349', '承兑商二');
INSERT INTO `think_financelog` VALUES ('116', '4', '承兑商二', '交易员利润_f1', '0.02086230876', '0', '1567420349', '承兑商二');
INSERT INTO `think_financelog` VALUES ('117', '4', '承兑商二', '后台修改USDT余额', '986.11265647', '1', '1567420611', 'admin');
INSERT INTO `think_financelog` VALUES ('118', '2', '承兑商', '后台修改USDT余额', '7994.71549102', '1', '1567420710', 'admin');
INSERT INTO `think_financelog` VALUES ('119', '2', '承兑商', '后台修改USDT余额', '7994.71549102', '1', '1567420717', 'admin');
INSERT INTO `think_financelog` VALUES ('120', '2', '承兑商', '后台修改USDT余额', '7994.71549102', '1', '1567420720', 'admin');
INSERT INTO `think_financelog` VALUES ('121', '2', '承兑商', '后台修改USDT余额', '7994.71549102', '1', '1567420722', 'admin');
INSERT INTO `think_financelog` VALUES ('122', '2', '承兑商', '后台修改USDT余额', '7994.71549102', '1', '1567420727', 'admin');
INSERT INTO `think_financelog` VALUES ('123', '2', '承兑商', '后台修改USDT余额', '7994.71549102', '1', '1567420748', 'admin');
INSERT INTO `think_financelog` VALUES ('124', '2', '承兑商', '后台修改USDT冻结余额', '1673.98182177', '1', '1567420748', 'admin');
INSERT INTO `think_financelog` VALUES ('125', '1', '商户', '买入USDT_f1', '990.98686030211', '0', '1567420978', '承兑商');
INSERT INTO `think_financelog` VALUES ('126', '2', '承兑商', '交易员利润_f1', '1.49170124481', '0', '1567420978', '承兑商');
INSERT INTO `think_financelog` VALUES ('127', '2', '承兑商', '后台修改USDT余额', '1.49170124', '1', '1567421151', 'admin');
INSERT INTO `think_financelog` VALUES ('128', '2', '承兑商', '后台修改USDT冻结余额', '5.53250346', '1', '1567421151', 'admin');
INSERT INTO `think_financelog` VALUES ('129', '1', '商户', '买入USDT_f1', '996.5', '0', '1567421254', '承兑商二');
INSERT INTO `think_financelog` VALUES ('130', '4', '承兑商二', '交易员利润_f1', '1.5', '0', '1567421254', '承兑商二');
INSERT INTO `think_financelog` VALUES ('131', '1', '商户', '买入USDT_f1', '138.59527120557', '0', '1567421299', '承兑商');
INSERT INTO `think_financelog` VALUES ('132', '2', '承兑商', '交易员利润_f1', '0.208623087615', '0', '1567421299', '承兑商');
INSERT INTO `think_financelog` VALUES ('133', '2', '承兑商', '后台修改USDT余额', '138.87343532', '0', '1567421363', 'admin');
INSERT INTO `think_financelog` VALUES ('134', '1', '商户', '买入USDT_f1', '996.5', '0', '1567421464', '承兑商');
INSERT INTO `think_financelog` VALUES ('135', '2', '承兑商', '交易员利润_f1', '1.5', '0', '1567421464', '承兑商');
INSERT INTO `think_financelog` VALUES ('136', '4', '承兑商二', '后台修改USDT余额', '998.5', '0', '1567434706', 'admin');
INSERT INTO `think_financelog` VALUES ('137', '1', '商户', '买入USDT_f1', '996.5', '0', '1567434807', '承兑商二');
INSERT INTO `think_financelog` VALUES ('138', '4', '承兑商二', '交易员利润_f1', '1.5', '0', '1567434807', '承兑商二');
INSERT INTO `think_financelog` VALUES ('139', '1', '商户', '后台修改USDT余额', '3160.69931879', '1', '1567478741', 'admin');
INSERT INTO `think_financelog` VALUES ('140', '1', '商户', '提币_1', '500.00000000', '1', '1567479025', 'admin');
INSERT INTO `think_financelog` VALUES ('141', '3', '代理商', '提币_1', '500.00000000', '1', '1567479767', 'admin');
INSERT INTO `think_financelog` VALUES ('142', '4', '承兑商二', '后台修改USDT余额', '998.5', '0', '1568354846', 'admin');
INSERT INTO `think_financelog` VALUES ('143', '1', '商户', '买入USDT_f1', '20.185877313895', '0', '1568354947', '承兑商二');
INSERT INTO `think_financelog` VALUES ('144', '1', '商户', '买入USDT_f1', '67.523181171705', '0', '1568355216', '承兑商二');
INSERT INTO `think_financelog` VALUES ('145', '1', '商户', '买入USDT_f1', '95.95399429506', '0', '1568355377', '承兑商二');
INSERT INTO `think_financelog` VALUES ('146', '1', '商户', '买入USDT_f1', '115.85556348241', '0', '1568355482', '承兑商二');
INSERT INTO `think_financelog` VALUES ('147', '4', '承兑商二', '后台修改USDT余额', '300.57061341', '0', '1568355538', 'admin');
INSERT INTO `think_financelog` VALUES ('148', '1', '商户', '买入USDT_f1', '142.15406561678', '0', '1568355609', '承兑商二');
INSERT INTO `think_financelog` VALUES ('149', '4', '承兑商二', '后台修改USDT余额', '142.65335235', '0', '1568355682', 'admin');
INSERT INTO `think_financelog` VALUES ('150', '4', '承兑商二', '后台修改USDT余额', '142.65335235', '0', '1568355774', 'admin');
INSERT INTO `think_financelog` VALUES ('151', '1', '商户', '买入USDT_f1', '142.15406561678', '0', '1568355822', '承兑商二');
INSERT INTO `think_financelog` VALUES ('152', '1', '商户', '买入USDT_f1', '996.5', '0', '1568355936', '承兑商二');
INSERT INTO `think_financelog` VALUES ('153', '4', '承兑商二', '后台修改USDT余额', '1000', '0', '1568355994', 'admin');
INSERT INTO `think_financelog` VALUES ('154', '1', '商户', '买入USDT_f1', '996.5', '0', '1568356057', '承兑商二');
INSERT INTO `think_financelog` VALUES ('155', '4', '承兑商二', '后台修改USDT余额', '1000', '0', '1568356185', 'admin');
INSERT INTO `think_financelog` VALUES ('156', '1', '商户', '买入USDT_f1', '996.5', '0', '1568356252', '承兑商二');

-- -----------------------------
-- Table structure for `think_log`
-- -----------------------------
DROP TABLE IF EXISTS `think_log`;
CREATE TABLE `think_log` (
  `log_id` int(11) NOT NULL AUTO_INCREMENT,
  `admin_id` int(11) DEFAULT NULL COMMENT '用户ID',
  `admin_name` varchar(50) DEFAULT NULL COMMENT '用户姓名',
  `description` varchar(300) DEFAULT NULL COMMENT '描述',
  `ip` char(60) DEFAULT NULL COMMENT 'IP地址',
  `status` tinyint(1) DEFAULT NULL COMMENT '1 成功 2 失败',
  `add_time` int(11) DEFAULT NULL COMMENT '添加时间',
  PRIMARY KEY (`log_id`)
) ENGINE=MyISAM AUTO_INCREMENT=188 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `think_log`
-- -----------------------------
INSERT INTO `think_log` VALUES ('1', '1', 'admin', '用户【admin】登录成功', '112.224.20.152', '1', '1567250145');
INSERT INTO `think_log` VALUES ('2', '1', 'admin', '用户【admin】登录成功', '112.96.240.113', '1', '1567302767');
INSERT INTO `think_log` VALUES ('3', '1', 'admin', '用户【admin】更改设置:成功', '112.96.240.113', '1', '1567302951');
INSERT INTO `think_log` VALUES ('4', '1', 'admin', '用户【admin】更改设置:成功', '112.96.240.113', '1', '1567303332');
INSERT INTO `think_log` VALUES ('5', '1', 'admin', '用户【admin】更改设置:成功', '112.96.240.113', '1', '1567304398');
INSERT INTO `think_log` VALUES ('6', '1', 'admin', '用户【admin】登录成功', '112.96.240.113', '1', '1567304617');
INSERT INTO `think_log` VALUES ('7', '1', 'admin', '用户【admin】登录成功', '112.96.240.113', '1', '1567304952');
INSERT INTO `think_log` VALUES ('8', '1', 'admin', '用户【admin】编辑用户:1成功', '112.96.240.113', '1', '1567305073');
INSERT INTO `think_log` VALUES ('9', '1', 'admin', '用户【admin】编辑用户:1成功', '112.96.240.113', '1', '1567305296');
INSERT INTO `think_log` VALUES ('10', '1', 'admin', '用户【admin】更改设置:成功', '112.96.240.113', '1', '1567308374');
INSERT INTO `think_log` VALUES ('11', '1', 'admin', '用户【admin】更改设置:成功', '112.96.240.113', '1', '1567309486');
INSERT INTO `think_log` VALUES ('12', '1', 'admin', '用户【admin】更改设置:成功', '112.96.240.113', '1', '1567309737');
INSERT INTO `think_log` VALUES ('13', '1', 'admin', '用户【admin】登录成功', '112.96.240.113', '1', '1567312471');
INSERT INTO `think_log` VALUES ('14', '1', 'admin', '用户【admin】更改设置:成功', '112.96.240.113', '1', '1567316891');
INSERT INTO `think_log` VALUES ('15', '1', 'admin', '用户【admin】更改设置:成功', '112.96.240.113', '1', '1567317686');
INSERT INTO `think_log` VALUES ('16', '1', 'admin', '用户【admin】更改设置:成功', '112.96.240.113', '1', '1567318208');
INSERT INTO `think_log` VALUES ('17', '1', 'admin', '用户【admin】更改设置:成功', '112.96.240.113', '1', '1567318498');
INSERT INTO `think_log` VALUES ('18', '1', 'admin', '用户【admin】更改设置:成功', '112.96.240.113', '1', '1567318615');
INSERT INTO `think_log` VALUES ('19', '1', 'admin', '用户【admin】更改设置:成功', '112.96.240.113', '1', '1567318676');
INSERT INTO `think_log` VALUES ('20', '1', 'admin', '用户【admin】更改设置:成功', '112.96.240.113', '1', '1567318752');
INSERT INTO `think_log` VALUES ('21', '1', 'admin', '用户【admin】更改设置:成功', '112.96.240.113', '1', '1567318811');
INSERT INTO `think_log` VALUES ('22', '1', 'admin', '用户【admin】更改设置:成功', '112.96.240.113', '1', '1567318879');
INSERT INTO `think_log` VALUES ('23', '1', 'admin', '用户【admin】更改设置:成功', '112.96.240.113', '1', '1567319716');
INSERT INTO `think_log` VALUES ('24', '1', 'admin', '用户【admin】更改设置:成功', '112.96.240.113', '1', '1567320772');
INSERT INTO `think_log` VALUES ('25', '1', 'admin', '用户【admin】更改设置:成功', '112.96.240.113', '1', '1567320804');
INSERT INTO `think_log` VALUES ('26', '1', 'admin', '用户【admin】更改设置:成功', '112.96.240.113', '1', '1567320889');
INSERT INTO `think_log` VALUES ('27', '1', 'admin', '用户【admin】更改设置:成功', '112.96.240.113', '1', '1567320963');
INSERT INTO `think_log` VALUES ('28', '1', 'admin', '用户【admin】更改设置:成功', '112.96.240.113', '1', '1567321010');
INSERT INTO `think_log` VALUES ('29', '1', 'admin', '用户【admin】登录成功', '112.96.241.100', '1', '1567324810');
INSERT INTO `think_log` VALUES ('30', '1', 'admin', '用户【admin】登录成功', '112.96.241.100', '1', '1567325073');
INSERT INTO `think_log` VALUES ('31', '1', 'admin', '用户【admin】编辑用户:4成功', '112.96.241.100', '1', '1567325428');
INSERT INTO `think_log` VALUES ('32', '1', 'admin', '用户【admin】编辑用户:1成功', '112.96.240.198', '1', '1567327705');
INSERT INTO `think_log` VALUES ('33', '1', 'admin', '用户【admin】编辑用户:1成功', '112.96.240.198', '1', '1567327732');
INSERT INTO `think_log` VALUES ('34', '1', 'admin', '用户【admin】编辑用户:1成功', '112.96.240.198', '1', '1567327744');
INSERT INTO `think_log` VALUES ('35', '1', 'admin', '用户【admin】编辑用户:4成功', '112.96.240.198', '1', '1567328284');
INSERT INTO `think_log` VALUES ('36', '1', 'admin', '用户【admin】编辑用户:1成功', '112.96.240.198', '1', '1567328350');
INSERT INTO `think_log` VALUES ('37', '1', 'admin', '用户【admin】编辑用户:1成功', '112.96.240.198', '1', '1567328382');
INSERT INTO `think_log` VALUES ('38', '1', 'admin', '用户【admin】编辑用户:4成功', '112.96.240.198', '1', '1567328420');
INSERT INTO `think_log` VALUES ('39', '1', 'admin', '用户【admin】编辑用户:1成功', '112.96.240.198', '1', '1567328643');
INSERT INTO `think_log` VALUES ('40', '1', 'admin', '用户【admin】编辑用户:1成功', '112.96.240.198', '1', '1567328663');
INSERT INTO `think_log` VALUES ('41', '1', 'admin', '用户【admin】编辑用户:4成功', '112.96.240.198', '1', '1567328694');
INSERT INTO `think_log` VALUES ('42', '1', 'admin', '用户【admin】更改设置:成功', '112.96.240.198', '1', '1567329132');
INSERT INTO `think_log` VALUES ('43', '1', 'admin', '用户【admin】编辑用户:4成功', '112.96.240.198', '1', '1567329238');
INSERT INTO `think_log` VALUES ('44', '1', 'admin', '用户【admin】编辑用户:4成功', '112.96.240.198', '1', '1567329260');
INSERT INTO `think_log` VALUES ('45', '1', 'admin', '用户【admin】编辑用户:1成功', '112.96.240.198', '1', '1567329280');
INSERT INTO `think_log` VALUES ('46', '1', 'admin', '用户【admin】编辑用户:1成功', '112.96.240.198', '1', '1567329398');
INSERT INTO `think_log` VALUES ('47', '1', 'admin', '用户【admin】更改设置:成功', '112.96.240.198', '1', '1567329432');
INSERT INTO `think_log` VALUES ('48', '1', 'admin', '用户【admin】编辑用户:4成功', '112.96.240.198', '1', '1567329585');
INSERT INTO `think_log` VALUES ('49', '1', 'admin', '用户【admin】编辑用户:1成功', '112.96.240.198', '1', '1567329606');
INSERT INTO `think_log` VALUES ('50', '1', 'admin', '用户【admin】编辑用户:1成功', '112.96.240.198', '1', '1567329633');
INSERT INTO `think_log` VALUES ('51', '1', 'admin', '用户【admin】编辑用户:4成功', '112.96.240.198', '1', '1567329970');
INSERT INTO `think_log` VALUES ('52', '1', 'admin', '用户【admin】编辑用户:1成功', '112.96.240.198', '1', '1567329990');
INSERT INTO `think_log` VALUES ('53', '1', 'admin', '用户【admin】编辑用户:4成功', '112.96.240.198', '1', '1567330161');
INSERT INTO `think_log` VALUES ('54', '1', 'admin', '用户【admin】编辑用户:1成功', '112.96.240.198', '1', '1567330182');
INSERT INTO `think_log` VALUES ('55', '1', 'admin', '用户【admin】更改设置:成功', '112.96.240.198', '1', '1567330415');
INSERT INTO `think_log` VALUES ('56', '1', 'admin', '用户【admin】编辑用户:1成功', '112.96.240.198', '1', '1567330514');
INSERT INTO `think_log` VALUES ('57', '1', 'admin', '用户【admin】编辑用户:4成功', '112.96.240.198', '1', '1567330549');
INSERT INTO `think_log` VALUES ('58', '1', 'admin', '用户【admin】编辑用户:4成功', '112.96.240.198', '1', '1567330564');
INSERT INTO `think_log` VALUES ('59', '1', 'admin', '用户【admin】编辑用户:1成功', '112.96.240.198', '1', '1567330592');
INSERT INTO `think_log` VALUES ('60', '1', 'admin', '用户【admin】编辑用户:4成功', '112.96.240.198', '1', '1567330757');
INSERT INTO `think_log` VALUES ('61', '1', 'admin', '用户【admin】编辑用户:1成功', '112.96.240.198', '1', '1567330771');
INSERT INTO `think_log` VALUES ('62', '1', 'admin', '用户【admin】编辑用户:1成功', '112.96.240.198', '1', '1567330961');
INSERT INTO `think_log` VALUES ('63', '1', 'admin', '用户【admin】编辑用户:1成功', '112.96.240.198', '1', '1567331268');
INSERT INTO `think_log` VALUES ('64', '1', 'admin', '用户【admin】编辑用户:1成功', '112.96.240.198', '1', '1567331287');
INSERT INTO `think_log` VALUES ('65', '1', 'admin', '用户【admin】编辑用户:4成功', '112.96.240.198', '1', '1567331371');
INSERT INTO `think_log` VALUES ('66', '1', 'admin', '用户【admin】更改设置:成功', '112.96.240.198', '1', '1567331798');
INSERT INTO `think_log` VALUES ('67', '1', 'admin', '用户【admin】编辑用户:1成功', '112.96.240.198', '1', '1567331827');
INSERT INTO `think_log` VALUES ('68', '1', 'admin', '用户【admin】编辑用户:1成功', '112.96.240.198', '1', '1567331868');
INSERT INTO `think_log` VALUES ('69', '1', 'admin', '用户【admin】编辑用户:4成功', '112.96.240.198', '1', '1567331902');
INSERT INTO `think_log` VALUES ('70', '1', 'admin', '用户【admin】编辑用户:1成功', '112.96.240.198', '1', '1567332069');
INSERT INTO `think_log` VALUES ('71', '1', 'admin', '用户【admin】编辑用户:1成功', '112.96.240.198', '1', '1567332093');
INSERT INTO `think_log` VALUES ('72', '1', 'admin', '用户【admin】编辑用户:4成功', '112.96.240.198', '1', '1567332143');
INSERT INTO `think_log` VALUES ('73', '1', 'admin', '用户【admin】编辑用户:4成功', '112.96.240.198', '1', '1567332292');
INSERT INTO `think_log` VALUES ('74', '1', 'admin', '用户【admin】更改设置:成功', '112.96.240.198', '1', '1567332312');
INSERT INTO `think_log` VALUES ('75', '1', 'admin', '用户【admin】编辑用户:1成功', '112.96.240.198', '1', '1567332333');
INSERT INTO `think_log` VALUES ('76', '1', 'admin', '用户【admin】更改设置:成功', '112.96.240.198', '1', '1567332499');
INSERT INTO `think_log` VALUES ('77', '1', 'admin', '用户【admin】编辑用户:3成功', '112.96.240.198', '1', '1567332716');
INSERT INTO `think_log` VALUES ('78', '1', 'admin', '用户【admin】编辑用户:3成功', '112.96.240.198', '1', '1567332738');
INSERT INTO `think_log` VALUES ('79', '1', 'admin', '用户【admin】编辑用户:4成功', '112.96.240.198', '1', '1567333413');
INSERT INTO `think_log` VALUES ('80', '1', 'admin', '用户【admin】编辑用户:4成功', '112.96.240.198', '1', '1567333429');
INSERT INTO `think_log` VALUES ('81', '1', 'admin', '用户【admin】更改设置:成功', '112.96.240.198', '1', '1567333533');
INSERT INTO `think_log` VALUES ('82', '1', 'admin', '用户【admin】更改设置:成功', '112.96.240.198', '1', '1567333590');
INSERT INTO `think_log` VALUES ('83', '1', 'admin', '用户【admin】编辑用户:1成功', '112.96.240.223', '1', '1567334879');
INSERT INTO `think_log` VALUES ('84', '1', 'admin', '用户【admin】编辑用户:1成功', '112.96.240.223', '1', '1567334920');
INSERT INTO `think_log` VALUES ('85', '1', 'admin', '用户【admin】编辑用户:1成功', '112.96.240.223', '1', '1567334976');
INSERT INTO `think_log` VALUES ('86', '1', 'admin', '用户【admin】编辑用户:4成功', '112.96.240.223', '1', '1567335002');
INSERT INTO `think_log` VALUES ('87', '1', 'admin', '用户【admin】登录成功', '112.96.240.223', '1', '1567335724');
INSERT INTO `think_log` VALUES ('88', '1', 'admin', '用户【admin】审核提币:2成功', '112.96.240.223', '1', '1567335803');
INSERT INTO `think_log` VALUES ('89', '1', 'admin', '用户【admin】编辑用户:4成功', '112.96.240.223', '1', '1567337509');
INSERT INTO `think_log` VALUES ('90', '1', 'admin', '用户【admin】编辑用户:1成功', '112.96.240.223', '1', '1567337537');
INSERT INTO `think_log` VALUES ('91', '1', 'admin', '用户【admin】编辑用户:4成功', '112.96.240.223', '1', '1567337796');
INSERT INTO `think_log` VALUES ('92', '1', 'admin', '用户【admin】编辑用户:4成功', '112.96.240.223', '1', '1567337868');
INSERT INTO `think_log` VALUES ('93', '1', 'admin', '用户【admin】编辑用户:4成功', '112.96.240.223', '1', '1567338033');
INSERT INTO `think_log` VALUES ('94', '1', 'admin', '用户【admin】编辑用户:1成功', '112.96.240.223', '1', '1567338072');
INSERT INTO `think_log` VALUES ('95', '1', 'admin', '用户【admin】编辑用户:1成功', '112.96.240.223', '1', '1567338242');
INSERT INTO `think_log` VALUES ('96', '1', 'admin', '用户【admin】编辑用户:1成功', '112.96.240.223', '1', '1567338261');
INSERT INTO `think_log` VALUES ('97', '1', 'admin', '用户【admin】编辑用户:4成功', '112.96.240.223', '1', '1567338330');
INSERT INTO `think_log` VALUES ('98', '1', 'admin', '用户【admin】登录成功', '112.96.240.223', '1', '1567338371');
INSERT INTO `think_log` VALUES ('99', '1', 'admin', '用户【admin】编辑用户:4成功', '112.96.240.223', '1', '1567338749');
INSERT INTO `think_log` VALUES ('100', '1', 'admin', '用户【admin】编辑用户:1成功', '112.96.240.223', '1', '1567338777');
INSERT INTO `think_log` VALUES ('101', '1', 'admin', '用户【admin】更改设置:成功', '112.96.240.223', '1', '1567338944');
INSERT INTO `think_log` VALUES ('102', '1', 'admin', '用户【admin】编辑用户:1成功', '112.96.240.223', '1', '1567338990');
INSERT INTO `think_log` VALUES ('103', '1', 'admin', '用户【admin】编辑用户:4成功', '112.96.240.223', '1', '1567339017');
INSERT INTO `think_log` VALUES ('104', '1', 'admin', '用户【admin】编辑用户:1成功', '112.96.240.223', '1', '1567339166');
INSERT INTO `think_log` VALUES ('105', '1', 'admin', '用户【admin】更改设置:成功', '112.96.240.223', '1', '1567339195');
INSERT INTO `think_log` VALUES ('106', '1', 'admin', '用户【admin】编辑用户:4成功', '112.96.240.223', '1', '1567339214');
INSERT INTO `think_log` VALUES ('107', '1', 'admin', '用户【admin】编辑用户:1成功', '112.96.240.223', '1', '1567339302');
INSERT INTO `think_log` VALUES ('108', '1', 'admin', '用户【admin】编辑用户:1成功', '112.96.240.223', '1', '1567339525');
INSERT INTO `think_log` VALUES ('109', '1', 'admin', '用户【admin】编辑用户:1成功', '112.96.240.223', '1', '1567339553');
INSERT INTO `think_log` VALUES ('110', '1', 'admin', '用户【admin】编辑用户:4成功', '112.96.240.223', '1', '1567339571');
INSERT INTO `think_log` VALUES ('111', '1', 'admin', '用户【admin】编辑用户:1成功', '112.96.240.223', '1', '1567339797');
INSERT INTO `think_log` VALUES ('112', '1', 'admin', '用户【admin】编辑用户:1成功', '112.96.240.223', '1', '1567339819');
INSERT INTO `think_log` VALUES ('113', '1', 'admin', '用户【admin】编辑用户:4成功', '112.96.240.223', '1', '1567339832');
INSERT INTO `think_log` VALUES ('114', '1', 'admin', '用户【admin】编辑用户:1成功', '112.96.240.223', '1', '1567339993');
INSERT INTO `think_log` VALUES ('115', '1', 'admin', '用户【admin】编辑用户:4成功', '112.96.240.223', '1', '1567340031');
INSERT INTO `think_log` VALUES ('116', '1', 'admin', '用户【admin】编辑用户:1成功', '112.96.240.223', '1', '1567340049');
INSERT INTO `think_log` VALUES ('117', '1', 'admin', '用户【admin】编辑用户:1成功', '112.96.240.223', '1', '1567340177');
INSERT INTO `think_log` VALUES ('118', '1', 'admin', '用户【admin】编辑用户:1成功', '112.96.240.223', '1', '1567340194');
INSERT INTO `think_log` VALUES ('119', '1', 'admin', '用户【admin】编辑用户:4成功', '112.96.240.223', '1', '1567340207');
INSERT INTO `think_log` VALUES ('120', '1', 'admin', '用户【admin】编辑用户:3成功', '112.96.240.223', '1', '1567340401');
INSERT INTO `think_log` VALUES ('121', '1', 'admin', '用户【admin】更改设置:成功', '112.96.240.223', '1', '1567340509');
INSERT INTO `think_log` VALUES ('122', '1', 'admin', '用户【admin】更改设置:成功', '112.96.240.223', '1', '1567341675');
INSERT INTO `think_log` VALUES ('123', '1', 'admin', '用户【admin】编辑用户:4成功', '112.96.240.223', '1', '1567341691');
INSERT INTO `think_log` VALUES ('124', '1', 'admin', '用户【admin】编辑用户:1成功', '112.96.240.223', '1', '1567341715');
INSERT INTO `think_log` VALUES ('125', '1', 'admin', '用户【admin】更改设置:成功', '112.96.240.223', '1', '1567341936');
INSERT INTO `think_log` VALUES ('126', '1', 'admin', '用户【admin】编辑用户:4成功', '112.96.240.223', '1', '1567341950');
INSERT INTO `think_log` VALUES ('127', '1', 'admin', '用户【admin】编辑用户:1成功', '112.96.240.223', '1', '1567341970');
INSERT INTO `think_log` VALUES ('128', '1', 'admin', '用户【admin】登录成功', '182.38.40.193', '1', '1567349696');
INSERT INTO `think_log` VALUES ('129', '1', 'admin', '用户【admin】编辑用户:4成功', '182.38.40.193', '1', '1567349722');
INSERT INTO `think_log` VALUES ('130', '1', 'admin', '用户【admin】编辑用户:1成功', '182.38.40.193', '1', '1567349742');
INSERT INTO `think_log` VALUES ('131', '1', 'admin', '用户【admin】编辑用户:4成功', '182.38.40.193', '1', '1567350114');
INSERT INTO `think_log` VALUES ('132', '1', 'admin', '用户【admin】登录成功', '112.96.241.10', '1', '1567418368');
INSERT INTO `think_log` VALUES ('133', '1', 'admin', '用户【admin】编辑用户:4成功', '112.96.241.10', '1', '1567419514');
INSERT INTO `think_log` VALUES ('134', '1', 'admin', '用户【admin】编辑用户:4成功', '112.96.241.10', '1', '1567419608');
INSERT INTO `think_log` VALUES ('135', '1', 'admin', '用户【admin】编辑用户:6成功', '112.96.241.10', '1', '1567420168');
INSERT INTO `think_log` VALUES ('136', '1', 'admin', '用户【admin】编辑用户:6成功', '112.96.241.10', '1', '1567420200');
INSERT INTO `think_log` VALUES ('137', '1', 'admin', '用户【admin】编辑用户:4成功', '112.96.241.10', '1', '1567420611');
INSERT INTO `think_log` VALUES ('138', '1', 'admin', '用户【admin】编辑用户:2成功', '112.96.241.10', '1', '1567420681');
INSERT INTO `think_log` VALUES ('139', '1', 'admin', '用户【admin】编辑用户:2成功', '112.96.241.10', '1', '1567420748');
INSERT INTO `think_log` VALUES ('140', '1', 'admin', '用户【admin】编辑用户:2成功', '112.96.241.10', '1', '1567421151');
INSERT INTO `think_log` VALUES ('141', '1', 'admin', '用户【admin】编辑用户:2成功', '112.96.241.10', '1', '1567421363');
INSERT INTO `think_log` VALUES ('142', '1', 'admin', '用户【admin】登录成功', '112.96.240.194', '1', '1567434011');
INSERT INTO `think_log` VALUES ('143', '1', 'admin', '用户【admin】更改设置:成功', '112.96.240.194', '1', '1567434597');
INSERT INTO `think_log` VALUES ('144', '1', 'admin', '用户【admin】更改设置:成功', '112.96.240.194', '1', '1567434623');
INSERT INTO `think_log` VALUES ('145', '1', 'admin', '用户【admin】编辑用户:4成功', '112.96.240.194', '1', '1567434706');
INSERT INTO `think_log` VALUES ('146', '1', 'admin', '用户【admin】登录成功', '112.96.240.17', '1', '1567474452');
INSERT INTO `think_log` VALUES ('147', '1', 'admin', '用户【admin】更改设置:成功', '112.96.240.17', '1', '1567475051');
INSERT INTO `think_log` VALUES ('148', '1', 'admin', '用户【admin】编辑用户:1成功', '112.96.240.17', '1', '1567478741');
INSERT INTO `think_log` VALUES ('149', '1', 'admin', '用户【admin】审核提币:1成功', '112.96.240.17', '1', '1567479025');
INSERT INTO `think_log` VALUES ('150', '1', 'admin', '用户【admin】审核提币:3成功', '112.96.240.17', '1', '1567479767');
INSERT INTO `think_log` VALUES ('151', '1', 'admin', '用户【admin】登录成功', '27.197.30.197', '1', '1567556637');
INSERT INTO `think_log` VALUES ('152', '1', 'admin', '用户【admin】登录成功', '27.197.30.197', '1', '1567557008');
INSERT INTO `think_log` VALUES ('153', '1', 'admin', '用户【admin】更改设置:成功', '112.96.240.29', '1', '1567561711');
INSERT INTO `think_log` VALUES ('154', '1', 'admin', '用户【admin】登录成功', '112.96.240.29', '1', '1567570239');
INSERT INTO `think_log` VALUES ('155', '1', 'admin', '用户【admin】登录成功', '112.224.21.53', '1', '1567921792');
INSERT INTO `think_log` VALUES ('156', '1', 'admin', '用户【admin】登录成功', '153.118.178.77', '1', '1568135943');
INSERT INTO `think_log` VALUES ('157', '1', 'admin', '用户【admin】登录成功', '112.96.240.37', '1', '1568169683');
INSERT INTO `think_log` VALUES ('158', '1', 'admin', '用户【admin】登录成功', '112.96.240.59', '1', '1568189654');
INSERT INTO `think_log` VALUES ('159', '1', 'admin', '用户【admin】登录成功', '112.96.241.155', '1', '1568246869');
INSERT INTO `think_log` VALUES ('160', '1', 'admin', '用户【admin】登录成功', '112.96.241.155', '1', '1568246938');
INSERT INTO `think_log` VALUES ('161', '1', 'admin', '用户【admin】登录成功', '112.96.241.155', '1', '1568247460');
INSERT INTO `think_log` VALUES ('162', '1', 'admin', '用户【admin】更改设置:成功', '112.96.241.155', '1', '1568247521');
INSERT INTO `think_log` VALUES ('163', '1', 'admin', '用户【admin】删除用户:2失败', '112.96.241.155', '0', '1568247577');
INSERT INTO `think_log` VALUES ('164', '1', 'admin', '用户【admin】删除用户:2成功', '112.96.241.155', '1', '1568247577');
INSERT INTO `think_log` VALUES ('165', '1', 'admin', '用户【admin】删除用户:5失败', '112.96.241.155', '0', '1568247582');
INSERT INTO `think_log` VALUES ('166', '1', 'admin', '用户【admin】删除用户:5成功', '112.96.241.155', '1', '1568247582');
INSERT INTO `think_log` VALUES ('167', '1', 'admin', '用户【admin】删除用户:7失败', '112.96.241.155', '0', '1568247591');
INSERT INTO `think_log` VALUES ('168', '1', 'admin', '用户【admin】删除用户:7成功', '112.96.241.155', '1', '1568247591');
INSERT INTO `think_log` VALUES ('169', '1', 'admin', '用户【admin】登录成功', '112.96.240.183', '1', '1568279286');
INSERT INTO `think_log` VALUES ('170', '1', 'admin', '用户【admin】登录失败：密码错误', '112.224.5.13', '2', '1568354674');
INSERT INTO `think_log` VALUES ('171', '1', 'admin', '用户【admin】登录成功', '112.224.5.13', '1', '1568354711');
INSERT INTO `think_log` VALUES ('172', '1', 'admin', '用户【admin】登录成功', '112.224.5.13', '1', '1568354827');
INSERT INTO `think_log` VALUES ('173', '1', 'admin', '用户【admin】编辑用户:4成功', '112.224.5.13', '1', '1568354846');
INSERT INTO `think_log` VALUES ('174', '1', 'admin', '用户【admin】编辑用户:4成功', '112.96.241.51', '1', '1568355538');
INSERT INTO `think_log` VALUES ('175', '1', 'admin', '用户【admin】编辑用户:4成功', '112.96.241.51', '1', '1568355682');
INSERT INTO `think_log` VALUES ('176', '1', 'admin', '用户【admin】编辑用户:4成功', '112.96.241.51', '1', '1568355774');
INSERT INTO `think_log` VALUES ('177', '1', 'admin', '用户【admin】编辑用户:4成功', '112.96.241.51', '1', '1568355971');
INSERT INTO `think_log` VALUES ('178', '1', 'admin', '用户【admin】编辑用户:4成功', '112.96.241.51', '1', '1568355994');
INSERT INTO `think_log` VALUES ('179', '1', 'admin', '用户【admin】更改设置:成功', '112.96.241.51', '1', '1568356160');
INSERT INTO `think_log` VALUES ('180', '1', 'admin', '用户【admin】编辑用户:4成功', '112.96.241.51', '1', '1568356185');
INSERT INTO `think_log` VALUES ('181', '1', 'admin', '用户【admin】登录成功', '112.96.240.166', '1', '1568370169');
INSERT INTO `think_log` VALUES ('182', '1', 'admin', '用户【admin】登录成功', '112.96.241.88', '1', '1568533408');
INSERT INTO `think_log` VALUES ('183', '1', 'admin', '用户【admin】更改设置:成功', '112.96.241.88', '1', '1568533845');
INSERT INTO `think_log` VALUES ('184', '1', 'admin', '用户【admin】审核用户:8成功', '112.96.241.88', '1', '1568533971');
INSERT INTO `think_log` VALUES ('185', '1', 'admin', '用户【admin】登录成功', '153.118.44.151', '1', '1568627885');
INSERT INTO `think_log` VALUES ('186', '1', 'admin', '用户【admin】登录失败：密码错误', '183.31.244.210', '2', '1568628003');
INSERT INTO `think_log` VALUES ('187', '1', 'admin', '用户【admin】登录成功', '183.31.244.210', '1', '1568628021');

-- -----------------------------
-- Table structure for `think_login_log`
-- -----------------------------
DROP TABLE IF EXISTS `think_login_log`;
CREATE TABLE `think_login_log` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `merchant_id` int(11) DEFAULT NULL,
  `login_time` int(11) DEFAULT NULL,
  `update_time` int(11) DEFAULT NULL,
  `online` smallint(6) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=52 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `think_login_log`
-- -----------------------------
INSERT INTO `think_login_log` VALUES ('1', '1', '1567305589', '1567306469', '1');
INSERT INTO `think_login_log` VALUES ('2', '4', '1567306498', '1567307192', '1');
INSERT INTO `think_login_log` VALUES ('3', '1', '1567307251', '1567307863', '1');
INSERT INTO `think_login_log` VALUES ('4', '4', '1567307933', '1567307990', '1');
INSERT INTO `think_login_log` VALUES ('5', '1', '1567308056', '1567308129', '1');
INSERT INTO `think_login_log` VALUES ('6', '4', '1567308470', '1567308557', '1');
INSERT INTO `think_login_log` VALUES ('7', '1', '1567308613', '1567308656', '1');
INSERT INTO `think_login_log` VALUES ('8', '4', '1567308735', '1567308813', '1');
INSERT INTO `think_login_log` VALUES ('9', '1', '1567308851', '1567309225', '1');
INSERT INTO `think_login_log` VALUES ('10', '4', '1567309570', '1567311756', '1');
INSERT INTO `think_login_log` VALUES ('11', '3', '1567313267', '1567316081', '0');
INSERT INTO `think_login_log` VALUES ('12', '4', '1567316108', '1567319734', '1');
INSERT INTO `think_login_log` VALUES ('13', '1', '1567319775', '1567319834', '1');
INSERT INTO `think_login_log` VALUES ('14', '4', '1567319867', '1567319900', '1');
INSERT INTO `think_login_log` VALUES ('15', '1', '1567319960', '1567321105', '1');
INSERT INTO `think_login_log` VALUES ('16', '4', '1567321192', '1567321369', '1');
INSERT INTO `think_login_log` VALUES ('17', '1', '1567321488', '1567321520', '1');
INSERT INTO `think_login_log` VALUES ('18', '4', '1567325100', '1567325134', '1');
INSERT INTO `think_login_log` VALUES ('19', '1', '1567325166', '1567325177', '1');
INSERT INTO `think_login_log` VALUES ('20', '4', '1567325234', '1567325268', '1');
INSERT INTO `think_login_log` VALUES ('21', '1', '1567325305', '1567327633', '0');
INSERT INTO `think_login_log` VALUES ('22', '1', '1567327649', '1567335243', '1');
INSERT INTO `think_login_log` VALUES ('23', '4', '1567327861', '1567335093', '1');
INSERT INTO `think_login_log` VALUES ('24', '4', '1567336028', '1567340568', '1');
INSERT INTO `think_login_log` VALUES ('25', '1', '1567338082', '1567338262', '1');
INSERT INTO `think_login_log` VALUES ('26', '1', '1567338172', '1567338180', '1');
INSERT INTO `think_login_log` VALUES ('27', '1', '1567338399', '1567340422', '1');
INSERT INTO `think_login_log` VALUES ('28', '3', '1567340441', '1567340452', '1');
INSERT INTO `think_login_log` VALUES ('29', '3', '1567340554', '1567341287', '1');
INSERT INTO `think_login_log` VALUES ('30', '4', '1567340697', '1567342087', '1');
INSERT INTO `think_login_log` VALUES ('31', '1', '1567342119', '1567345655', '0');
INSERT INTO `think_login_log` VALUES ('32', '4', '1567349765', '1567350374', '1');
INSERT INTO `think_login_log` VALUES ('33', '3', '1567418421', '1567423558', '0');
INSERT INTO `think_login_log` VALUES ('34', '5', '1567418968', '1567419088', '1');
INSERT INTO `think_login_log` VALUES ('35', '5', '1567419280', '1567420831', '1');
INSERT INTO `think_login_log` VALUES ('36', '4', '1567419298', '1567421259', '1');
INSERT INTO `think_login_log` VALUES ('37', '6', '1567420090', '1567420841', '1');
INSERT INTO `think_login_log` VALUES ('38', '2', '1567420870', '1567423303', '1');
INSERT INTO `think_login_log` VALUES ('39', '3', '1567423590', '1567423687', '1');
INSERT INTO `think_login_log` VALUES ('40', '5', '1567423720', '1567432136', '0');
INSERT INTO `think_login_log` VALUES ('41', '7', '1567423739', '1567423846', '1');
INSERT INTO `think_login_log` VALUES ('42', '4', '1567434720', '1567434808', '1');
INSERT INTO `think_login_log` VALUES ('43', '5', '1567475262', '1567479194', '0');
INSERT INTO `think_login_log` VALUES ('44', '1', '1567478711', '1567479054', '1');
INSERT INTO `think_login_log` VALUES ('45', '3', '1567479629', '1567481273', '1');
INSERT INTO `think_login_log` VALUES ('46', '6', '1567501475', '1567502485', '1');
INSERT INTO `think_login_log` VALUES ('47', '6', '1567501945', '1567502188', '1');
INSERT INTO `think_login_log` VALUES ('48', '5', '1567562322', '1567562347', '1');
INSERT INTO `think_login_log` VALUES ('49', '4', '1568354792', '1568356285', '1');
INSERT INTO `think_login_log` VALUES ('50', '8', '1568533983', '1568534351', '1');
INSERT INTO `think_login_log` VALUES ('51', '8', '1568534397', '1568534419', '1');

-- -----------------------------
-- Table structure for `think_member`
-- -----------------------------
DROP TABLE IF EXISTS `think_member`;
CREATE TABLE `think_member` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `account` varchar(64) DEFAULT NULL COMMENT '邮件或者手机',
  `nickname` varchar(32) DEFAULT NULL COMMENT '昵称',
  `sex` int(10) DEFAULT NULL COMMENT '1男2女',
  `password` char(32) DEFAULT NULL,
  `group_id` int(11) DEFAULT NULL,
  `head_img` varchar(128) DEFAULT NULL COMMENT '头像',
  `integral` int(11) DEFAULT '0' COMMENT '积分',
  `money` int(11) DEFAULT '0' COMMENT '账户余额',
  `mobile` varchar(11) DEFAULT NULL COMMENT '认证的手机号码',
  `create_time` int(11) DEFAULT '0' COMMENT '注册时间',
  `update_time` int(11) DEFAULT NULL COMMENT '最后一次登录',
  `login_num` varchar(15) DEFAULT NULL COMMENT '登录次数',
  `status` tinyint(1) DEFAULT NULL COMMENT '1正常  0 禁用',
  `closed` tinyint(1) DEFAULT '0' COMMENT '0正常，1删除',
  `token` char(32) DEFAULT '0' COMMENT '令牌',
  `session_id` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=212066 DEFAULT CHARSET=utf8;


-- -----------------------------
-- Table structure for `think_member_group`
-- -----------------------------
DROP TABLE IF EXISTS `think_member_group`;
CREATE TABLE `think_member_group` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '留言Id',
  `group_name` varchar(32) NOT NULL COMMENT '留言评论作者',
  `status` tinyint(1) DEFAULT NULL,
  `create_time` int(11) DEFAULT NULL COMMENT '留言回复时间',
  `update_time` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=127 DEFAULT CHARSET=utf8 COMMENT='文章评论表';

-- -----------------------------
-- Records of `think_member_group`
-- -----------------------------
INSERT INTO `think_member_group` VALUES ('1', '系统组', '1', '1441616559', '1525405964');
INSERT INTO `think_member_group` VALUES ('2', '游客组', '1', '1441617195', '1502940499');
INSERT INTO `think_member_group` VALUES ('3', 'VIP1', '1', '1441769224', '1502940506');

-- -----------------------------
-- Table structure for `think_merchant`
-- -----------------------------
DROP TABLE IF EXISTS `think_merchant`;
CREATE TABLE `think_merchant` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) NOT NULL COMMENT '姓名',
  `mobile` char(11) NOT NULL COMMENT '手机号',
  `password` char(32) NOT NULL COMMENT '密码',
  `paypassword` char(32) DEFAULT NULL COMMENT '交易密码',
  `invite` varchar(15) DEFAULT NULL COMMENT '邀请码',
  `idcard` varchar(50) DEFAULT NULL COMMENT '身份证号',
  `idcard_zheng` varchar(255) DEFAULT NULL COMMENT '正面照',
  `idcard_fan` varchar(255) DEFAULT NULL COMMENT '反面照',
  `appid` char(16) NOT NULL COMMENT '商户id',
  `key` char(32) NOT NULL COMMENT 'MD5Key',
  `addtime` int(11) NOT NULL COMMENT '注册时间',
  `status` tinyint(2) NOT NULL DEFAULT '1',
  `usdt` decimal(20,8) DEFAULT '0.00000000' COMMENT '活动的usdt',
  `usdtd` decimal(20,8) DEFAULT '0.00000000' COMMENT '冻结usdt',
  `headpic` varchar(255) DEFAULT NULL COMMENT '头像',
  `ga` varchar(255) DEFAULT NULL,
  `merchant_tibi_fee` decimal(10,4) DEFAULT '0.0000',
  `user_withdraw_fee` decimal(10,4) DEFAULT '0.0000',
  `user_recharge_fee` decimal(10,4) DEFAULT '0.0000',
  `pid` int(11) DEFAULT '0',
  `reg_check` tinyint(4) DEFAULT '0' COMMENT '0:待审核，1:通过，2：拒绝',
  `agent_check` tinyint(4) DEFAULT '0' COMMENT '0:未提交，1：通过，2：拒绝，3：已提交申请',
  `trader_check` tinyint(4) DEFAULT '0' COMMENT '交易员审核，0:未提交，1：通过，2：拒绝，3：已提交申请',
  `usdtb` varchar(200) DEFAULT NULL COMMENT 'omni地址',
  `usdte` varchar(255) DEFAULT NULL COMMENT 'erc地址',
  `trader_recharge_fee` decimal(10,4) DEFAULT '0.0000',
  `c_bank` varchar(20) DEFAULT NULL,
  `c_bank_detail` varchar(50) DEFAULT NULL,
  `c_bank_card` varchar(50) DEFAULT NULL,
  `c_wechat_account` varchar(50) DEFAULT NULL,
  `c_wechat_img` varchar(255) DEFAULT NULL,
  `c_alipay_account` varchar(50) DEFAULT NULL,
  `c_alipay_img` varchar(255) DEFAULT NULL,
  `transact` int(11) DEFAULT '0',
  `averge` int(11) DEFAULT '0',
  `online` tinyint(4) DEFAULT '0',
  `pp_amount` int(11) DEFAULT '0',
  `transact_buy` int(11) DEFAULT '0',
  `averge_buy` int(11) DEFAULT '0',
  `trader_trader_get` decimal(10,2) DEFAULT '0.00',
  `trader_parent_get` decimal(10,2) DEFAULT '0.00',
  `trader_merchant_parent_get` decimal(10,2) DEFAULT '0.00',
  `pptrader` varchar(255) DEFAULT NULL,
  `merchant_pk_fee` decimal(10,2) DEFAULT '0.00' COMMENT '商户盘口费率',
  `reg_type` tinyint(4) DEFAULT NULL COMMENT '1,商户,2,承兑商,3,代理商',
  `recharge_amount` decimal(20,8) DEFAULT '0.00000000' COMMENT '充值数量汇总',
  `withdraw_amount` decimal(20,8) DEFAULT '0.00000000' COMMENT '提币数量汇总',
  `ad_on_sell` int(11) DEFAULT '0' COMMENT '在售广告数',
  `ad_on_buy` int(11) DEFAULT '0' COMMENT '求购广告数',
  `order_sell_success_num` int(11) DEFAULT '0' COMMENT '出售成功次数',
  `order_buy_success_num` int(11) DEFAULT '0' COMMENT '求购成功次数',
  `order_sell_usdt_amount` decimal(20,8) DEFAULT '0.00000000' COMMENT '总出售usdt数量',
  `order_buy_usdt_amount` decimal(20,8) DEFAULT '0.00000000' COMMENT '总求购usdt数量',
  `nickname` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `think_merchant`
-- -----------------------------
INSERT INTO `think_merchant` VALUES ('1', '商户', '13866889900', 'e10adc3949ba59abbe56e057f20f883e', 'e10adc3949ba59abbe56e057f20f883e', '', '123456789012345678', '20190829/159d42ce9d24a24eb9edc0e0f478873a.png', '20190829/4787ebebbbc424cc5f2f78f3d0c3ed88.png', 'QndLSfX9Q0uaVuak', '24ccfcdb5d8f5b7a86e9df6348a20347', '1567083094', '1', '4073.32674750', '0.00000000', '', 'IB7KS5ON3OPT7R5C|0|0', '3.0000', '0.0000', '0.0000', '0', '1', '0', '0', '', '', '0.0000', '', '', '', '', '', '', '', '0', '0', '0', '0', '0', '0', '0.00', '0.00', '0.00', '', '0.35', '1', '0.00000000', '500.00000000', '0', '0', '4', '59', '195.81900648', '37923.15842311', '测试商户');
INSERT INTO `think_merchant` VALUES ('3', '代理商', '13800138002', '4297f44b13955235245b2497399d7a93', 'e10adc3949ba59abbe56e057f20f883e', 'JHKZNB', '123456789012345672', '20190829/c9c1743ce060be6483ab63f67b61e404.png', '20190829/3b940ccbd2c812acd3e5416299950e3f.png', 'LZHidkVZjcbC1EKs', '7c59f21bc1f63d1f67adee78cc87977d', '1567083174', '1', '500.00000000', '0.00000000', '', 'PVOIL2HQICVLBUTN|0|0', '2.0000', '0.0000', '0.0000', '0', '1', '1', '0', '', '', '0.0000', '', '', '', '', '', '', '', '0', '0', '0', '0', '0', '0', '0.00', '0.15', '0.10', '', '0.30', '3', '0.00000000', '500.00000000', '0', '0', '0', '0', '0.00000000', '0.00000000', '测试代理商');
INSERT INTO `think_merchant` VALUES ('4', '承兑商二', '13800138003', '4297f44b13955235245b2497399d7a93', 'e10adc3949ba59abbe56e057f20f883e', '', '123456789013345678', '20190830/a1b2d1847c6a4819707f13d9dd916a3b.jpg', '20190830/a52fad649cfe04d0db5017a24fd76761.png', 'tbGsBV7c51AELp4f', 'b6a68585a13a7558fa72ee041480b303', '1567127578', '1', '0.00000000', '0.00000000', '', 'J2OSJDZA5QBJ2O6Y|0|0', '2.0000', '0.0000', '0.0000', '0', '1', '0', '1', '', '0x6d8ffc3c999de02900a7e13a58ee5472b0029a59', '0.0000', '', '', '', '', '', '', '', '53', '121', '0', '53', '2', '96', '0.15', '0.00', '0.00', '', '0.00', '2', '0.00000000', '0.00000000', '0', '0', '53', '2', '35971.05447458', '84.77502889', '承兑商二');
INSERT INTO `think_merchant` VALUES ('6', '陈超', '18596386668', '96e79218965eb72c92a549dd5a330112', 'e3ceb5881a0a1fdaad01296d7554868d', '', '370983198701100558', '20190902/a02fa6ad96ea2ee5df9cbd88f8528404.jpg', '20190902/bc65b9143e7c5831f99e45fb1315d1c9.jpg', 'cIPBDs97dP2iMklV', 'c46c36e3f2dcccd54806a89c373ae856', '1567419865', '1', '1000.00000000', '0.00000000', '', 'IB7KS5ON3OPT7R5C|0|0', '2.0000', '0.0000', '0.0000', '3', '1', '0', '1', '', '0xd8865a9f321e8241629afca7e447d89b1937f11b', '0.0000', '', '', '', '', '', '', '', '0', '0', '0', '0', '0', '0', '0.15', '0.00', '0.00', '', '0.00', '2', '0.00000000', '0.00000000', '0', '0', '0', '0', '0.00000000', '0.00000000', '小霸王');
INSERT INTO `think_merchant` VALUES ('8', '郝栋超', '13383309776', 'e10adc3949ba59abbe56e057f20f883e', '7c7ac29f70178840ea655e24e76aa0b0', '', '130481198702031078', '20190915/2b6718db8ea910abebb238e30ee33dc3.jpg', '20190915/1dec7f830d88a38792d64af87171a446.png', 'DtATYOzUr91UeU5b', 'ee9ce85f380ac79852902ae63cf52aee', '1568533961', '1', '0.00000000', '0.00000000', '', '', '0.0000', '0.0000', '0.0000', '0', '1', '0', '0', '', '', '0.0000', '', '', '', '', '', '', '', '0', '0', '0', '0', '0', '0', '0.00', '0.00', '0.00', '', '0.00', '1', '0.00000000', '0.00000000', '0', '0', '0', '0', '0.00000000', '0.00000000', '1111');

-- -----------------------------
-- Table structure for `think_merchant_apilog`
-- -----------------------------
DROP TABLE IF EXISTS `think_merchant_apilog`;
CREATE TABLE `think_merchant_apilog` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `uid` int(11) DEFAULT NULL,
  `duid` int(11) DEFAULT NULL,
  `api_name` varchar(50) DEFAULT NULL,
  `request_param` varchar(255) DEFAULT NULL,
  `return_param` text,
  `create_time` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;


-- -----------------------------
-- Table structure for `think_merchant_bankcard`
-- -----------------------------
DROP TABLE IF EXISTS `think_merchant_bankcard`;
CREATE TABLE `think_merchant_bankcard` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `merchant_id` int(11) NOT NULL DEFAULT '0',
  `name` varchar(50) DEFAULT NULL,
  `c_bank` varchar(20) DEFAULT NULL,
  `c_bank_detail` varchar(100) DEFAULT NULL,
  `c_bank_card` varchar(100) DEFAULT NULL,
  `create_time` int(11) DEFAULT '0',
  `update_time` int(11) DEFAULT '0',
  `truename` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `think_merchant_bankcard`
-- -----------------------------
INSERT INTO `think_merchant_bankcard` VALUES ('1', '2', '银行卡1', '中国银行', '北京支行', '10000000000000', '1567128420', '1567128420', '张三');
INSERT INTO `think_merchant_bankcard` VALUES ('2', '4', '李四的卡', '建设银行', '北京支行', '1029389182903', '1567129833', '1567129833', '李四');

-- -----------------------------
-- Table structure for `think_merchant_log`
-- -----------------------------
DROP TABLE IF EXISTS `think_merchant_log`;
CREATE TABLE `think_merchant_log` (
  `log_id` int(11) NOT NULL AUTO_INCREMENT,
  `admin_id` int(11) DEFAULT NULL COMMENT '用户ID',
  `admin_name` varchar(50) DEFAULT NULL COMMENT '用户姓名',
  `description` varchar(300) DEFAULT NULL COMMENT '描述',
  `ip` char(60) DEFAULT NULL COMMENT 'IP地址',
  `status` tinyint(1) DEFAULT NULL COMMENT '1 成功 2 失败',
  `add_time` int(11) DEFAULT NULL COMMENT '添加时间',
  PRIMARY KEY (`log_id`)
) ENGINE=MyISAM AUTO_INCREMENT=52 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `think_merchant_log`
-- -----------------------------
INSERT INTO `think_merchant_log` VALUES ('1', '1', '13800138000', '用户【13800138000】登录成功', '112.96.240.113', '1', '1567305589');
INSERT INTO `think_merchant_log` VALUES ('2', '4', '13800138003', '用户【13800138003】登录成功', '112.96.240.113', '1', '1567306498');
INSERT INTO `think_merchant_log` VALUES ('3', '1', '13800138000', '用户【13800138000】登录成功', '112.96.240.113', '1', '1567307251');
INSERT INTO `think_merchant_log` VALUES ('4', '4', '13800138003', '用户【13800138003】登录成功', '112.96.240.113', '1', '1567307933');
INSERT INTO `think_merchant_log` VALUES ('5', '1', '13800138000', '用户【13800138000】登录成功', '112.96.240.113', '1', '1567308056');
INSERT INTO `think_merchant_log` VALUES ('6', '4', '13800138003', '用户【13800138003】登录成功', '112.96.240.113', '1', '1567308470');
INSERT INTO `think_merchant_log` VALUES ('7', '1', '13800138000', '用户【13800138000】登录成功', '112.96.240.113', '1', '1567308613');
INSERT INTO `think_merchant_log` VALUES ('8', '4', '13800138003', '用户【13800138003】登录成功', '112.96.240.113', '1', '1567308735');
INSERT INTO `think_merchant_log` VALUES ('9', '1', '13800138000', '用户【13800138000】登录成功', '112.96.240.113', '1', '1567308851');
INSERT INTO `think_merchant_log` VALUES ('10', '4', '13800138003', '用户【13800138003】登录成功', '112.96.240.113', '1', '1567309570');
INSERT INTO `think_merchant_log` VALUES ('11', '3', '13800138002', '用户【13800138002】登录成功', '112.96.240.113', '1', '1567313267');
INSERT INTO `think_merchant_log` VALUES ('12', '4', '13800138003', '用户【13800138003】登录成功', '112.96.240.113', '1', '1567316108');
INSERT INTO `think_merchant_log` VALUES ('13', '1', '13800138000', '用户【13800138000】登录成功', '112.96.240.113', '1', '1567319775');
INSERT INTO `think_merchant_log` VALUES ('14', '4', '13800138003', '用户【13800138003】登录成功', '112.96.240.113', '1', '1567319867');
INSERT INTO `think_merchant_log` VALUES ('15', '1', '13800138000', '用户【13800138000】登录成功', '112.96.240.113', '1', '1567319960');
INSERT INTO `think_merchant_log` VALUES ('16', '4', '13800138003', '用户【13800138003】登录成功', '112.96.240.113', '1', '1567321192');
INSERT INTO `think_merchant_log` VALUES ('17', '1', '13800138000', '用户【13800138000】登录成功', '112.96.240.113', '1', '1567321488');
INSERT INTO `think_merchant_log` VALUES ('18', '4', '13800138003', '用户【13800138003】登录成功', '112.96.241.100', '1', '1567325100');
INSERT INTO `think_merchant_log` VALUES ('19', '1', '13800138000', '用户【13800138000】登录成功', '112.96.241.100', '1', '1567325166');
INSERT INTO `think_merchant_log` VALUES ('20', '4', '13800138003', '用户【13800138003】登录成功', '112.96.241.100', '1', '1567325234');
INSERT INTO `think_merchant_log` VALUES ('21', '1', '13800138000', '用户【13800138000】登录成功', '112.96.241.100', '1', '1567325305');
INSERT INTO `think_merchant_log` VALUES ('22', '1', '13800138000', '用户【13800138000】登录成功', '112.96.240.198', '1', '1567327649');
INSERT INTO `think_merchant_log` VALUES ('23', '4', '13800138003', '用户【13800138003】登录成功', '112.96.240.198', '1', '1567327861');
INSERT INTO `think_merchant_log` VALUES ('24', '4', '13800138003', '用户【13800138003】登录成功', '112.96.240.223', '1', '1567336028');
INSERT INTO `think_merchant_log` VALUES ('25', '1', '13866889900', '用户【13866889900】登录成功', '182.119.52.43', '1', '1567338082');
INSERT INTO `think_merchant_log` VALUES ('26', '1', '13866889900', '用户【13866889900】登录成功', '112.96.240.223', '1', '1567338172');
INSERT INTO `think_merchant_log` VALUES ('27', '1', '13866889900', '用户【13866889900】登录成功', '112.96.240.223', '1', '1567338399');
INSERT INTO `think_merchant_log` VALUES ('28', '3', '13800138002', '用户【13800138002】登录成功', '112.96.240.223', '1', '1567340441');
INSERT INTO `think_merchant_log` VALUES ('29', '3', '13800138002', '用户【13800138002】登录成功', '112.96.240.223', '1', '1567340554');
INSERT INTO `think_merchant_log` VALUES ('30', '4', '13800138003', '用户【13800138003】登录成功', '112.96.240.223', '1', '1567340697');
INSERT INTO `think_merchant_log` VALUES ('31', '1', '13866889900', '用户【13866889900】登录成功', '112.96.240.223', '1', '1567342119');
INSERT INTO `think_merchant_log` VALUES ('32', '4', '13800138003', '用户【13800138003】登录成功', '182.38.40.193', '1', '1567349765');
INSERT INTO `think_merchant_log` VALUES ('33', '3', '13800138002', '用户【13800138002】登录成功', '112.96.241.10', '1', '1567418421');
INSERT INTO `think_merchant_log` VALUES ('34', '5', '吴全', '用户【吴全】登录成功', '112.96.241.10', '1', '1567418968');
INSERT INTO `think_merchant_log` VALUES ('35', '5', '吴全', '用户【吴全】登录成功', '112.96.241.10', '1', '1567419280');
INSERT INTO `think_merchant_log` VALUES ('36', '4', '13800138003', '用户【13800138003】登录成功', '112.224.20.28', '1', '1567419298');
INSERT INTO `think_merchant_log` VALUES ('37', '6', '18596386668', '用户【18596386668】登录成功', '112.224.20.28', '1', '1567420090');
INSERT INTO `think_merchant_log` VALUES ('38', '2', '13800138001', '用户【13800138001】登录成功', '112.96.241.10', '1', '1567420870');
INSERT INTO `think_merchant_log` VALUES ('39', '3', '13800138002', '用户【13800138002】登录成功', '112.96.241.10', '1', '1567423590');
INSERT INTO `think_merchant_log` VALUES ('40', '5', '吴全', '用户【吴全】登录成功', '112.96.241.10', '1', '1567423720');
INSERT INTO `think_merchant_log` VALUES ('41', '7', '13800138111', '用户【13800138111】登录成功', '182.61.171.106', '1', '1567423739');
INSERT INTO `think_merchant_log` VALUES ('42', '4', '13800138003', '用户【13800138003】登录成功', '112.96.240.194', '1', '1567434720');
INSERT INTO `think_merchant_log` VALUES ('43', '5', '吴全', '用户【吴全】登录成功', '112.96.240.17', '1', '1567475262');
INSERT INTO `think_merchant_log` VALUES ('44', '1', '13866889900', '用户【13866889900】登录成功', '112.96.240.17', '1', '1567478711');
INSERT INTO `think_merchant_log` VALUES ('45', '3', '13800138002', '用户【13800138002】登录成功', '112.96.240.17', '1', '1567479629');
INSERT INTO `think_merchant_log` VALUES ('46', '6', '18596386668', '用户【18596386668】登录成功', '112.65.48.221', '1', '1567501475');
INSERT INTO `think_merchant_log` VALUES ('47', '6', '18596386668', '用户【18596386668】登录成功', '112.65.48.221', '1', '1567501945');
INSERT INTO `think_merchant_log` VALUES ('48', '5', '15563681127', '用户【15563681127】登录成功', '112.96.240.29', '1', '1567562322');
INSERT INTO `think_merchant_log` VALUES ('49', '4', '13800138003', '用户【13800138003】登录成功', '112.224.5.13', '1', '1568354792');
INSERT INTO `think_merchant_log` VALUES ('50', '8', '郝栋超', '用户【郝栋超】登录成功', '124.239.143.115', '1', '1568533983');
INSERT INTO `think_merchant_log` VALUES ('51', '8', '郝栋超', '用户【郝栋超】登录成功', '60.208.176.240', '1', '1568534397');

-- -----------------------------
-- Table structure for `think_merchant_recharge`
-- -----------------------------
DROP TABLE IF EXISTS `think_merchant_recharge`;
CREATE TABLE `think_merchant_recharge` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `merchant_id` int(11) NOT NULL COMMENT '商户id',
  `from_address` varchar(255) NOT NULL COMMENT '转出地址',
  `to_address` varchar(255) DEFAULT NULL COMMENT '转入地址',
  `coinname` varchar(20) DEFAULT NULL COMMENT '币种',
  `txid` varchar(255) DEFAULT NULL COMMENT 'hash值',
  `num` decimal(20,8) DEFAULT '0.00000000' COMMENT '数量',
  `fee` decimal(20,8) DEFAULT '0.00000000' COMMENT '手续费',
  `mum` decimal(20,8) DEFAULT '0.00000000' COMMENT '实到',
  `addtime` int(11) DEFAULT NULL COMMENT '时间',
  `status` tinyint(2) DEFAULT '0' COMMENT '状态',
  `confirmations` tinyint(4) DEFAULT '0' COMMENT '确认数',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;


-- -----------------------------
-- Table structure for `think_merchant_user_address`
-- -----------------------------
DROP TABLE IF EXISTS `think_merchant_user_address`;
CREATE TABLE `think_merchant_user_address` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `merchant_id` int(11) NOT NULL COMMENT '商户id',
  `username` varchar(50) DEFAULT NULL COMMENT '用户名',
  `address` varchar(255) DEFAULT NULL COMMENT '钱包地址',
  `addtime` int(11) DEFAULT NULL COMMENT '申请时间',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=18 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `think_merchant_user_address`
-- -----------------------------
INSERT INTO `think_merchant_user_address` VALUES ('12', '2', 'admin', '0x11a7500e3e6bde9d94a585161dffe05a93012860', '1567239426');
INSERT INTO `think_merchant_user_address` VALUES ('13', '2', 'admin', '0x11a7500e3e6bde9d94a585161dffe05a93012860', '1567239429');
INSERT INTO `think_merchant_user_address` VALUES ('14', '2', 'admin', '0x11a7500e3e6bde9d94a585161dffe05a93012860', '1567239430');
INSERT INTO `think_merchant_user_address` VALUES ('15', '4', 'admin', '0x6d8ffc3c999de02900a7e13a58ee5472b0029a59', '1567311675');
INSERT INTO `think_merchant_user_address` VALUES ('16', '5', 'admin', '0x0f491c4675a84d7c40e538b1737568ae48d40f21', '1567475387');
INSERT INTO `think_merchant_user_address` VALUES ('17', '6', '', '0xd8865a9f321e8241629afca7e447d89b1937f11b', '1567502485');

-- -----------------------------
-- Table structure for `think_merchant_user_recharge`
-- -----------------------------
DROP TABLE IF EXISTS `think_merchant_user_recharge`;
CREATE TABLE `think_merchant_user_recharge` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `merchant_id` int(11) NOT NULL COMMENT '商户id',
  `from_address` varchar(255) NOT NULL COMMENT '转出地址',
  `to_address` varchar(255) DEFAULT NULL COMMENT '转入地址',
  `coinname` varchar(20) DEFAULT NULL COMMENT '币种',
  `txid` varchar(255) DEFAULT NULL COMMENT 'hash值',
  `num` decimal(20,8) DEFAULT '0.00000000' COMMENT '数量',
  `fee` decimal(20,8) DEFAULT '0.00000000' COMMENT '手续费',
  `mum` decimal(20,8) DEFAULT '0.00000000' COMMENT '实到',
  `addtime` int(11) DEFAULT NULL COMMENT '时间',
  `status` tinyint(2) DEFAULT '0' COMMENT '状态',
  `confirmations` tinyint(4) DEFAULT '0' COMMENT '确认数',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;


-- -----------------------------
-- Table structure for `think_merchant_user_withdraw`
-- -----------------------------
DROP TABLE IF EXISTS `think_merchant_user_withdraw`;
CREATE TABLE `think_merchant_user_withdraw` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `merchant_id` int(11) NOT NULL COMMENT '商户id',
  `address` varchar(255) DEFAULT NULL,
  `username` varchar(20) DEFAULT NULL COMMENT '用户名',
  `num` decimal(20,8) DEFAULT '0.00000000' COMMENT '数量',
  `fee` decimal(20,8) DEFAULT '0.00000000' COMMENT '手续费',
  `mum` decimal(20,8) DEFAULT '0.00000000' COMMENT '实到',
  `txid` varchar(255) DEFAULT NULL COMMENT 'hash值',
  `addtime` int(11) NOT NULL,
  `status` tinyint(2) DEFAULT '0' COMMENT '状态，0:待审核，1:通过，2:拒绝，3:撤销',
  `endtime` int(11) DEFAULT NULL COMMENT '完成实际',
  `ordersn` varchar(255) DEFAULT NULL COMMENT '订单号唯一标识',
  `type` smallint(6) DEFAULT NULL COMMENT '1:走钱包,2:不走钱包',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;


-- -----------------------------
-- Table structure for `think_merchant_withdraw`
-- -----------------------------
DROP TABLE IF EXISTS `think_merchant_withdraw`;
CREATE TABLE `think_merchant_withdraw` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `merchant_id` int(11) NOT NULL COMMENT '商户id',
  `username` varchar(255) DEFAULT NULL COMMENT '用户名',
  `address` varchar(255) DEFAULT NULL COMMENT '转入地址',
  `num` decimal(20,8) DEFAULT '0.00000000' COMMENT '数量',
  `fee` decimal(20,8) DEFAULT '0.00000000' COMMENT '手续费',
  `mum` decimal(20,8) DEFAULT '0.00000000' COMMENT '实到',
  `note` varchar(255) DEFAULT NULL COMMENT '备注',
  `txid` varchar(255) DEFAULT NULL COMMENT 'hash值',
  `addtime` int(11) DEFAULT NULL,
  `status` tinyint(2) DEFAULT '0' COMMENT '状态，0:待审核，1:通过，2:拒绝，3:撤销',
  `endtime` int(11) DEFAULT NULL COMMENT '完成实际',
  `ordersn` varchar(255) DEFAULT NULL COMMENT '订单号，唯一标识',
  `type` smallint(6) DEFAULT NULL COMMENT '1:走钱包,2:不走钱包',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `think_merchant_withdraw`
-- -----------------------------
INSERT INTO `think_merchant_withdraw` VALUES ('1', '2', '', '0x8499b4e12BA8F8C36a23FcEeCDBAee29Efd5Ab72', '10.00000000', '3.00000000', '7.00000000', '', '', '1567227202', '1', '1567335803', 'M2T8312720265812PS788', '2');
INSERT INTO `think_merchant_withdraw` VALUES ('2', '1', '', '0x05F72bE0CB7Cf86f41a49788C7CCaCC3DC80034C', '500.00000000', '6.00000000', '494.00000000', '', '', '1567478879', '1', '1567479025', 'M1T9037887951587PS112', '2');
INSERT INTO `think_merchant_withdraw` VALUES ('3', '3', '', '0x05F72bE0CB7Cf86f41a49788C7CCaCC3DC80034C', '500.00000000', '5.00000000', '495.00000000', '', '', '1567479739', '1', '1567479767', 'M3T9037973919624PS256', '2');

-- -----------------------------
-- Table structure for `think_merchant_wx`
-- -----------------------------
DROP TABLE IF EXISTS `think_merchant_wx`;
CREATE TABLE `think_merchant_wx` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `merchant_id` int(11) NOT NULL DEFAULT '0',
  `name` varchar(50) DEFAULT NULL,
  `c_bank` varchar(20) DEFAULT NULL,
  `c_bank_detail` varchar(100) DEFAULT NULL,
  `c_bank_card` varchar(100) DEFAULT NULL,
  `create_time` int(11) DEFAULT '0',
  `update_time` int(11) DEFAULT '0',
  `truename` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `think_merchant_wx`
-- -----------------------------
INSERT INTO `think_merchant_wx` VALUES ('1', '2', '微信账户1', '123', '20190830/e387a79f85c878b49e190a485e60c5d5.png', '', '1567134696', '1567134696', '司法局');
INSERT INTO `think_merchant_wx` VALUES ('2', '4', '1', '1', '20190901/7ed61295f96bce831000d24c8053d0ee.jpg', '', '1567306550', '1567306550', '1');

-- -----------------------------
-- Table structure for `think_merchant_ysf`
-- -----------------------------
DROP TABLE IF EXISTS `think_merchant_ysf`;
CREATE TABLE `think_merchant_ysf` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `merchant_id` int(11) NOT NULL DEFAULT '0',
  `name` varchar(50) DEFAULT NULL,
  `c_bank` varchar(20) DEFAULT NULL,
  `c_bank_detail` varchar(100) DEFAULT NULL,
  `c_bank_card` varchar(100) DEFAULT NULL,
  `create_time` int(11) DEFAULT '0',
  `update_time` int(11) DEFAULT '0',
  `truename` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `think_merchant_ysf`
-- -----------------------------
INSERT INTO `think_merchant_ysf` VALUES ('1', '2', '云闪付1', '', '20190830/5a675f3bb8c080f943b0ecd3d10d804e.png', '', '1567132720', '1567132720', '设计费');

-- -----------------------------
-- Table structure for `think_merchant_zfb`
-- -----------------------------
DROP TABLE IF EXISTS `think_merchant_zfb`;
CREATE TABLE `think_merchant_zfb` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `merchant_id` int(11) NOT NULL DEFAULT '0',
  `name` varchar(50) DEFAULT NULL,
  `c_bank` varchar(20) DEFAULT NULL,
  `c_bank_detail` varchar(100) DEFAULT NULL,
  `c_bank_card` varchar(100) DEFAULT NULL,
  `create_time` int(11) DEFAULT '0',
  `update_time` int(11) DEFAULT '0',
  `truename` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `think_merchant_zfb`
-- -----------------------------
INSERT INTO `think_merchant_zfb` VALUES ('1', '2', '支付宝1', '123@123.com', '20190830/b6bc103112f2890984d0b7f53eb14d5f.png', '', '1567128449', '1567128449', '张三');
INSERT INTO `think_merchant_zfb` VALUES ('2', '4', '李四支付宝', '12303@123.com', '20190830/4e01536d74dbb81570492b553b1fc9db.png', '', '1567129866', '1567129866', '李四');
INSERT INTO `think_merchant_zfb` VALUES ('3', '1', '1这是考虑的', '123@123.com', '20190831/26f813e2a0c06983bfbeaed6e8303617.png', '', '1567229748', '1567229748', '水电费');

-- -----------------------------
-- Table structure for `think_order_buy`
-- -----------------------------
DROP TABLE IF EXISTS `think_order_buy`;
CREATE TABLE `think_order_buy` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `buy_id` int(10) NOT NULL COMMENT '买家的id',
  `buy_bid` int(11) NOT NULL DEFAULT '0' COMMENT '发布购买单子的id',
  `sell_id` int(10) NOT NULL COMMENT '卖家id',
  `sell_sid` int(10) NOT NULL DEFAULT '0' COMMENT '卖家发布买的id',
  `deal_amount` decimal(13,2) NOT NULL COMMENT '交易金额',
  `deal_price` decimal(13,2) NOT NULL DEFAULT '0.00' COMMENT '交易价格',
  `deal_ctype` int(2) NOT NULL DEFAULT '0' COMMENT '交易货币的种类',
  `deal_num` decimal(20,8) NOT NULL COMMENT '交易数量',
  `ctime` int(10) NOT NULL COMMENT '创建时间',
  `dktime` int(11) NOT NULL DEFAULT '0' COMMENT '打款时间',
  `ltime` int(10) NOT NULL DEFAULT '30' COMMENT '限时多长时间付款',
  `status` tinyint(2) NOT NULL DEFAULT '0' COMMENT '0代表已经拍下1代付款2待收货3代评价4已经完成5取消交易6处于申诉状态 需要管理员处理',
  `desc` varchar(100) DEFAULT NULL COMMENT '交易操作描述',
  `finished_time` int(10) DEFAULT NULL,
  `order_no` varchar(55) NOT NULL COMMENT '订单编号',
  `cancle_op` int(1) NOT NULL DEFAULT '0' COMMENT '0默手动取消交易1为此交易已关闭，因为未及时将付款标记为完成。如果您已付款，请要求卖家重新打开交易。',
  `buy_pj` int(1) DEFAULT '0' COMMENT '来自买家的评价',
  `sell_pj` int(1) DEFAULT '0' COMMENT '来自卖家的评价',
  `su_type` int(1) NOT NULL DEFAULT '0' COMMENT '1我已付款，但卖家没有放行我比特币2卖家未遵守交易广告条款',
  `su_reason` text,
  `sutp` varchar(255) DEFAULT NULL COMMENT '上传路径',
  `type` tinyint(1) NOT NULL DEFAULT '1',
  `deal_coin` int(10) NOT NULL DEFAULT '0',
  `fee` decimal(20,8) NOT NULL DEFAULT '0.00000000',
  `buy_username` varchar(255) DEFAULT NULL,
  `buy_address` varchar(255) DEFAULT NULL,
  `return_url` varchar(255) DEFAULT NULL,
  `notify_url` varchar(255) DEFAULT NULL,
  `orderid` varchar(255) DEFAULT NULL,
  `platform_fee` decimal(20,8) DEFAULT '0.00000000' COMMENT '平台利润，交易员释放订单时更新',
  PRIMARY KEY (`id`),
  UNIQUE KEY `order_no` (`order_no`) USING BTREE,
  KEY `buy_id` (`buy_id`) USING BTREE,
  KEY `sell_id` (`sell_id`) USING BTREE,
  KEY `status` (`status`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=56 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `think_order_buy`
-- -----------------------------
INSERT INTO `think_order_buy` VALUES ('1', '1', '0', '2', '1', '106.00', '7.23', '0', '14.66113416', '1567305482', '0', '15', '5', '', '', 'E20190901103624256708', '0', '0', '0', '0', '', '', '1', '0', '0.00000000', '13803971223', 'test', 'http://www.faf5050.com/4.php?orderid=E20190901103624256708', 'http://www.faf5050.com/3.php', 'E20190901103624256708', '0.00000000');
INSERT INTO `think_order_buy` VALUES ('2', '1', '0', '2', '1', '233.00', '7.23', '0', '32.22683264', '1567306375', '0', '15', '5', '', '', 'E20190901105252432403', '0', '0', '0', '0', '', '', '1', '0', '0.00000000', '13801959131', 'test', 'http://www.faf5050.com/4.php?orderid=E20190901105252432403', 'http://www.faf5050.com/3.php', 'E20190901105252432403', '0.00000000');
INSERT INTO `think_order_buy` VALUES ('3', '1', '0', '4', '2', '692.00', '7.13', '0', '97.05469846', '1567306595', '1567306615', '15', '4', '', '1567306659', 'E20190901105629346725', '0', '0', '0', '0', '', '', '1', '0', '0.00000000', '13803637657', 'test', 'http://www.faf5050.com/4.php?orderid=E20190901105629346725', 'http://www.faf5050.com/3.php', 'E20190901105629346725', '1.94109397');
INSERT INTO `think_order_buy` VALUES ('4', '1', '0', '4', '3', '924.00', '7.13', '0', '129.59326788', '1567309671', '1567309680', '15', '4', '', '1567309752', 'E20190901114727177350', '0', '0', '0', '0', '', '', '1', '0', '0.00000000', '13809029386', 'test', 'http://www.faf5050.com/4.php?orderid=E20190901114727177350', 'http://www.faf5050.com/3.php', 'E20190901114727177350', '2.59186536');
INSERT INTO `think_order_buy` VALUES ('5', '1', '0', '4', '3', '119.00', '7.13', '0', '16.69004208', '1567316935', '1567317061', '15', '4', '', '1567317061', 'E20190901134849295508', '0', '0', '0', '0', '', '', '1', '0', '0.00000000', '13805305571', 'test', 'http://www.faf5050.com/4.php?orderid=E20190901134849295508', 'http://www.faf5050.com/3.php', 'E20190901134849295508', '0.33380084');
INSERT INTO `think_order_buy` VALUES ('6', '1', '0', '4', '3', '998.00', '7.13', '0', '139.97194951', '1567317036', '1567317045', '15', '4', '', '1567317070', 'E20190901135011708390', '0', '0', '0', '0', '', '', '1', '0', '0.00000000', '13805473698', 'test', 'http://www.faf5050.com/4.php?orderid=E20190901135011708390', 'http://www.faf5050.com/3.php', 'E20190901135011708390', '2.79943899');
INSERT INTO `think_order_buy` VALUES ('7', '1', '0', '4', '3', '73.00', '7.13', '0', '10.23842917', '1567317414', '1567317424', '15', '4', '', '1567317480', 'E20190901135640721032', '0', '0', '0', '0', '', '', '1', '0', '0.00000000', '13805418095', 'test', 'http://www.faf5050.com/4.php?orderid=E20190901135640721032', 'http://www.faf5050.com/3.php', 'E20190901135640721032', '0.20476858');
INSERT INTO `think_order_buy` VALUES ('8', '1', '0', '4', '3', '815.00', '7.13', '0', '114.30575035', '1567318274', '1567318283', '15', '4', '', '1567319141', 'E20190901141049146912', '0', '0', '0', '0', '', '', '1', '0', '0.00000000', '13805375226', 'test', 'http://www.faf5050.com/4.php?orderid=E20190901141049146912', 'http://www.faf5050.com/3.php', 'E20190901141049146912', '2.28611501');
INSERT INTO `think_order_buy` VALUES ('9', '1', '0', '4', '4', '436.00', '7.18', '0', '60.72423398', '1567318949', '1567318956', '15', '4', '', '1567319041', 'E20190901142225597873', '0', '0', '0', '0', '', '', '1', '0', '0.00000000', '13808341021', 'test', 'http://www.faf5050.com/4.php?orderid=E20190901142225597873', 'http://www.faf5050.com/3.php', 'E20190901142225597873', '1.21448468');
INSERT INTO `think_order_buy` VALUES ('10', '1', '0', '4', '4', '31.00', '7.18', '0', '4.31754875', '1567319197', '1567319204', '15', '4', '', '1567319245', 'E20190901142635513916', '0', '0', '0', '0', '', '', '1', '0', '0.00000000', '13801792082', 'test', 'http://www.faf5050.com/4.php?orderid=E20190901142635513916', 'http://www.faf5050.com/3.php', 'E20190901142635513916', '0.08635098');
INSERT INTO `think_order_buy` VALUES ('11', '1', '0', '4', '4', '371.00', '7.18', '0', '51.67130919', '1567319381', '1567319389', '15', '4', '', '1567319407', 'E20190901142904202513', '0', '0', '0', '0', '', '', '1', '0', '0.00000000', '13805276233', 'test', 'http://www.faf5050.com/4.php?orderid=E20190901142904202513', 'http://www.faf5050.com/3.php', 'E20190901142904202513', '1.03342618');
INSERT INTO `think_order_buy` VALUES ('12', '1', '0', '4', '4', '456.00', '7.18', '0', '63.50974930', '1567321278', '1567321293', '15', '4', '', '1567325250', 'E20190901150052928211', '0', '0', '0', '0', '', '', '1', '0', '0.00000000', '13804276815', 'test', 'http://www.faf5050.com/4.php?orderid=E20190901150052928211', 'http://www.faf5050.com/3.php', 'E20190901150052928211', '1.27019499');
INSERT INTO `think_order_buy` VALUES ('13', '1', '0', '4', '8', '909.00', '7.18', '0', '126.60167131', '1567327967', '1567327975', '15', '4', '', '1567327999', 'E20190901165243102906', '0', '0', '0', '0', '', '', '1', '0', '0.00000000', '13809835832', 'test', 'http://www.faf5050.com/4.php?orderid=E20190901165243102906', 'http://www.faf5050.com/3.php', 'E20190901165243102906', '3.79805014');
INSERT INTO `think_order_buy` VALUES ('14', '1', '0', '4', '8', '506.00', '7.18', '0', '70.47353760', '1567328480', '1567328489', '15', '4', '', '1567328519', 'E20190901170118552903', '0', '0', '0', '0', '', '', '1', '0', '0.00000000', '13807260176', 'test', 'http://www.faf5050.com/4.php?orderid=E20190901170118552903', 'http://www.faf5050.com/3.php', 'E20190901170118552903', '0.14094708');
INSERT INTO `think_order_buy` VALUES ('15', '1', '0', '4', '8', '511.00', '7.18', '0', '71.16991643', '1567328812', '1567328819', '15', '4', '', '1567328838', 'E20190901170650965785', '0', '0', '0', '0', '', '', '1', '0', '0.00000000', '13808955617', 'test', 'http://www.faf5050.com/4.php?orderid=E20190901170650965785', 'http://www.faf5050.com/3.php', 'E20190901170650965785', '1.42339833');
INSERT INTO `think_order_buy` VALUES ('16', '1', '0', '4', '9', '1000.00', '7.19', '0', '139.08205841', '1567329497', '1567329503', '15', '4', '', '1567329534', 'E20190901171810921148', '0', '0', '0', '0', '', '', '1', '0', '0.00000000', '13802437551', 'test', 'http://www.faf5050.com/4.php?orderid=E20190901171810921148', 'http://www.faf5050.com/3.php', 'E20190901171810921148', '0.00000000');
INSERT INTO `think_order_buy` VALUES ('17', '1', '0', '4', '10', '100.00', '7.18', '0', '13.92757660', '1567329732', '1567329747', '15', '4', '', '1567329775', 'E20190901172206218980', '0', '0', '0', '0', '', '', '1', '0', '0.00000000', '13805580577', 'test', 'http://www.faf5050.com/4.php?orderid=E20190901172206218980', 'http://www.faf5050.com/3.php', 'E20190901172206218980', '0.27855153');
INSERT INTO `think_order_buy` VALUES ('18', '1', '0', '2', '1', '7190.00', '7.23', '0', '994.46749654', '1567330036', '1567330049', '15', '4', '', '1567420978', 'E20190901172707307554', '0', '0', '0', '0', '', '', '1', '0', '0.00000000', '13803926840', 'test', 'http://www.faf5050.com/4.php?orderid=E20190901172707307554', 'http://www.faf5050.com/3.php', 'E20190901172707307554', '1.98893499');
INSERT INTO `think_order_buy` VALUES ('19', '1', '0', '4', '11', '1000.00', '7.19', '0', '139.08205841', '1567330107', '1567330139', '15', '4', '', '1567330139', 'E20190901172823142561', '0', '0', '0', '0', '', '', '1', '0', '0.00000000', '13804542177', 'test', 'http://www.faf5050.com/4.php?orderid=E20190901172823142561', 'http://www.faf5050.com/3.php', 'E20190901172823142561', '2.78164117');
INSERT INTO `think_order_buy` VALUES ('20', '1', '0', '4', '12', '7180.00', '7.18', '0', '1000.00000000', '1567330223', '1567330232', '15', '4', '', '1567330252', 'E20190901173016981274', '0', '0', '0', '0', '', '', '1', '0', '0.00000000', '13804018897', 'test', 'http://www.faf5050.com/4.php?orderid=E20190901173016981274', 'http://www.faf5050.com/3.php', 'E20190901173016981274', '20.00000000');
INSERT INTO `think_order_buy` VALUES ('21', '1', '0', '4', '13', '7180.00', '7.18', '0', '1000.00000000', '1567330648', '1567330656', '15', '4', '', '1567330698', 'E20190901173715561812', '0', '0', '0', '0', '', '', '1', '0', '0.00000000', '13807976370', 'test', 'http://www.faf5050.com/4.php?orderid=E20190901173715561812', 'http://www.faf5050.com/3.php', 'E20190901173715561812', '20.00000000');
INSERT INTO `think_order_buy` VALUES ('22', '1', '0', '4', '14', '7180.00', '7.18', '0', '1000.00000000', '1567331038', '1567331044', '15', '4', '', '1567331058', 'E20190901174350800914', '0', '0', '0', '0', '', '', '1', '0', '0.00000000', '13805079547', 'test', 'http://www.faf5050.com/4.php?orderid=E20190901174350800914', 'http://www.faf5050.com/3.php', 'E20190901174350800914', '20.00000000');
INSERT INTO `think_order_buy` VALUES ('23', '1', '0', '4', '15', '7180.00', '7.18', '0', '1000.00000000', '1567331433', '1567331441', '15', '4', '', '1567331523', 'E20190901175026771268', '0', '0', '0', '0', '', '', '1', '0', '0.00000000', '13805231965', 'test', 'http://www.faf5050.com/4.php?orderid=E20190901175026771268', 'http://www.faf5050.com/3.php', 'E20190901175026771268', '4.00000000');
INSERT INTO `think_order_buy` VALUES ('24', '1', '0', '4', '16', '7180.00', '7.18', '0', '1000.00000000', '1567331973', '1567331980', '15', '4', '', '1567331993', 'E20190901175926128374', '0', '0', '0', '0', '', '', '1', '0', '0.00000000', '13806981379', 'test', 'http://www.faf5050.com/4.php?orderid=E20190901175926128374', 'http://www.faf5050.com/3.php', 'E20190901175926128374', '0.00000000');
INSERT INTO `think_order_buy` VALUES ('25', '1', '0', '4', '17', '7180.00', '7.18', '0', '1000.00000000', '1567332377', '1567332385', '15', '4', '', '1567332402', 'E20190901180601549752', '0', '0', '0', '0', '', '', '1', '0', '0.00000000', '13805992504', 'test', 'http://www.faf5050.com/4.php?orderid=E20190901180601549752', 'http://www.faf5050.com/3.php', 'E20190901180601549752', '4.00000000');
INSERT INTO `think_order_buy` VALUES ('26', '1', '0', '4', '18', '7180.00', '7.18', '0', '1000.00000000', '1567333481', '1567333488', '15', '4', '', '1567333546', 'E20190901182434457438', '0', '0', '0', '0', '', '', '1', '0', '0.00000000', '13801417779', 'test', 'http://www.faf5050.com/4.php?orderid=E20190901182434457438', 'http://www.faf5050.com/3.php', 'E20190901182434457438', '4.00000000');
INSERT INTO `think_order_buy` VALUES ('27', '1', '0', '4', '20', '7180.00', '7.18', '0', '1000.00000000', '1567337593', '1567337599', '15', '4', '', '1567337614', 'E20190901193304538581', '0', '0', '0', '0', '', '', '1', '0', '0.00000000', '13807992096', 'test', 'http://www.faf5050.com/4.php?orderid=E20190901193304538581', 'http://www.faf5050.com/3.php', 'E20190901193304538581', '25.00000000');
INSERT INTO `think_order_buy` VALUES ('28', '1', '0', '4', '21', '7180.00', '7.18', '0', '1000.00000000', '1567337904', '1567337908', '15', '4', '', '1567337920', 'E20190901193816588965', '0', '0', '0', '0', '', '', '1', '0', '0.00000000', '13801026588', 'test', 'http://www.faf5050.com/4.php?orderid=E20190901193816588965', 'http://www.faf5050.com/3.php', 'E20190901193816588965', '28.00000000');
INSERT INTO `think_order_buy` VALUES ('29', '1', '0', '4', '22', '7180.00', '7.18', '0', '1000.00000000', '1567338117', '1567338122', '15', '4', '', '1567338136', 'E20190901194151963900', '0', '0', '0', '0', '', '', '1', '0', '0.00000000', '13805215205', 'test', 'http://www.faf5050.com/4.php?orderid=E20190901194151963900', 'http://www.faf5050.com/3.php', 'E20190901194151963900', '28.50000000');
INSERT INTO `think_order_buy` VALUES ('30', '1', '0', '4', '23', '7180.00', '7.18', '0', '1000.00000000', '1567338453', '1567338458', '15', '4', '', '1567338470', 'E20190901194727998039', '0', '0', '0', '0', '', '', '1', '0', '0.00000000', '13807113711', 'test', 'http://www.faf5050.com/4.php?orderid=E20190901194727998039', 'http://www.faf5050.com/3.php', 'E20190901194727998039', '3.50000000');
INSERT INTO `think_order_buy` VALUES ('31', '1', '0', '4', '24', '7180.00', '7.18', '0', '1000.00000000', '1567338817', '1567338863', '15', '4', '', '1567338874', 'E20190901195332161538', '0', '0', '0', '0', '', '', '1', '0', '0.00000000', '13809708345', 'test', 'http://www.faf5050.com/4.php?orderid=E20190901195332161538', 'http://www.faf5050.com/3.php', 'E20190901195332161538', '3.50000000');
INSERT INTO `think_order_buy` VALUES ('32', '1', '0', '4', '25', '7180.00', '7.18', '0', '1000.00000000', '1567339093', '1567339099', '15', '4', '', '1567339111', 'E20190901195807411158', '0', '0', '0', '0', '', '', '1', '0', '0.00000000', '13806693604', 'test', 'http://www.faf5050.com/4.php?orderid=E20190901195807411158', 'http://www.faf5050.com/3.php', 'E20190901195807411158', '3.50000000');
INSERT INTO `think_order_buy` VALUES ('33', '1', '0', '4', '26', '7180.00', '7.18', '0', '1000.00000000', '1567339253', '1567339261', '15', '4', '', '1567339326', 'E20190901200047227640', '0', '0', '0', '0', '', '', '1', '0', '0.00000000', '13806806743', 'test', 'http://www.faf5050.com/4.php?orderid=E20190901200047227640', 'http://www.faf5050.com/3.php', 'E20190901200047227640', '33.50000000');
INSERT INTO `think_order_buy` VALUES ('34', '1', '0', '4', '27', '7180.00', '7.18', '0', '1000.00000000', '1567339706', '1567339710', '15', '4', '', '1567339733', 'E20190901200820340792', '0', '0', '0', '0', '', '', '1', '0', '0.00000000', '13802191956', 'test', 'http://www.faf5050.com/4.php?orderid=E20190901200820340792', 'http://www.faf5050.com/3.php', 'E20190901200820340792', '6.50000000');
INSERT INTO `think_order_buy` VALUES ('35', '1', '0', '4', '28', '7190.00', '7.19', '0', '1000.00000000', '1567339871', '1567339875', '15', '4', '', '1567339889', 'E20190901201104609410', '0', '0', '0', '0', '', '', '1', '0', '0.00000000', '13807225102', 'test', 'http://www.faf5050.com/4.php?orderid=E20190901201104609410', 'http://www.faf5050.com/3.php', 'E20190901201104609410', '3.50000000');
INSERT INTO `think_order_buy` VALUES ('36', '1', '0', '4', '29', '7190.00', '7.19', '0', '1000.00000000', '1567340093', '1567340098', '15', '4', '', '1567340109', 'E20190901201447742159', '0', '0', '0', '0', '', '', '1', '0', '0.00000000', '13804743830', 'test', 'http://www.faf5050.com/4.php?orderid=E20190901201447742159', 'http://www.faf5050.com/3.php', 'E20190901201447742159', '2.50000000');
INSERT INTO `think_order_buy` VALUES ('37', '1', '0', '4', '30', '7180.00', '7.18', '0', '1000.00000000', '1567340258', '1567340262', '15', '4', '', '1567340273', 'E20190901201724859141', '0', '0', '0', '0', '', '', '1', '0', '0.00000000', '13805751219', 'test', 'http://www.faf5050.com/4.php?orderid=E20190901201724859141', 'http://www.faf5050.com/3.php', 'E20190901201724859141', '2.00000000');
INSERT INTO `think_order_buy` VALUES ('38', '1', '0', '4', '31', '71800.00', '7.18', '0', '10000.00000000', '1567341798', '1567341805', '15', '4', '', '1567341820', 'E20190901204307380697', '0', '0', '0', '0', '', '', '1', '0', '0.00000000', '13804438554', 'test', 'http://www.faf5050.com/4.php?orderid=E20190901204307380697', 'http://www.faf5050.com/3.php', 'E20190901204307380697', '35.00000000');
INSERT INTO `think_order_buy` VALUES ('39', '1', '0', '4', '32', '7180.00', '7.18', '0', '1000.00000000', '1567342019', '1567342023', '15', '4', '', '1567342042', 'E20190901204653903724', '0', '0', '0', '0', '', '', '1', '0', '0.00000000', '13801469909', 'test', 'http://www.faf5050.com/4.php?orderid=E20190901204653903724', 'http://www.faf5050.com/3.php', 'E20190901204653903724', '2.00000000');
INSERT INTO `think_order_buy` VALUES ('40', '1', '0', '4', '33', '100.00', '7.18', '0', '13.92757660', '1567349874', '1567349977', '15', '4', '', '1567349977', '1', '0', '0', '0', '0', '', '', '1', '0', '0.00000000', '1', '1', '1', '1', '1', '0.02785515');
INSERT INTO `think_order_buy` VALUES ('41', '1', '0', '4', '33', '100.00', '7.18', '0', '13.92757660', '1567350181', '1567350197', '15', '4', '', '1567350197', '11', '0', '0', '0', '0', '', '', '1', '0', '0.00000000', '1', '1', 'http://www.baidu.com', 'http://www.baidu.com', '11', '0.02785515');
INSERT INTO `think_order_buy` VALUES ('42', '1', '0', '4', '35', '100.00', '7.19', '0', '13.90820584', '1567420102', '1567420120', '15', '4', '', '1567420349', '1111', '0', '0', '0', '0', '', '', '1', '0', '0.00000000', 'test', '1', 'http://www.coinvestlife.com/pay', 'http://www.coinvestlife.com/pay', '1111', '0.02781641');
INSERT INTO `think_order_buy` VALUES ('43', '1', '0', '4', '36', '7190.00', '7.19', '0', '1000.00000000', '1567421191', '1567421227', '15', '4', '', '1567421254', '1111111', '0', '0', '0', '0', '', '', '1', '0', '0.00000000', 'test', '1', 'http://www.coinvestlife.com/pay', 'http://www.coinvestlife.com/pay', '1111111', '2.00000000');
INSERT INTO `think_order_buy` VALUES ('44', '1', '0', '2', '38', '1000.00', '7.19', '0', '139.08205841', '1567421246', '1567421259', '15', '4', '', '1567421299', '2222', '0', '0', '0', '0', '', '', '1', '0', '0.00000000', 'test', '1', 'http://www.coinvestlife.com/pay', 'http://www.coinvestlife.com/pay', '2222', '0.27816412');
INSERT INTO `think_order_buy` VALUES ('45', '1', '0', '2', '39', '7190.00', '7.19', '0', '1000.00000000', '1567421432', '1567421446', '15', '4', '', '1567421464', '22221', '0', '0', '0', '0', '', '', '1', '0', '0.00000000', 'test', '1', 'http://www.coinvestlife.com/pay', 'http://www.coinvestlife.com/pay', '22221', '2.00000000');
INSERT INTO `think_order_buy` VALUES ('46', '1', '0', '4', '40', '7180.00', '7.18', '0', '1000.00000000', '1567434786', '1567434793', '15', '4', '', '1567434807', 'E20190902223258745940', '0', '0', '0', '0', '', '', '1', '0', '0.00000000', '13805956968', 'test', 'http://www.faf5050.com/4.php?orderid=E20190902223258745940', 'http://www.faf5050.com/3.php', 'E20190902223258745940', '2.00000000');
INSERT INTO `think_order_buy` VALUES ('47', '1', '0', '4', '41', '142.00', '7.01', '0', '20.25677603', '1568354881', '1568354906', '15', '4', '', '1568354947', 'E20190913140754922262', '0', '0', '0', '0', '', '', '1', '0', '0.00000000', '13808898546', 'test', 'http://www.faf5050.com/4.php?orderid=E20190913140754922262', 'http://www.faf5050.com/3.php', 'E20190913140754922262', '0.07089872');
INSERT INTO `think_order_buy` VALUES ('48', '1', '0', '4', '41', '475.00', '7.01', '0', '67.76034237', '1568355045', '1568355063', '15', '4', '', '1568355216', 'E20190913141041806579', '0', '0', '0', '0', '', '', '1', '0', '0.00000000', '13801362350', 'test', 'http://www.faf5050.com/4.php?orderid=E20190913141041806579', 'http://www.faf5050.com/3.php', 'E20190913141041806579', '0.23716120');
INSERT INTO `think_order_buy` VALUES ('49', '1', '0', '4', '41', '675.00', '7.01', '0', '96.29101284', '1568355353', '1568355361', '15', '4', '', '1568355376', 'E20190913141547469877', '0', '0', '0', '0', '', '', '1', '0', '0.00000000', '13807044240', 'test', 'http://www.faf5050.com/4.php?orderid=E20190913141547469877', 'http://www.faf5050.com/3.php', 'E20190913141547469877', '0.33701854');
INSERT INTO `think_order_buy` VALUES ('50', '1', '0', '4', '41', '815.00', '7.01', '0', '116.26248217', '1568355457', '1568355462', '15', '4', '', '1568355482', 'E20190913141730856417', '0', '0', '0', '0', '', '', '1', '0', '0.00000000', '13803569370', 'test', 'http://www.faf5050.com/4.php?orderid=E20190913141730856417', 'http://www.faf5050.com/3.php', 'E20190913141730856417', '0.40691869');
INSERT INTO `think_order_buy` VALUES ('51', '1', '0', '4', '41', '1000.00', '7.01', '0', '142.65335235', '1568355566', '1568355576', '15', '4', '', '1568355609', 'E20190913141917253943', '0', '0', '0', '0', '', '', '1', '0', '0.00000000', '13807876038', 'test', 'http://www.faf5050.com/4.php?orderid=E20190913141917253943', 'http://www.faf5050.com/3.php', 'E20190913141917253943', '0.49928673');
INSERT INTO `think_order_buy` VALUES ('52', '1', '0', '4', '42', '1000.00', '7.01', '0', '142.65335235', '1568355719', '1568355726', '15', '4', '', '1568355822', 'E20190913142152821552', '0', '0', '0', '0', '', '', '1', '0', '0.00000000', '13807068266', 'test', 'http://www.faf5050.com/4.php?orderid=E20190913142152821552', 'http://www.faf5050.com/3.php', 'E20190913142152821552', '0.49928673');
INSERT INTO `think_order_buy` VALUES ('53', '1', '0', '4', '43', '7010.00', '7.01', '0', '1000.00000000', '1568355901', '1568355909', '15', '4', '', '1568355936', 'E20190913142451263965', '0', '0', '0', '0', '', '', '1', '0', '0.00000000', '13808256859', 'test', 'http://www.faf5050.com/4.php?orderid=E20190913142451263965', 'http://www.faf5050.com/3.php', 'E20190913142451263965', '3.50000000');
INSERT INTO `think_order_buy` VALUES ('54', '1', '0', '4', '44', '7010.00', '7.01', '0', '1000.00000000', '1568356031', '1568356038', '15', '4', '', '1568356057', 'E20190913142702486648', '0', '0', '0', '0', '', '', '1', '0', '0.00000000', '13805479798', 'test', 'http://www.faf5050.com/4.php?orderid=E20190913142702486648', 'http://www.faf5050.com/3.php', 'E20190913142702486648', '3.50000000');
INSERT INTO `think_order_buy` VALUES ('55', '1', '0', '4', '45', '7010.00', '7.01', '0', '1000.00000000', '1568356229', '1568356235', '15', '4', '', '1568356252', 'E20190913142955490855', '0', '0', '0', '0', '', '', '1', '0', '0.00000000', '13804368147', 'test', 'http://www.faf5050.com/4.php?orderid=E20190913142955490855', 'http://www.faf5050.com/3.php', 'E20190913142955490855', '3.50000000');

-- -----------------------------
-- Table structure for `think_order_sell`
-- -----------------------------
DROP TABLE IF EXISTS `think_order_sell`;
CREATE TABLE `think_order_sell` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `buy_id` int(10) NOT NULL COMMENT '买家的id',
  `buy_bid` int(11) NOT NULL DEFAULT '0' COMMENT '发布购买单子的id',
  `sell_id` int(10) NOT NULL COMMENT '卖家id',
  `sell_sid` int(10) NOT NULL DEFAULT '0' COMMENT '买家发布买的id',
  `deal_amount` decimal(20,2) NOT NULL COMMENT '交易金额',
  `deal_price` decimal(13,2) NOT NULL DEFAULT '0.00' COMMENT '交易价格',
  `deal_ctype` int(2) NOT NULL DEFAULT '0' COMMENT '交易货币种类',
  `deal_num` decimal(20,8) NOT NULL COMMENT '交易数量',
  `ctime` int(10) NOT NULL COMMENT '创建时间',
  `dktime` int(11) NOT NULL DEFAULT '0' COMMENT '打款时间',
  `ltime` int(10) NOT NULL DEFAULT '60' COMMENT '限时多长时间付款',
  `status` tinyint(2) NOT NULL DEFAULT '0' COMMENT '0代表已经拍下1代付款2待发货3代评价4已经完成5取消交易6处于申诉的状态管理员需要审核',
  `desc` varchar(100) DEFAULT NULL COMMENT '交易操作描述',
  `finished_time` int(10) DEFAULT NULL,
  `order_no` varchar(55) NOT NULL COMMENT '订单编号',
  `buy_pj` int(1) DEFAULT '0' COMMENT '买家给出的评价1好评2中评3差评',
  `sell_pj` int(1) DEFAULT '0' COMMENT '卖家给买家的评价',
  `su_type` int(1) NOT NULL DEFAULT '0' COMMENT '1 2',
  `su_reason` text,
  `cancle_op` int(2) NOT NULL DEFAULT '0' COMMENT '取消的原因',
  `sutp` varchar(155) DEFAULT NULL COMMENT '上传路径',
  `type` tinyint(1) NOT NULL DEFAULT '2',
  `deal_coin` int(10) NOT NULL DEFAULT '0',
  `fee` decimal(20,8) NOT NULL DEFAULT '0.00000000',
  `getpaymethod` varchar(255) DEFAULT NULL,
  `buyer_fee` decimal(20,8) DEFAULT '0.00000000' COMMENT '买家手续费，即交易员',
  `pay` varchar(255) DEFAULT NULL COMMENT '银行卡',
  `pay2` varchar(255) DEFAULT NULL COMMENT '支付宝',
  `pay3` varchar(255) DEFAULT NULL COMMENT '微信',
  `pay4` varchar(255) DEFAULT NULL COMMENT '云闪付',
  PRIMARY KEY (`id`),
  UNIQUE KEY `order_no` (`order_no`) USING BTREE,
  KEY `buy_id` (`buy_id`) USING BTREE,
  KEY `sell_id` (`sell_id`) USING BTREE,
  KEY `status` (`status`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `think_order_sell`
-- -----------------------------
INSERT INTO `think_order_sell` VALUES ('1', '4', '2', '1', '0', '500.00', '7.15', '0', '69.93006993', '1567308652', '1567308777', '15', '4', '', '1567308882', 'T1T9010865250809PS138', '0', '0', '0', '', '0', '', '2', '0', '0.69930070', '', '-0.69930070', '', '3', '', '');
INSERT INTO `think_order_sell` VALUES ('2', '4', '3', '1', '0', '100.00', '7.14', '0', '14.00560224', '1567319819', '1567319887', '15', '4', '', '1567319996', 'T1T9011981927812PS613', '0', '0', '0', '', '0', '', '2', '0', '0.08403361', '', '-0.14005602', '', '3', '', '');

-- -----------------------------
-- Table structure for `think_question`
-- -----------------------------
DROP TABLE IF EXISTS `think_question`;
CREATE TABLE `think_question` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `merchant_id` int(11) NOT NULL COMMENT '商户id',
  `type` tinyint(2) DEFAULT NULL COMMENT '问题类型，1：充值，2：提币，3：其他问题',
  `content` varchar(255) DEFAULT NULL COMMENT '内容',
  `reply` varchar(255) DEFAULT NULL COMMENT '回复',
  `addtime` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `think_question`
-- -----------------------------
INSERT INTO `think_question` VALUES ('1', '5', '2', '到账时间慢', ' 请提供账号', '1567562344');

-- -----------------------------
-- Table structure for `think_statistics`
-- -----------------------------
DROP TABLE IF EXISTS `think_statistics`;
CREATE TABLE `think_statistics` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `platform_profit` decimal(20,8) DEFAULT '0.00000000' COMMENT '平台利润，所有平台的手续费',
  `agent_reward` decimal(20,8) DEFAULT '0.00000000' COMMENT '代理商奖励总和',
  `trader_reward` decimal(20,8) DEFAULT '0.00000000' COMMENT '交易员奖励总和',
  `platform_usdt_amount` decimal(20,8) DEFAULT '0.00000000' COMMENT '平台现存usdt总数量，所有会员类型账户的冻结加活动',
  `recharge_total` decimal(20,8) DEFAULT '0.00000000' COMMENT '总充值数量',
  `withdraw_total` decimal(20,8) DEFAULT '0.00000000' COMMENT '总提币数量',
  `ad_sell_on_total` int(11) DEFAULT '0' COMMENT '现存挂单出售笔数，交易员发布出售的单子，不含下架的，不含数量低于0的',
  `order_sell_amount` decimal(20,8) DEFAULT '0.00000000' COMMENT '现存挂单出售总USDT，所有交易员挂单出售的usdt数量',
  `ad_buy_on_total` int(11) DEFAULT '0' COMMENT '求购笔数，交易员求购广告数量',
  `order_buy_amount` decimal(20,8) DEFAULT '0.00000000' COMMENT '求购总数量，挂单购买的总usdt数量',
  `create_time` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=18 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `think_statistics`
-- -----------------------------
INSERT INTO `think_statistics` VALUES ('1', '0.00000000', '0.00000000', '0.00000000', '0.00000000', '0.00000000', '0.00000000', '0', '0.00000000', '0', '0.00000000', '1567086395');
INSERT INTO `think_statistics` VALUES ('2', '0.00000000', '0.00000000', '0.00000000', '31881.42857143', '0.00000000', '0.00000000', '1', '1000.00000000', '0', '0.00000000', '1567267202');
INSERT INTO `think_statistics` VALUES ('3', '274.18381572', '0.00000000', '17.54178272', '14682.54828771', '0.00000000', '7.00000000', '2', '1172.14484680', '3', '2016.06432783', '1567353602');
INSERT INTO `think_statistics` VALUES ('4', '282.47873124', '0.00000000', '23.76296936', '6163.69931879', '0.00000000', '7.00000000', '0', '0.00000000', '0', '0.00000000', '1567440003');
INSERT INTO `think_statistics` VALUES ('5', '293.47873124', '0.00000000', '23.76296936', '2003.00000000', '0.00000000', '996.00000000', '0', '0.00000000', '0', '0.00000000', '1567526402');
INSERT INTO `think_statistics` VALUES ('6', '293.47873124', '0.00000000', '23.76296936', '2003.00000000', '0.00000000', '996.00000000', '0', '0.00000000', '0', '0.00000000', '1567612801');
INSERT INTO `think_statistics` VALUES ('7', '293.47873124', '0.00000000', '23.76296936', '2003.00000000', '0.00000000', '996.00000000', '0', '0.00000000', '0', '0.00000000', '1567699203');
INSERT INTO `think_statistics` VALUES ('8', '293.47873124', '0.00000000', '23.76296936', '2003.00000000', '0.00000000', '996.00000000', '0', '0.00000000', '0', '0.00000000', '1567785602');
INSERT INTO `think_statistics` VALUES ('9', '293.47873124', '0.00000000', '23.76296936', '2003.00000000', '0.00000000', '996.00000000', '0', '0.00000000', '0', '0.00000000', '1567872002');
INSERT INTO `think_statistics` VALUES ('10', '293.47873124', '0.00000000', '23.76296936', '2003.00000000', '0.00000000', '996.00000000', '0', '0.00000000', '0', '0.00000000', '1567958402');
INSERT INTO `think_statistics` VALUES ('11', '293.47873124', '0.00000000', '23.76296936', '2003.00000000', '0.00000000', '996.00000000', '0', '0.00000000', '0', '0.00000000', '1568044805');
INSERT INTO `think_statistics` VALUES ('12', '293.47873124', '0.00000000', '23.76296936', '2003.00000000', '0.00000000', '996.00000000', '0', '0.00000000', '0', '0.00000000', '1568131201');
INSERT INTO `think_statistics` VALUES ('13', '293.47873124', '0.00000000', '23.76296936', '2003.00000000', '0.00000000', '996.00000000', '0', '0.00000000', '0', '0.00000000', '1568217602');
INSERT INTO `think_statistics` VALUES ('14', '293.47873124', '0.00000000', '23.76296936', '2001.50000000', '0.00000000', '996.00000000', '0', '0.00000000', '0', '0.00000000', '1568304001');
INSERT INTO `think_statistics` VALUES ('15', '306.02930185', '0.00000000', '23.76296936', '5573.32674750', '0.00000000', '996.00000000', '0', '0.00000000', '0', '0.00000000', '1568390402');
INSERT INTO `think_statistics` VALUES ('16', '306.02930185', '0.00000000', '23.76296936', '5573.32674750', '0.00000000', '996.00000000', '0', '0.00000000', '0', '0.00000000', '1568476802');
INSERT INTO `think_statistics` VALUES ('17', '306.02930185', '0.00000000', '23.76296936', '5573.32674750', '0.00000000', '996.00000000', '0', '0.00000000', '0', '0.00000000', '1568563202');

-- -----------------------------
-- Table structure for `think_trader_reward`
-- -----------------------------
DROP TABLE IF EXISTS `think_trader_reward`;
CREATE TABLE `think_trader_reward` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `uid` int(11) DEFAULT NULL,
  `duid` int(11) DEFAULT NULL,
  `amount` decimal(20,8) DEFAULT '0.00000000',
  `type` tinyint(4) DEFAULT '0' COMMENT '0:商户提币，1：用户提币，2：用户充值',
  `create_time` int(11) DEFAULT NULL,
  `orderid` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `think_trader_reward`
-- -----------------------------
INSERT INTO `think_trader_reward` VALUES ('1', '4', '', '5.00000000', '0', '1567337614', '27');
INSERT INTO `think_trader_reward` VALUES ('2', '4', '', '2.00000000', '0', '1567337920', '28');
INSERT INTO `think_trader_reward` VALUES ('3', '4', '', '1.50000000', '0', '1567338136', '29');
INSERT INTO `think_trader_reward` VALUES ('4', '4', '', '1.50000000', '0', '1567339326', '33');
INSERT INTO `think_trader_reward` VALUES ('5', '4', '', '1.50000000', '0', '1567339733', '34');
INSERT INTO `think_trader_reward` VALUES ('6', '4', '', '1.50000000', '0', '1567339889', '35');
INSERT INTO `think_trader_reward` VALUES ('7', '4', '', '1.50000000', '0', '1567340109', '36');
INSERT INTO `think_trader_reward` VALUES ('8', '4', '', '1.50000000', '0', '1567340273', '37');
INSERT INTO `think_trader_reward` VALUES ('9', '4', '', '1.50000000', '0', '1567342042', '39');
INSERT INTO `think_trader_reward` VALUES ('10', '4', '', '0.02089136', '0', '1567349977', '40');
INSERT INTO `think_trader_reward` VALUES ('11', '4', '', '0.02089136', '0', '1567350197', '41');
INSERT INTO `think_trader_reward` VALUES ('12', '4', '', '0.02086231', '0', '1567420349', '42');
INSERT INTO `think_trader_reward` VALUES ('13', '2', '', '1.49170124', '0', '1567420978', '18');
INSERT INTO `think_trader_reward` VALUES ('14', '4', '', '1.50000000', '0', '1567421254', '43');
INSERT INTO `think_trader_reward` VALUES ('15', '2', '', '0.20862309', '0', '1567421299', '44');
INSERT INTO `think_trader_reward` VALUES ('16', '2', '', '1.50000000', '0', '1567421464', '45');
INSERT INTO `think_trader_reward` VALUES ('17', '4', '', '1.50000000', '0', '1567434807', '46');

-- -----------------------------
-- Table structure for `think_user`
-- -----------------------------
DROP TABLE IF EXISTS `think_user`;
CREATE TABLE `think_user` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `account` varchar(20) DEFAULT NULL COMMENT '认证的手机号码',
  `nickname` varchar(32) DEFAULT NULL COMMENT '昵称',
  `password` char(32) DEFAULT NULL,
  `head_img` varchar(255) DEFAULT NULL COMMENT '头像',
  `status` tinyint(1) DEFAULT NULL COMMENT '1激活  0 未激活',
  `token` varchar(255) DEFAULT '0' COMMENT '令牌',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `think_user`
-- -----------------------------
INSERT INTO `think_user` VALUES ('1', '13800138000', '13800138000', 'e10adc3949ba59abbe56e057f20f883e', '', '1', 'LWBYIiLWinNiulNXYD1UzGgfynNx+gy/zmq5Ega0E0we4a0WyB8UaG4x+VKRoc9CG4e1BXrqZww=');
INSERT INTO `think_user` VALUES ('2', '18993075721', '7245', 'e10adc3949ba59abbe56e057f20f883e', '', '1', 'VslU7gKYuddZFPq4ssWLZCNYBsi3YQIicyG1jm5pUfvZHI4qw03b3A2sygA4efLyWHRkYBQX8LAscwsA7sLzhg==');
INSERT INTO `think_user` VALUES ('3', '15095340657', '45245', 'e10adc3949ba59abbe56e057f20f883e', '', '1', '2d8471d156a9e6db155145571cedea5a');
